module clkDiv(
    input  logic clk,
    input  logic clr,
    output logic clk25MHz );
    
    logic q;
    always @(posedge clk, posedge clr)
        if(clr==1) q <= 0;
        else       q <= q + 1;

    assign clk25MHz = q;
endmodule