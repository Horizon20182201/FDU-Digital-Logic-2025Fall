module Clock_Top(
    input  logic CLK100MHZ,
    input  logic BTNC,
    output logic [6:0] A2G,
    output logic [7:0] AN,
    output logic DP
    );
    
    logic _1s, s_out, m_out;
    logic [31:0] x;
    logic [7:0] s, m, h;
    logic [9:0] sb, mb, hb;
    
    assign x = {hb[7:0], 4'b1010, mb[7:0], 4'b1010, sb[7:0]};
    
    OneSecond Second(.clk(CLK100MHZ),
                     .clr(BTNC),
                     .sec(_1s) );
                     
    TimeCounter C1(.clk(CLK100MHZ), .clr(BTNC), .time_in(_1s), 
                   .time_out(s_out), .time_counter(s) );
                   
    TimeCounter C2(.clk(CLK100MHZ), .clr(BTNC), .time_in(s_out), 
                   .time_out(m_out), .time_counter(m) );
                   
    TimeCounter C3(.clk(CLK100MHZ), .clr(BTNC), .time_in(m_out), 
                   .time_counter(h) );
                   
    Bin2BCD B1(.b(s), .p(sb));
    
    Bin2BCD B2(.b(m), .p(mb));
    
    Bin2BCD B3(.b(h), .p(hb));
                     
    x7seg H7(.data(x),
             .clk(CLK100MHZ),
             .clr(BTNC),
             .a2g(A2G),
             .an(AN),
             .dp(DP) );                 
    
endmodule
