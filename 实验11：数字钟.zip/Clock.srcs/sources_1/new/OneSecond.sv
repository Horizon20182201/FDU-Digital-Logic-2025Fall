module OneSecond(
    input  logic clk,
    input  logic clr,
    output logic sec
    );
    
    parameter second = 2'b10;
    
    logic [24:0] count3Hz;
    logic [1:0] count1s;
    
    always_ff @(posedge clk, posedge clr) begin
        if(clr == 1) count3Hz <= 0;
        else count3Hz <= count3Hz + 1;
    end
    
    always_ff @(posedge count3Hz[24], posedge clr) begin
        if(clr == 1) begin count1s <= 0; sec <= 0; end
        else if(count1s < second) begin count1s <= count1s + 1; sec <= 0; end
        else begin count1s <= 0; sec <= 1; end
    end
    
endmodule
