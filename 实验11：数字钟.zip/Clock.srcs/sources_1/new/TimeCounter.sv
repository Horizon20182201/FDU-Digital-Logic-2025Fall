module TimeCounter(
    input  logic clk,
    input  logic clr,
    input  logic time_in,
    output logic time_out,
    output logic [7:0] time_counter
    );
    
    parameter t = 6'b111011;
    
    logic [5:0] count;
    
    always_ff @(posedge time_in, posedge clr) begin
        if(clr == 1) begin 
            count <= 0;
            time_out <= 0;
            time_counter <= 0;
        end
        else if(count < t) begin
                 count <= count + 1;
                 time_out <= 0;
                 time_counter <= time_counter + 1;
             end
             else begin
                 count <= 0;
                 time_out <= 1;
                 time_counter <= 0;
             end
    end
    
endmodule
