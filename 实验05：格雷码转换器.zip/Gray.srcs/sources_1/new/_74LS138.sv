module _74LS138(
    input  logic [2:0] S,
    input  logic [2:0] A,
    output logic [7:0] Y
    );
    
    always_comb begin
        Y = 8'b11111111;
        if (S[0] && ~(~(S[1]) || ~(S[2]))) begin
            Y = 8'b11111111;
            Y[A] = 1'b0;
        end
    end
    
endmodule
