module Gray_1(
    input  logic [3:0] x,
    output logic [3:0] y
    );
    
    logic [7:0] tempL;
    logic [7:0] tempR;
    
    _74LS138 aL(.S({1'b1, ~x[3], 1'b1}),
                .A(x[2:0]),
                .Y(tempL) );
    
    _74LS138 aR(.S({1'b1, 1'b1, x[3]}),
                .A(x[2:0]),
                .Y(tempR) );
                
    assign y[0] = ~(tempL[1] && tempL[2] && tempL[5] && tempL[6] && tempR[1] && tempR[2] && tempR[5] && tempR[6]);
    assign y[1] = ~(tempL[2] && tempL[3] && tempL[4] && tempL[5] && tempR[2] && tempR[3] && tempR[4] && tempR[5]);
    assign y[2] = ~(tempL[4] && tempL[5] && tempL[6] && tempL[7] && tempR[0] && tempR[1] && tempR[2] && tempR[3]);
    assign y[3] = x[3];
    
endmodule