module Gray_1_Top(
    input  logic       CLK100MHZ,
    input  logic [15:12] SW,
    output logic [15:12] LED,
    output logic [6:0] A2G,
    output logic [7:0] AN,
    output logic       DP
    );
    
    logic [3:0] x;
    logic [3:0] y;
    logic [31:0] data;
    
    assign LED = SW;
    assign x[3:0] = SW[15:12];
    assign data = {3'b000, x[3], 3'b000, x[2], 3'b000, x[1], 3'b000, x[0], 
                   3'b000, y[3], 3'b000, y[2], 3'b000, y[1], 3'b000, y[0]};
    
    Gray_1 G1(.x(x),
              .y(y) );
    
    x7seg X7(.data(data),
             .clk (CLK100MHZ),
             .clr (0),
             .a2g (A2G),
             .an  (AN),
             .dp  (DP) );
             
endmodule
