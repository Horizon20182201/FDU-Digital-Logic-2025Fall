`timescale 1ns/1ps
module Gray_2_Sim;

    logic [3:0] x;
    logic [3:0] y;

    Gray_2 G2(.x(x),
              .y(y) );

    initial begin
        x = 4'b0000;
        #20;
        repeat (15) begin
            x = x + 1;
            #20;
        end
        #20;
    end
    
endmodule
