module ALU4(
        input  logic [2:0] alusel,  // input wire [2:0] alusel,
        input  logic [3:0] a,       // input wire [3:0] a,
        input  logic [3:0] b,       // input wire [3:0] b,
        input  logic c,
        output logic [39:0] result     // output reg [3:0] y );
        );
    
    logic [4:0] temp;           // reg [4:0] temp;
    logic cf;
    logic [3:0] y;
    logic [4:0] blank = 5'b10000;
    logic [4:0] plus  = 5'b10001;
    logic [4:0] minus = 5'b10010;
    logic [4:0] equal = 5'b10011;
    
    always_comb
    begin
        temp = 5'b00000;
        case(alusel)
            3'b100:         // a + b + c
                begin
                    temp = {1'b0, a} + {1'b0, b} + {1'b0, c};
                    y = temp[3:0];
                    cf = temp[4];
                    result = {1'b0, a, plus, 1'b0, b, plus, 4'b0000, c, equal, 4'b0000, cf, 1'b0, y};
                end
            3'b101:         // a - b - c
                begin
                    temp = {1'b0, a} - {1'b0, b} - {1'b0, c};
                    y = temp[3:0];
                    cf = temp[4];
                    result = {1'b0, a, minus, 1'b0, b, minus, 4'b0000, c, equal, 4'b0000, cf, 1'b0, y};
                end
            3'b000:
                begin
                    y = ~a;   // NOT a
                    result = {1'b0, a, blank, blank, blank, blank, equal, blank, 1'b0, y};
                end
            3'b001:
                begin
                    y = a & b;// a AND b
                    result = {1'b0, a, blank, 1'b0, b, blank, blank, equal, blank, 1'b0, y};
                end
            3'b010:
                begin
                    y = a | b;// a OR b
                    result = {1'b0, a, blank, 1'b0, b, blank, blank, equal, blank, 1'b0, y};
                end
            3'b011:
                begin
                    y = a ^ b;// a XOR b
                    result = {1'b0, a, blank, 1'b0, b, blank, blank, equal, blank, 1'b0, y};
                end
            default:
                begin
                    y = a;
                    result = {1'b0, a, blank, blank, blank, blank, equal, blank, 1'b0, y};
                end
        endcase
    end
    
endmodule