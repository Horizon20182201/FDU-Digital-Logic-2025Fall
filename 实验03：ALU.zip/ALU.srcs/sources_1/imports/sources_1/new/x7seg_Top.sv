module x7seg_Top(
    input  logic       CLK100MHZ,
    input  logic [15:0] SW,
    output logic [15:0] LED,
    output logic [6:0] A2G,
    output logic [7:0] AN,
    output logic       DP );
    
    logic [3:0] a;
    logic [3:0] b;
    logic [1:0] s;
    logic m;
    logic c_in;
    logic [39:0] result;
    
    assign LED = SW;
    assign a[3:0] = SW[3:0];
    assign b[3:0] = SW[7:4];
    assign s[1:0] = SW[14:13];
    assign m = SW[15];
    assign c_in = SW[8];
    
    ALU4 ALU(.alusel({m, s}),
             .a(a),
             .b(b),
             .c(c_in),
             .result(result));
             
    x7seg(.data(result),
          .clk (CLK100MHZ),
          .clr (1'b0),
          .a2g (A2G),
          .an  (AN),
          .dp  (DP));
             
endmodule