module _74LS283(
    input  logic [3:0] A,
    input  logic [3:0] B,
    input  logic c_in,
    output logic [3:0] S,
    output logic c_out
    );
    
    logic [3:0] G;
    logic [3:0] P;
    logic [3:0] C;
    
    assign G = A & B;
    assign P = A ^ B;
    assign C[0] = c_in;
    assign C[1] = G[0];
    assign C[2] = G[1] | (P[1] & G[0]);
    assign C[3] = G[2] | (P[2] & G[1]) | (P[2] & P[1] & G[0]);
    
    assign S = P ^ C;
    
    assign c_out = G[3] | (P[3] & G[2]) | (P[3] & P[2] & G[1])
                        | (P[3] & P[2] & P[1] & G[0]);

endmodule