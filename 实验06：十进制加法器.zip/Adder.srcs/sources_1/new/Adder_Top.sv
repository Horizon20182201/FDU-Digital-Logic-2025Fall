module Adder_Top(
    input  logic CLK100MHZ,
    input  logic [15:0] SW,
    output logic [15:0] LED,
    output logic [6:0] A2G,
    output logic [7:0] AN,
    output logic DP 
    );
    
    logic [31:0] x;
    logic [7:0] s;
    logic [9:0] p1;
    logic [9:0] p2;
    logic [9:0] p3;
    logic [7:0] a;
    logic [7:0] b;
    
    assign LED = SW;
    assign a = (SW[15:8] > 8'd99) ? 8'd99 : SW[15:8];
    assign b = (SW[7:0]  > 8'd99) ? 8'd99 : SW[7:0];
    
    Adder add(.A(a),
              .B(b),
              .S(s) );
              
    Bin2BCD B1(.b(a),
               .p(p1) );
               
    Bin2BCD B2(.b(b),
               .p(p2) );
              
    Bin2BCD B3(.b(s),
               .p(p3) ); 
               
    assign x = {p1[7:0], p2[7:0], 4'b1010, 2'b00, p3};                 
    
    x7seg X7(.data(x),
             .clk (CLK100MHZ),
             .clr (0),
             .a2g (A2G),
             .an  (AN),
             .dp  (DP) );
    
endmodule
