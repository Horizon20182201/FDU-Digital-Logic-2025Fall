module Adder(
    input  logic [7:0] A,
    input  logic [7:0] B,
    output logic [7:0] S
    );
    
    logic x;
    
    _74LS283 add1(.A(A[3:0]),
                  .B(B[3:0]),
                  .c_in(1'b0),
                  .S(S[3:0]),
                  .c_out(x) );
                  
    _74LS283 add2(.A(A[7:4]),
                  .B(B[7:4]),
                  .c_in(x),
                  .S(S[7:4]) );             
    
endmodule