module PasswordLock(
    input  logic clk,
    input  logic clr,
    input  logic [7:0] sw,
    input  logic [1:0] btn,
    output logic fail,
    output logic pass
    );
    
    parameter S0 = 4'b0000, S1 = 4'b0001, S2 = 4'b0010, S3 = 4'b0011, S4 = 4'b0100,
                            E1 = 4'b0101, E2 = 4'b0110, E3 = 4'b0111, E4 = 4'b1000;
    logic [3:0] present_state;
    logic [3:0] next_state;
        
    always_comb
        case (present_state)
            S0: if(btn == sw[7:6]) next_state = S1;
                else       next_state = E1;
            S1: if(btn == sw[5:4]) next_state = S2;
                else       next_state = E2;
            S2: if(btn == sw[3:2]) next_state = S3;
                else       next_state = E3;
            S3: if(btn == sw[1:0]) next_state = S4;
                else       next_state = E4; 
            S4: if(btn == sw[7:6]) next_state = S1;
                else       next_state = E1; 
            E1: next_state = E2;
            E2: next_state = E3;
            E3: next_state = E4;
            E4: if(btn == sw[7:6]) next_state = S1;
                else       next_state = E1;
            default:       next_state = S0;
        endcase
                
    always_ff @(posedge clk, posedge clr)
        if(clr==1) present_state <= S0;
        else       present_state <= next_state;
    
    always_comb
        case (present_state)
            S4: begin pass = 1; fail = 0; end
            E4: begin pass = 0; fail = 1; end
            default: begin pass = 0; fail = 0; end
        endcase
    
endmodule