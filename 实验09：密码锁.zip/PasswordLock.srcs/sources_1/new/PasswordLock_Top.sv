module PasswordLock_Top(
    input  logic CLK100MHZ,
    input  logic BTNC,    // clr
    input  logic BTNU,    // 0
    input  logic BTNL,    // 1
    input  logic BTNR,    // 2
    input  logic BTND,    // 3
    input  logic [7:0] SW,
    output logic [7:0] LED,
    output logic LED16_G,
    output logic LED16_R
    );
    
    logic clr, clk190Hz, clkp, btn01;
    logic [1:0] btn;
    
    assign LED   = SW;
    assign clr   = BTNC;
    assign btn01 = BTNU | BTNL | BTNR | BTND;
    
    clkDiv U1(.mclk(CLK100MHZ), .clr(clr), 
              .clk190Hz(clk190Hz));
    
    clkPulse U2(.inp(btn01), .clk(clk190Hz), 
                .clr(clr),   .outp(clkp));
                
    Selector S1(.U(BTNU), .L(BTNL),
                .R(BTNR), .D(BTND),
                .btn(btn));
    
    PasswordLock P1(.clk(clkp),
                    .clr(clr),
                    .sw(SW),
                    .btn(btn),
                    .fail(LED16_R),
                    .pass(LED16_G));
endmodule
