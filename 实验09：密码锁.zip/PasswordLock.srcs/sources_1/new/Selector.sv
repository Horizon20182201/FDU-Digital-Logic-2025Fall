module Selector(
    input  logic U,
    input  logic L,
    input  logic R,
    input  logic D,
    output logic [1:0] btn
    );
    
    always_comb
        if (D)  btn = 2'b11;
        else if (R)  btn = 2'b10;
        else if (L)  btn = 2'b01;
        else  btn = 2'b00;
    
endmodule
