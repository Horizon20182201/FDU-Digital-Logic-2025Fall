// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2019.2 (win64) Build 2708876 Wed Nov  6 21:40:23 MST 2019
// Date        : Mon Oct 27 10:29:49 2025
// Host        : LEZ running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ mult_gen_0_sim_netlist.v
// Design      : mult_gen_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "mult_gen_0,mult_gen_v12_0_16,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "mult_gen_v12_0_16,Vivado 2019.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (CLK,
    A,
    B,
    CE,
    P);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk_intf CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk_intf, ASSOCIATED_BUSIF p_intf:b_intf:a_intf, ASSOCIATED_RESET sclr, ASSOCIATED_CLKEN ce, FREQ_HZ 10000000, PHASE 0.000, INSERT_VIP 0" *) input CLK;
  (* x_interface_info = "xilinx.com:signal:data:1.0 a_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME a_intf, LAYERED_METADATA undef" *) input [3:0]A;
  (* x_interface_info = "xilinx.com:signal:data:1.0 b_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME b_intf, LAYERED_METADATA undef" *) input [3:0]B;
  (* x_interface_info = "xilinx.com:signal:clockenable:1.0 ce_intf CE" *) (* x_interface_parameter = "XIL_INTERFACENAME ce_intf, POLARITY ACTIVE_HIGH" *) input CE;
  (* x_interface_info = "xilinx.com:signal:data:1.0 p_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME p_intf, LAYERED_METADATA undef" *) output [7:0]P;

  wire [3:0]A;
  wire [3:0]B;
  wire CE;
  wire CLK;
  wire [7:0]P;
  wire [47:0]NLW_U0_PCASC_UNCONNECTED;
  wire [1:0]NLW_U0_ZERO_DETECT_UNCONNECTED;

  (* C_A_TYPE = "1" *) 
  (* C_A_WIDTH = "4" *) 
  (* C_B_TYPE = "1" *) 
  (* C_B_VALUE = "10000001" *) 
  (* C_B_WIDTH = "4" *) 
  (* C_CCM_IMP = "0" *) 
  (* C_CE_OVERRIDES_SCLR = "0" *) 
  (* C_HAS_CE = "1" *) 
  (* C_HAS_SCLR = "0" *) 
  (* C_HAS_ZERO_DETECT = "0" *) 
  (* C_LATENCY = "1" *) 
  (* C_MODEL_TYPE = "0" *) 
  (* C_MULT_TYPE = "0" *) 
  (* C_OUT_HIGH = "7" *) 
  (* C_OUT_LOW = "0" *) 
  (* C_ROUND_OUTPUT = "0" *) 
  (* C_ROUND_PT = "0" *) 
  (* C_VERBOSITY = "0" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* c_optimize_goal = "1" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_mult_gen_v12_0_16 U0
       (.A(A),
        .B(B),
        .CE(CE),
        .CLK(CLK),
        .P(P),
        .PCASC(NLW_U0_PCASC_UNCONNECTED[47:0]),
        .SCLR(1'b0),
        .ZERO_DETECT(NLW_U0_ZERO_DETECT_UNCONNECTED[1:0]));
endmodule

(* C_A_TYPE = "1" *) (* C_A_WIDTH = "4" *) (* C_B_TYPE = "1" *) 
(* C_B_VALUE = "10000001" *) (* C_B_WIDTH = "4" *) (* C_CCM_IMP = "0" *) 
(* C_CE_OVERRIDES_SCLR = "0" *) (* C_HAS_CE = "1" *) (* C_HAS_SCLR = "0" *) 
(* C_HAS_ZERO_DETECT = "0" *) (* C_LATENCY = "1" *) (* C_MODEL_TYPE = "0" *) 
(* C_MULT_TYPE = "0" *) (* C_OPTIMIZE_GOAL = "1" *) (* C_OUT_HIGH = "7" *) 
(* C_OUT_LOW = "0" *) (* C_ROUND_OUTPUT = "0" *) (* C_ROUND_PT = "0" *) 
(* C_VERBOSITY = "0" *) (* C_XDEVICEFAMILY = "artix7" *) (* downgradeipidentifiedwarnings = "yes" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_mult_gen_v12_0_16
   (CLK,
    A,
    B,
    CE,
    SCLR,
    ZERO_DETECT,
    P,
    PCASC);
  input CLK;
  input [3:0]A;
  input [3:0]B;
  input CE;
  input SCLR;
  output [1:0]ZERO_DETECT;
  output [7:0]P;
  output [47:0]PCASC;

  wire \<const0> ;
  wire [3:0]A;
  wire [3:0]B;
  wire CE;
  wire CLK;
  wire [7:0]P;
  wire [47:0]NLW_i_mult_PCASC_UNCONNECTED;
  wire [1:0]NLW_i_mult_ZERO_DETECT_UNCONNECTED;

  assign PCASC[47] = \<const0> ;
  assign PCASC[46] = \<const0> ;
  assign PCASC[45] = \<const0> ;
  assign PCASC[44] = \<const0> ;
  assign PCASC[43] = \<const0> ;
  assign PCASC[42] = \<const0> ;
  assign PCASC[41] = \<const0> ;
  assign PCASC[40] = \<const0> ;
  assign PCASC[39] = \<const0> ;
  assign PCASC[38] = \<const0> ;
  assign PCASC[37] = \<const0> ;
  assign PCASC[36] = \<const0> ;
  assign PCASC[35] = \<const0> ;
  assign PCASC[34] = \<const0> ;
  assign PCASC[33] = \<const0> ;
  assign PCASC[32] = \<const0> ;
  assign PCASC[31] = \<const0> ;
  assign PCASC[30] = \<const0> ;
  assign PCASC[29] = \<const0> ;
  assign PCASC[28] = \<const0> ;
  assign PCASC[27] = \<const0> ;
  assign PCASC[26] = \<const0> ;
  assign PCASC[25] = \<const0> ;
  assign PCASC[24] = \<const0> ;
  assign PCASC[23] = \<const0> ;
  assign PCASC[22] = \<const0> ;
  assign PCASC[21] = \<const0> ;
  assign PCASC[20] = \<const0> ;
  assign PCASC[19] = \<const0> ;
  assign PCASC[18] = \<const0> ;
  assign PCASC[17] = \<const0> ;
  assign PCASC[16] = \<const0> ;
  assign PCASC[15] = \<const0> ;
  assign PCASC[14] = \<const0> ;
  assign PCASC[13] = \<const0> ;
  assign PCASC[12] = \<const0> ;
  assign PCASC[11] = \<const0> ;
  assign PCASC[10] = \<const0> ;
  assign PCASC[9] = \<const0> ;
  assign PCASC[8] = \<const0> ;
  assign PCASC[7] = \<const0> ;
  assign PCASC[6] = \<const0> ;
  assign PCASC[5] = \<const0> ;
  assign PCASC[4] = \<const0> ;
  assign PCASC[3] = \<const0> ;
  assign PCASC[2] = \<const0> ;
  assign PCASC[1] = \<const0> ;
  assign PCASC[0] = \<const0> ;
  assign ZERO_DETECT[1] = \<const0> ;
  assign ZERO_DETECT[0] = \<const0> ;
  GND GND
       (.G(\<const0> ));
  (* C_A_TYPE = "1" *) 
  (* C_A_WIDTH = "4" *) 
  (* C_B_TYPE = "1" *) 
  (* C_B_VALUE = "10000001" *) 
  (* C_B_WIDTH = "4" *) 
  (* C_CCM_IMP = "0" *) 
  (* C_CE_OVERRIDES_SCLR = "0" *) 
  (* C_HAS_CE = "1" *) 
  (* C_HAS_SCLR = "0" *) 
  (* C_HAS_ZERO_DETECT = "0" *) 
  (* C_LATENCY = "1" *) 
  (* C_MODEL_TYPE = "0" *) 
  (* C_MULT_TYPE = "0" *) 
  (* C_OUT_HIGH = "7" *) 
  (* C_OUT_LOW = "0" *) 
  (* C_ROUND_OUTPUT = "0" *) 
  (* C_ROUND_PT = "0" *) 
  (* C_VERBOSITY = "0" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* c_optimize_goal = "1" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_mult_gen_v12_0_16_viv i_mult
       (.A(A),
        .B(B),
        .CE(CE),
        .CLK(CLK),
        .P(P),
        .PCASC(NLW_i_mult_PCASC_UNCONNECTED[47:0]),
        .SCLR(1'b0),
        .ZERO_DETECT(NLW_i_mult_ZERO_DETECT_UNCONNECTED[1:0]));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2019.1"
`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`pragma protect key_block
HPMPLvpmoX7LOmPj78BMT9X1rCnPz6PdhVGZQ307N9haGfAdMGVirvGR3e0Glyn2ieoWqXA6qOQL
t0xn28+h0g==

`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
Nxv/BnutRgdmHnLyK7kvDGjm7WGfFKW2mxQ6xUKF14zS4ziz5pSV0ueW4VqAzUyEPsErIAEuyV6F
m5KCqRBB197Q2NbZa7O7tdAqboX6tPAJzbB6u4U/MmNS1AQcSgtfj5srMbdBzDa5pR4V3HrI0MRj
0xhV1BWf725FYPP4av0=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
F5KGJgEDQsX2btdjtRUlSmNtuyodIhGXEa3/AXv1Y7qgSO8gknBfiqj5HcIaVA9b4npQpDnNcmq+
1ONAqLeLhdOm9TES+GsTAkh/lClvl89bzfqgOV33iqwQHYIHwSsWMRXT9JSUx+YWu+g6xKpT1Ycn
8BCPsq4QUJIqL6W16fheEHB/lkMgnespIWEYJJG6R6zvv2zG8GiU6cG8zHrRjdvAj8kOkhmiMvSd
YjGXJSMfjw7ojCPSUF+nb6WWhUEmoMA/6lgSVaXRm00YHSZ09k7rKTJWSXFSpTmkL2WOsQhNS0ek
jdTK2KF5K6z2YOK4zkfHgZ+fB0KJyANaLLJH/Q==

`pragma protect key_keyowner="ATRENTA", key_keyname="ATR-SG-2015-RSA-3", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
lFuQXeJ0hi7qnIKAR+37XCSOwp8bGLukonngcICceOVpL87+rxvhP5TyNJ/zXpAWDF0BaRYlGr7d
isPiUStrvUthNyOqCr4vFZyhCdY8n+Mrv3OCvLoLQSarxVXbaKbXb0tPsXJCUdXTrCt9mr5x0Nda
6DAI8FBPlFMAiqnFXnYMwlUiSlkNWUpInuNw7+1eD8kUdckEUV1PDwZ0yjpFqMokMH9oJjN6z0Yy
65D8Tqo288ZMfZQuIimjski+X6EK157XbpyuoZIuYLJ7j6oaATdintgfZpgGzVvhCZtMbx6/SJtR
efW5vLBGiGs7rPBPE2T8fosHGOvmeC9QBSj8Ww==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2019_02", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Q8VVvHzTNgU3tZr4+8ia7ylST+kbNPWskONHDOT1dTkB7cHZIAWyzXpQZPuEgk2wJq21PoqmVlG9
t08IYzkfC8vYQ2LRf2Co3SXc7p3gF2OFMC68J9Nf9D+/PXJCJy3QO4H8oO39l6bn8c56K2ARnK0R
mMIALbCWSBDGCWGQmXWZJ+xmDGs1KgTeiSW3bZRftWJ6K8l8BhMit8BLOY2Mi3jJ0WRhN8kKd6JT
D4NU1jTZT6jEtmI7Gnj/AXG6auTqDPHsVQzf+ZzBsLTfw83CFoO70xM997L5cZXlqz8fEDmxezkr
wWxPwJbJeVkRV3tUxlo2Bs2x1uVkXQeNVMI8jg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
oUeTLA0HA2uKORUHo1HidNC3lw54gxwlLUkv28qRPv1pz7AEVUbIJ7wsyu2Scju+EkC2Ivi8HbBn
jxkeqRDTAwAbAqIKnY3AdyfojN9Hb8SMLcLnpWLLCpb6E0vwA09r7uqKRZ8wYAgT9CPFvzpQ3zKt
9DTLgQ3rZtFxx2nfCug=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Fayrlym1l14Y48yZ195XboT9ZQmp/mAzUyHby3Y9qJTzDF+m6mRQ/ZbebObo8bu4VAm45JeETPx1
YI4UZNOK4IqKv0BZsAlzUfAYAmqmkmIJYbn2gWUCwXyKX5AoA4ONnlxEHxzZhqtsmEXvxwTEs25/
R7iLzeoMfmwwNHgPNQkteiR4zDlB76CYmgu6EOSUX5Nnitq1oh7qRuU8WqWN7lLfgIC6T7qNHwGD
RPze2yiP06fSG45jPrOn2fvBX9SRbUXjNtiFgmqim4anwJU46v7y3ubit/I6giZhz5PJMZfkDaFX
ag+uCMq4Q8ZEolqMBmjUjat86BdVd4Nmr0yUaA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
kIpxh3qIIkWUg8aLJSPKvKhKTPFH7T8fisti5RtNaftS7xh3KDsGLYnF1lYhH2RVXgzbdaVqvtED
5QJazVo6wUFI91xgFeOR5jX+Ny5UBUX2MngsK+UZyZg5+EdtSiDtiJNtQqgjq1Rn+XQCGF3xP80n
7YvuVMbgRHCAfWrWw7ZJ7Y3raRzeIkx+koPFio7XnC+QdRJ0ItO1YtQgF4Sg1Ihr5TH8/RrNn903
kPa+anH9spo3SFCf2Ts11UXAGLdIBmOLMtEAKjjCUbtmjGSeSc0gn2q2I+xRTFcegLevlr/iuLTw
3lFndBAoW40xOiCDjWZ6Rz7J+jZhsRl3D0Bhwg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
QDHJBzN59wzlyyZQgNghnKTmlMpAmCIt/dCXMEGDxX8IXGn9J+AgGlMZOByMKNixHul5eMsXtje/
qWHJOo4zlUI5VCJbeampAM1W1pjI5rOy1/ZjfXp9aIQA0FxCeWagHKQD7dGmtOnw1RyuXPSWpezI
RKODtxd/vbS02jLNf9JRtiisf++0XnGVVWPbfYO3sawCqFhg6m3XB5GrHtlp6DpPE5RHbbqa2gsa
T6qxXnJ1H9ckKi6Wfh+cMO6iYEK0yNVOUXzyq1zN1gaFZw4+Vdt35dN8CNh8s7qtL3BIYobUn1VK
mBPnNk24Ju7HzhPcBkbfebQLS89HJtmuUSKDLA==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
QeOzn2mogO/584cll6DT2Ib7d0Ozf+gwjPrJJf4f9I1VS95hw7SVovDucN4ChPS0icCLOqoA8LvL
mSfmWDPVaHRL7JRzlNLCOPUSDIeHtyZbpl6+NPZk93uzUX/F89L1pkoODKLlrlBOgXHP0TUpxPiP
WvOHBE+6OwVeOKHVDaNmD04k3StI55+na4EGi5UvC+51gzWzRx7L6yVl5cMMuvDkxIcIQcLP/9ld
SGDa8+53PO8FCJp1RHFNCY0RjQShLpptoEvO+y/hNbc7mnkLGhjvSfwEcS0Bkyg3UvH0F0FIGbIs
BqEUjv3ZqVQt4PFMNhhW9Oz141lFm0D/Yfbfpw==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 17200)
`pragma protect data_block
01au6pJZnoCDblGzh8l1dBrTy4VX6sap3CSAnEaz9VvVJPvTDSfkbaLOxzO2RUHN5gczk0i99xk2
H4F5x3jzDQAC/kIssj/UosdswMLDcrLF+4YjLt4eCk+EHzeiM/o48U+yiuK5qcUc7p8Qn56YvRuf
XEqi866Yj4kNjbrAw4dALnfwl/2PV1xQ23RRdwoLPEcOXQnJ4xXNoQtDTqCP6pqge74eiFTBv12u
cqO1WCNjDpdVo2xxlsPwzSnOM/gJf9p9s08dqzBtBnqdjjke+uAVAzyxq+3bxgL83BlvlDiUM0r7
JxROpOy/oTtV5dcZMtDyDOlclYj/iHIFFfB8mdYXQPiqpmY2Hr9LACJ4Q1ZHTl0pjp+1qTvC7Nn4
Vg5Npj6JoZUID+9XgAmI2+SLajY9rgzGc61P1oPOYB1MsU+GUuXgB+bxk3doEayzXdgSev0o7HB8
sm/uJYZTvPF0l9m3dwPhrqFQvpE6AHiD/aMFvJuyHVNV2sotZrB+3cikSkRyyKc4jtK2UD86brNh
93jhcDooRohuVHTC34AlJiHc+YrKHtbQwo4on1on73G7D525iPThXBuIt0PSpzQmAIApiaTDTwXW
KxH3wYXKb9BJZU6yn9coTBVgEom1Jl8B5KB2zmO0m121/eabiRCWUqiD7bUeSWJ5wssgcVdMjLxX
J5q5W3QgHpthrXJQurOopi510nRAj+nqHmRF9qVNuKPSK83eewntq5jeSA01mjHhRC587sguVGUT
p8HuBw8p1SvYYS4rbQEMWATHBO1O0guzMhz70LuNEGLIZWWUadwcHJvsJfNKv5CMAzCJtYVd4wag
i59qNyqyYjqkC+UlO0+B7soJ71rtSdOwPy96IAeE2KmjxqmEfLGa1IDjPz4r+9SMp03xQWLz0I9a
dvUI+gRm7dzhFJyb2zBsWVAsjYSB2fq8gMpaTCXNfLmvce04EwTqgtVZodoaA4dSdP7WqeLqPGcZ
XOLYFvYDYzdPP4p5bsr0Ngq9G8gnJih5HV7TeGx0KQQmPEugzQgz2F8Vne2lRV1mPufZZ5umdeSY
LF4Afhe8nbe9KrJ2xWg+gwPkPmdep0WQAmn8CSbQp3nG/4vGT5jMamZhBAxA+sy50/hz/Wx8TNqc
9Hr/YeHQChW9kLalXZ7Efr1Vb+iAwxyUmKJOJH2VsGumQdwDHRBkPP81NaBjB7IxfhtUBDhgrJ4X
RZ9qgVpaG9fd97B4/G9baDQdj9Y6dOZHeETD8+GoGnVVZipTfKXPmcyr3fiwRud7LJB5gmOgYXQZ
Z0O4S8OdC0ABqMRybmKwg7sceNm2y7BilKMwF6s6QedgFCtJCTzEuNfrIq3ELqoyXPs3WpSNNdfU
NZdFsJFlDeAsDVdXucOmpUGFolk2uFJdWrBE3mxUEIcFJG1C3JquWAbVGERaxxdXOpZ7vvG9QcdU
p9xKZnPQiOW0zxq7J8tOgShDT0bZinER9ivaSLfUecV6QUPyHVljrOe2nq+1UpXJWeY5n2yUYfQ8
4/RPAJIg5lQF4l9C0fs1cN2FVIQVv+e+VkadP88EWwrDbOKaDeg6QedEjUEMMbsebMKHoUYBV3Rg
OvxLGFzctbSVx7KXeNiCG53f7jTAP7c6BWoaZHKd5CmiKQUI7d9L49gpUcQ2YWJj1jB9I1PFv7bn
GcdAHkn88mFrs/3I2bTYod0MwpjIM4i9XgVjgSKjMX4fIcmbFf7Ts0x1RxK+Qpr3i4ADntxqTrQP
2DXuYmT/eE0zwzYXM+yG9HFtKORDa6YjlQNe2OCUTUpQe8Buka8hwqwjrHCBviJwNlrKTTwUf4o7
laZwH0ZcPX6pLdJb+pnJjUOHtc4Kdd2L4pfGJnQ7WRQLpBdGNjML0Rr6x7R/Xl1/Fz8wJVqhwolP
DqJ3F/6J4aV05SnSDaoEZ9TnxfAUNtzbYfnhGMgspcTqt8l0PhvtYSPa9Gjo80bfuSJtIP4O3bJc
Ft5h7aRPxfgfh+hbw2LtBfTe3RweiaNjVagptbBaTV2zXLW4T8SGSI9SGtVnweggRWmiQWXQ4xjf
qtysS+tf3VAWLD1McRqUIrUGkHP2mitkiAiVFJ5I/9cWNhS6EEVhJCd8D6pdap1kZ+OywXxifJj6
1464zKEGZOO83H/NXL8TYFPAJYovZElSUv78hhh2d2dPbeUN532R491W6mKsDlLnmOBYBySicgou
/s0iRPCAIuoigEkUJ72oi+jH77zKh83CYWydlkucQjmiGStcrOYDqlgtEvL+Ln3Tv93mbOCzMxSJ
9XzDPpVX8UMnMP5VigTHsoF008pwVxWlbIKz2DAJd5rS3Q7D645lxRDTdvP+pTbdilPtjz/rSTo2
A6/AeHnw34ASvV/hBqvotJhZ08p8wXoHcE4lYBNW5Fhl+rvaKPNZeaO95kRQuliPYW+f3/l1p3Jn
3tucJFqoDbAwXe4l+xtidrBZTPXsoYbg/4NJ6nTiZa7WPuFpMmYuC/FfcYDwbJPRuMCscu8iH70c
oISVgNCFUxPyDsezDzBwG8ULOJGp1XtxDS7TkiSWplnQbJeXrntW1s0ZRgL0Xh0x0AJlB7AxytbR
DgY16rXynauiVKObyq41lKaCi4YaEQOkVdlbSzmXcG/CMgKRynPkhCofCyniAVp16kHQTT8oOv+t
00457kiy981smcfApi0lQAZamYJvgXku95wz3nyRtpvP8t6N9F4zcIvEZtHc0nHs2EGmmfr3Q90F
7qwbwA1ddC7sOtBOi3QrdogJ6FSKSzja8RxD9NNiPW36kT+ZM2RMYF6WwjkFmRkTIRP460oGIyaO
QpMyKFYjCnLTG48ArpofBXNwCWPd9U7tpj9KLQZQboFm2M9yh3sGN/adm9WUOCpbc/0LLiFrPyBA
1NNzT63F1QjiTiHb7FKxZpSx4QHw3HSRMqivbcJOz6FHsPwrAnn8GBJHqjfH4ZU9DH4S+dmfnz31
EZbx2edZJN5HxSA+Ct9h0KBi3HLZyOuLHZDhf4b3IoBxcDz3dB2QC+6qlq+cXXUpJELjTQChT8gF
UW5rpRRn4OoHxRI9CHq2qbM/7laOlIcdHoulAr3MjWc7kIS8CUWuLr3CozayVLyHOoL9BfAFrB4O
/V21nwKP982nVgwDRoVc0gRGHD3JmiRqAnHnA72Wkss07S487EgmunJ8mQucz8tAO3wC1Me1yfcD
TkgPLBYjx+1P9YBGUzDswRZGu9UvZ9BmlljSzIna+SFfcMpBcyFyCAInOLUMyWKjIVEjYERUZcH5
ilRHv4raiYqV7Wn9OxjarXcVIId6Vfk57eWODMgx0aVR9Lr6w830r2jdOHBArWLOVwh5JSI3/0JO
+w49AzRS1WlrLd9ypqAP2YgNiGJdNTc7klXPp3D4W/aiwSbX52PzpYDbK3hTex+SdAdhjYgXWrM6
ie4wEztzRCQfHMFJrfg1W3TE/lP/SXA5kdzXtk4T7HakOMe5c4FVgCAaIIbjGjVOhuc13hH0SX80
vvbq/gvawFahjl4bFmVOmrlYcvXFOaWNAUehAd9lu/e/U2ytFQ8PBEde5Og6+tCieAmdVWlLORr2
PhUVsueUmxv6ACJy9aZvB/jir1QS7Lqh8CG5hJgyie4OGzYdbEXbrpvXamXnnNOJgaQat4iZXZgP
qID96z3Y91Ez0G6tfoQXW2DE9kVsSskI6KWsjGGt+6Ov2UQve/vGy2RZyB7y/zOQsWThbc/Hck3l
qXF3JPI9Oz4uu/DRQvvDuRyB+KPDc+1HRGz91uhSdP0zI2sVVc9gtKNoRopxSELvZT61ZsSEr/1I
S+7Uw31TMZx6lCsVjAHZlqWK/cB9tilSnWF9t0rsHAPq6c77HXZ0HWuIRcUp2aASN8LwuH+kk9h0
x+vS+eadacz9fx2fFvDBblMFIXNUQm3vOh2Ram5fjtNkpg/E1x3m9rp6ObgQEldH1NcX/BVR8v7a
mtzCMtKfe5QomDR3AWbF2qLgvTY+vTx1rhxebSWzo5+bmgHMYSybevRKRcQ4jBBm3QDpDXfaXfaK
mCTd9tGLybDOTd71k/VTIE/nVEuoMANkOVVSAKFsuOm82mJteGjFl/YBsk4/WomkIw/3B/bb6V2j
aRmepjzzZOEcgvTnrNyyY5UY4JqrAUYdnLpwkIjuCVAd4YVUmIOblkLA2utMtZgStQAJWPY7VtLv
aeF4h/GDr2OqwZLy0K86w4UHCkptFL9nbBFhtHccIA9O8qfwxB3Ovl22HmcsGGtfaJ8ZXj3UCCGi
ruAlykc+a+e+y3oLiioefP2ySRPNy0wJd9WDDQBNKjneXDxYXdhXIzkkGOYFpVoFi95Ftdty5ZIm
nyp9bZQP52IKDuGhioclRuQ7DFzowSkoKL+qYUYDVvkOXPb9KgAYJUj7Xf77aC5EnmXv64vC7ACd
OzZsJqx4gFOa8couqF6Rl+llhf5Od4PSzz14vGWGaJFK1VKM5Ma72T0fQ6IeXANvRbCvMyjIf/gF
+GylPbTdoDDVA4fyzKbZDVEnRLOiD17CMukjP7qHggjTjgFdOETgYnPis8KVpHzlG+w3YtKpAjeS
72P+afCfzqrHqFElLHalgZ8L3cknyQM+Lun7+hqWttkfoKsUXsUuWQIhSgXerad4aUdPKg12imLC
9ooH5XGIG+l6ClAhCOJh2yIedIbTmN2adp91wEjH6lnZuVcEfv3DahpzkbqiYJ4L5svECrIx1B/D
DI9OyagjdKSw/F6M3jKumlsT5wSXX7sdyKv38bN3WFjUQBDi1QSwbFpNbrPMVj98i2jABvx59mTm
5i5D96FYyZFZO1Ma/y3Uyls37SFxBe4qQs32FKQWd+5H/maa9SEne0DwqzxogwqUlsBBRNEGsSRO
T4mkfVaRY2+BEaHj9UNZ0ecCc7KfOANOsYF1J74w7U6L/ezYe3jq0utyELF+ivRMTLMMh5qR99Mu
6X0Z63FP8EU6Fnytx2se0gStVnRKbKQ4AAaTkoEpDj5Li1ivb/W2LoJ6gT01mFqF72gC9jbwGhxx
zSNygVY6EvSfQL2yggT4D5R8mfziq9fYOi7ImPrax3j/Vl51x/VHzIZjGcdnr8oRTtJ2HnPKHRwP
HXnMusLKydgv/NFqu0xnDVdAuubmmgBYnKHwAAC2AmcnFCQx4zeds2OemMNfq/H1qLhpesvxmPkF
ESZlWDLCtPZViW34GGqnf8/SLwrvuK0OgY3Ofb6hLmog5k8zVkx2m8q1xf+TZpWmo48DWdZa+sUs
nUuE4IC1RLbYmqJ+Re447nwUl+jSDpcjP7ijzOqHrjiVo289qICpsL+e+DquedZr4sixxiBUKvjw
fUjBv51kvYSv5h4LHiY9O0fFuYddp1gNL6WqtemcqhlUBUHn2tosF4HTpm8mU0iew84qM/f/zh3M
n4QuSrBIklngHN5jv8N/itKPML9UzIm/SRkNFP4hofWwjq4j7cEfFnLHRVXfu2H630WHFIGc5sAh
Hz5jLd0vL0+vyxwdzFaMkXqjT7PSQuL3ki74DIn4ZtxRetsqSnQzuFkTshKlYMMNIk+ATOTsXJPF
OBlVLGcKeZHTOhJDiFmYpL2RkZMugqe3sgKer5LkDwbGDXk66J05Uq7ZNb9gL0bw7pOIkPvjnROk
HINGt3TrffvdwS0BZV+UpT1v0QHOMkFdT0Ye6mmwjgcc//lNCXdRgsWJBlJ8kc5TzhHYS4Trasfa
e1VH7183VGqedFiVb8DasyD/XjsCQqiA7bZs00mZSN/3+DY5Y3Dxx0cXbq/bmuIwHEJbusgrqG2g
VKunNqg8x05dlXcD0YKg8O/BrQrLfW3WbJz3p7voNuNnG9YrIbMeiiuDo4opBZkI3iF5KEu+S0kW
hQcfh2tAzPJhl0wgzsbLN+HALxLoMxXbAoZS0rnF/yHTSH8hspj117F6e0hVFUvjzrH6XDaSb2kM
CLAa1v8LC+8mZk5qFpEukdBvuzX2gKLZWokYf3M2d0xwAQidEzvxmgW5O2sVDSprUF3lXGZtyfFM
Ou+ummpDXbg6zVG/CFdtKtfb5fy2e3jNy9iIUtaN29pa4ueRNdxI+YbC338qg8F3Plvi6G2Dc6Yy
eTF96oTS7uo1CR6jLuba4/4QfxPGfaQVUwPUi0rY2TJ+7brbCO1Brgkv8d072Zjr+SUxAuRzB1uv
Bez83acTlbHD6wBU5GXjvvlHgTUHYHSXbKWRQo9cEignBs95pT+2Ru8lvUKSPxg4TJ9k+qxBlmpV
5G3kJ8HXYw4pYrwZ+QE29dSUlwvP2Ai3ABmM/OmO9gUnbPgx2lb/Pv2V7WtasTPiuNcnQYrTsxzX
OVL8gVRp1k9u6cpfFloY4LI8JajREBQDq5nQ4oocV6sDTll44uH0tPSCEXAijeY6sHvLVkqT6IFQ
3U9FvhdU2AHz2l8ojvFGbJWe4V+SeByUSmr1Mes3WEy9vi8rpbRZOxLj9iQt/A+1/bw6iCreBdcG
GTtATrzam+FrgECAUnxjurTsDGdOL3/rYmraVj3FsUOcRlnwmzAg5zk/Q55EsfOXBQEyRq/ABfWz
3BUlwimGii364YBdKJHkO4RTU23b9tHyaVmjSx/NlVCiyMzXKIkY+azmz65uKbx8AtZTtSwvKRth
uA7uOnvQX8Wa7n3AdMXA9yViio9UBJstJV68H1suNPK13HFn5FVb2PNPB7gHU5C4eMi3THT1y0ll
BqrkuFP4rGaN0k2JsY7gVPbIAxZMlwKpmb7MooqTqZWu1N0ioc0f89mK+58zko7NTrSw0edDpyMK
6cfXpv5voX0IcILJ6p6dmS3Gz24+QjZsAAlrtvDchOjbJoRejWbZlO60YgfpDihLXChxSEBQr4K7
vUtllh+Pn/FZu4A0LXyS9cUbWrvuVH1V8EVhpl9zpNKD+OL0Blz+2MNtF9joCtA9mMHifiUeXDzH
9nbmkxlaRLbsxbMuyCm67Sofa2syKX/17BjpPVJqlfeQ9pDI5itvmpfycbV3tlUCZkGLvDEuA57K
3rM7ijsQ+AFkpLsAZRJ3wggsN9lV7jULkQtfRjUhpXd3gNeFzjrfVLea4ah77p4U9glWPsfH3KDO
tqLGuHFnG2SgMlfvCKw1cBWAoeklV0DySD8HmS02DL98Cr5Rbsb0DjEXQj8X5UMnsHfDLk3bvgpD
vvPh6vRuKcQfUWv5NXBXnvAcZhje/qri86HFuNUCtV/373WQtsfKnHlslLPQKEUqSA6wITQwalxk
PMJTueVxZly6oWXaOUxC1Q7WCMx0rHyyU4TtrrJj1caVWUAK7MWugsx9KZCCy2p+KQd0OLWEf724
lbHgZiB7vR71b6yJShePXmZfIvxopFP7chJX59J1vJKzALjggHp2q0+dK8qAMObyoSbR+F9wqZ2K
MJGTDPiWZEqhMml7rpamCO2mJje7bRRe1p11oDBfhWX3dvliuQvNvhZ+em0Ut8vflT7zhtsF0q51
HzEKz3qQVF9qHzEVkbmLE9aJc6FOO1dQTLi7RevPsNLqxnrUFBqkubfe0z57XTiulONERF8c3N/Z
z7rpGHjlGzDX4YevgxGgWdGVpLRsupGFtBijoiWNFfSk78rgU/+mc9898pIs600O9Bm/ndfMSSbV
ru9nn0kCJEvrSnkIP91UE0xmCIg3buLnWauwt7tn96WdtWiVJKqXRNSW7mfVOesDmTO9u9Iolo4U
cDrJ6TAli9zQN7AGPZDPRveoyHFA5/Ws0iU1mLbCE7bnj210JoHYEzXsEpV2ieTc2H+iLyppVdbz
Rdsf8KhFXfkt0KBDB8jWtu5jE+GO+NccW3tWxxoFnDbEZGiIiINhu13Jt97ZF/sAEBAiH10CAk9G
b/QTeyeQCGAMHxjhK42yqU4OzcpoyC0sRc+LwhQvDTrLT3PqsrKAez71jSm0ZQEd7mZtomgzd5No
qgvsN+2HJcgxzjxKJ1j7JH/FTiHLxmTFyPJc6Ka7Kqbf4YkZD9QGNgfGgEfGfnxZUr7/spJxoieV
ktLNeGUtAdT315ebALZWA1yjAxa5ezUA5F+zxd9PXVLG5YXBeNbee88bTJukQ88QXR+0R+ioCfO0
iNV7SvQ9iM/2Tg9Yky3s2MeMCAgBl3vk2/bROLZRaERD02SPvPJ65XYmlPgItsy5ZZkL3nmpJkUa
6MOScGhCSVSGLyra8dEk0YlwlzKq0lU/ZiX4ajEZJUmql1WA1BQoxE74h3oIpfjwyhSJS606q3yE
xzeS7b6gKKVkMp16kIWQvN4d+NtRehlafwAE/6Fxvfr8sex90mKXgL+5uGkxSCKv2A46XCba+5Eg
/KRF7S23MZTusZ5Il+r71jnbVhUmOqTViev2rKhxUpUROhgNlDz72sVA4PmzEP41NX+IhpUDzEkm
iqUgPWQ63qfZOFKWW4yYhgHcmcH5F6p0VaxnTMY+2TqOyrPNn0RIXYIOOFJRjDjcwiabx5L5G5pK
a8h7m5EejIfXPLYfy8jJhnLMkP1S9PFNVM6eA4BuG9EAlIoLCBRSPjRXc1529AATEw2jePZj32mR
rQ8yjXBkurAFUUP0Ab6nabSLj7t/5QT1X3d2O88lszDc4K1u6TxxNnhAvPlhPCA9dj4qXUp4r3xg
Lr5AvZz2VqwdZz6AaULOi/6+I/ZduouneXtaEET4AJLd03IuaDNUy6kUj79HczuKliCPv5Nuh1iC
TSaOVUElYLobM6psydiU6IYmkFEA23Ddey9Te7L+rWTXGqsbEFApDUxMYSagBlAohe6FntqkmLP7
2/VMnMhKp3JffHmcaZ+2gPpmX425I7actizxI5WMZZGK9bXqTEEA0Zy+sacoHVeFftZZAOWYPVSJ
9em2pBU+F+UT5fzGlpTaisU5LScKSd8jYx3wf8WFw/l24Zq5PFIxcNU2GULa6MIGZo2qni7S2w2d
kUQ0ioM9jAhfTzxxwNFp66LtM3X6FBj7E10czlTG9HYLKHFaIbqlms/BFzqn7o04ycn69ol2b4Io
Wo8Ohvb4t5/zZj/HAatQ3GJOV34oDVmgt61+GtB0bFoDrikuyFQN6MzEzP+jJpsjADx8JrXXjbkl
VxfoiwniUkwBYPztbu/qS9X6AyFFX78LVL2OAWPcESsciwK1dLcFwsNIsMTCqBdVzL/K9hbYk/JL
GRHo1tkE2DsgQxZDv1Lxc2ChKg2TvANpi2xryWGCx1RBCrViVPH1JYJXv0ZaiDVG2r+mM+2h8c85
+/IKq+CteECzBOVLTJGYCD4RObDWdydaetDWsxPQ3wWF3fXL5qqWiqwH+4lyF27Rz336NxJSEsCD
Tp0uyMreGXDwVpyu86H6nu4Pm30gscZKzCnqtQlWtb3BjpE10oCkjqI9CVc0Ac+TlvpNq5Sl0AyC
ql2isb7cYdt3bXX+u+SibNjPbJfnp49hue8DF1lFjHgOJ7xtax2iWJxwU0vTIj5OySgvnmcumRqT
CBT4u2+xftsQxyEytm+M2I3Pk9VE9CPQGUZEnVuAOlVGr5qRC0SazScu2RKVh1iSRCF/Y7a2BYRh
uxJDdAGzwxQJla2z9/Kby/HPzw1++/KWq34OXr6YKg16btVjjt6VZ1izfHT12pD1IwAuPWMU840W
rEn50j9xzJfmXulF1XYhDuwMHN/FTYompFIcFCMKs4WWnqq8vpt/uCNKXskxQKzX2NnlOYOmb02e
awuYIwp53NvvhBwru7tqyWKAnAIS8gIpUSR7NcQOa1FmT99IZAA9KEMV1NNpr08mnT/00nGzXAMO
XcGG6B1QA7MDXyTIpEwhDawqwLXUNNqkTce9hyMzopsQ5rwMqyZyJsBuI2If86YYqTuSOIRH/AXM
eT1y6MOexj5Ztl0PELws9gqWs0xAIh/ner4QxLfre9PmCpEEVnZQeQKVEaj9MDSK2/0ayP0dteKu
93iintaISWuxeU+OlGhd9LUrXui+N2C2tQh2Al4vFgB91EhEAJyaFZG/7aXBfvXVUsKACJThrG2J
fBihOBu2EWNejKPPdA/r9yLJQjVBtZ/RSNufDUgBMHhBwq87MHSsViOjhxJ1vptFic7gfEeMSArA
oJOxG7Mq9+hlB3FCxRdKMbNbm1nmHnZCJAtNdk8w2UTS+NCbL+ArNdWmAImwQPh7+KtsPDO5ndmF
FPZKLRzfrfoZ40yMfGdN2q+LL+bsd584Rrz/USoakX/gy054W29KSYZxNpTC8699r/+V4Gf7U2o/
yxpPQfLXHME4Rc7Bd2wP2PpTyIzbz28aHVB6a3Y2g0BkFyr4Wo5V/ccda/f6uYaM6SNMIDvF1kOh
bgW3E52ho9yDDmjClHVDYhUsck1Vwk4eqZuyiZfaZPxhDJPZloaAUuSD2gQnPm9LcUWN5cXGCZ/C
cHfXNfcgICNYTVbyBKo1kuUnkwY1GWNM6DbLMNvoSC54p4HUdJvfN30GlY3IAVPL+weIUpMyhL+G
4C1DNjXyXrobmuwucwalL8PGJ6Adw/h607FZIHfy/y3aut/Z9oGZp2P+yvsgEHqfTKs5ENedQZjs
jJcHlDwJMSzsyMOr4I3k7H4kD+kPDD4dJEvRIDJ5op9lWCF1JxJ31Xyu4Zg+sYSb61jRtGqhpFTk
4AoYw1uVAKfhDrYlHuKmQJaQKg72YJflMLr2Rm1ag5diB5F1ccIiOwI++IDwSt8O/7MehXaUtgzQ
GZtdD0SkzUIS1XO0V8Sm4BHoATvRNgN+lZk5XO70A3idhsXurHIrMP56vevW4y2WTRUJK1mPN1hj
J6xcSD3L+MhMSIYXKFdRwy4kycdicOP59qUIjKXOggaOLGFJH3Jk+MnjUxkX8MYieHoj8BKlF5WX
Ztskgf7UgUVi5vUAzAoZNqzhWa41/epEfln/94webuAMmaEEc4vQkU460d9y1fE1Po+S4incSWLX
Qiv5cPBqMZcXaqmjN7gc7UcK3P/etD/b6zbPju7XWFuips93gkpkSuvwog6ziWI4lLFjOcx6ahgC
WZMhmCqqpv5VicSz2dzrYfoSLrbrsftUCi1cqG11Qd94C6I5/jY58QuHXA9n7yO+QYpIyo3uwVID
cXAW9fiWrwooKZafv8edk2jDlS4am4RFhQBTWlxFMeZigvl/wxtt1Iced/0yfigpNEiINRztr17V
4aizubQkCzDEF62Bswc8E8wqUJKHv2s9n0AxPmHQ3GRjlYKSk9cBWH5baxBA2dr9/N8qWw9mMFuW
WYIyC5qY9Pb6+g52vt1LzOn+KNG9hg9Y6y3UYcpH4ZnI7UkjvmxE+wUAgUYal7Rz9rhLh97l2l65
6SLHN22I62Y1cnXn6HTbjSQHUag2NWrlwoFDHHmrZYirrzY50dP3MkzuITPap8uvKQLkgTtVuBn1
ChlEXhWxa3bZgdWntuLGOmSegln/XLiRh3f75x7Nc/S71tN8pa84rqsTVuMS346LFOKjVmKq1gHh
zUqb+HIn0s0IzjhJIqPRWtBm922wZuQ3d2n6YwKCh6TAIUnR9lhinPgpiqSJnHM+EdoMhDeqECS8
EHXLrafD9ShK8ezQPIcNR1Uo/s+Aw2isVv/PxYiApG5nFyFYM5kaPSnJys9jMp9RNS2hb9Tq+CM+
sYn6zVoiTT7dZswhDGk92iDFTlXRQnvT7/WCiZ2tKwi/LgxqRnK4WmR1p0u3QFgQdJnhyz4yM62b
sIPQDsX7dS09V78SdZx5STq++BWbYqvUiNf1llCpxp8TPpBcJD6l9xwB7k/4q7YhW9htgXnboyrz
tjHjHLk1OClSzNcKsbbbSPehrS3PSVDYCMLtXWjUcaOYJlyd8ETZpuhOR8rfudCly4xbNwfUxD0t
TbrfDN1MIHKtzv9FyvqSVbTKhr8Oy7jU291oVfWawGqk7IPIebKAhlLovUrMEJK/mksgTcW/+C/D
GQjwpwqn7y+sicp6AfSjn1rZa8N65Skb7jRFGmBeKazRQa1VfqPBKRnWlN2VNt5UcfNNmzIX+pSN
QIgCdccxGdJ6UpYUWwunPQ2UQlT3711qisOyKN7YwnVleN+CQVk+9DgeYdF5MYxwRc8G8+ppuCdi
0sYCDO8YS480ZyIrp8W7Jmb4wkTqt25PHyXdMkNNRZ9VvX8hz6Ld1JdBroz/FtFH8jv6YT+SV2rO
s8JO8wWgRVVQk1t9+5hiaMjUpRzZ8bd40vwfX8i2vd0LH8tKP1pZ9mPUa2BsRbZpvdr5LuHpR/lR
rRnfmHoJ22IIR+9TY327HUtH7XY5rNaNVjVFBKriue5HwshBDokT1ge/vjdxx07i+q0DAu58uNVq
KJMOY7kj1UfmoFYPrE207c/nbcKZToyXnh2Jp2FEreGruH/ZktZnzSH11R2ICHlJcRUYNHdFDXC5
y/PaAOEfydKSuQdpgTreu3JC6FtV1M/X5C69DgI1xdK3yZBa/kzEHaYkiSGiqzZaBDcgQqSWRw92
rnq/TIEDRdHf2HSHH8N2PZyvJ0sxhXyCZG72LdZTxNwn4C//QxzKHxcwBGHlSxqB/FnjxQZvaria
OTp9izfO4xsY3ExCM1XHAQL6WGFpP2n9uteWre3NuBUpmzz7/z87oBw9N03Zvh7kCWeo7pP6AYhe
7FrdzpCXMPZeN9aV1och9gJpxO1szvKj7wbmicUKTVK2dD7mMLMt4Hx8Yunq4siOx8Sgv41gcPvi
adwAWK8h/+6SEYocLFzC6wS66eZgUrd3NNZZzotTzY0nIKMAYHM5mUiEYQ9qM9yoM6S+TMxjWnol
ijSvb4uWaqxIt3zZKY11LLl+Uax8PpMdKYftJYrCNpA29XMPMSQ7pI/LhF4SzTWCw0pe6QWE91Zz
5gjhYedJ/vAyrRM2RBDbB5XX6zppTmGHCdc6axmwJILoZj+IpVZ3EqAGJ3wKDbLRtzixCpVkChuO
2RE+SXsKz53DPZEcMrSqmYxP3mZUpsrUkdx1pJRRnR6GGnVh3dRIU/NfBqhLu8M0qBqYDmSDyTkh
FxiSdUO76sJt7kixbNpJbP14DqkMRagWYE5/YkxO5mGjMJU0KLb2dZKBoubAhTtazbkWkQQfhlnw
dGFYvx3Q3MQeBMSi4Blpw87IXwUI2O6ODjiSfKWSxWwIs4uyE5c7/6dp71xLRNq3p2+mVBgFFY4U
rEVtQERjmtprC5BqWV85vjJBUbzrZjb/rmcPNR4hvrwqCDcsrlrop3atQ6h2eX/j8B6pEWxrIWlM
+/FR8MksUSkegaBROL7SZVu/kivRYcVRNR6EUBDdJHTyvmNdJX7LBoEzLKaBUYpzw54okUal/kHw
z+JdAgtj0rN3h5Q0soPfbYpPtg8OETMNVlX8OfY0WpjC5t5BTT+H7emGzzemCVU+ciEQvmgOhEqU
wbw5L54WYsrJCFb9XQb4f20aEj3djMTx8P6Yl6drh2/BS7aOM57xdOg8uZgG872HlHNVwwQCgw/7
buWiYamljkPtxrGdEqQzJqMr5eobXCREOy8HOwj7Exn73Kk7gIJLAGxK4hbLmwDwWBiXlmgnPa6Y
ewxniWTg/zqw2uZJy6wHcwVjk4CiM3EZcrQpkZSBdn2etFEbv7HIwK8nYomOIYwEdKvaHr6TPscO
azFG8CE0f3Qz0OosXRWMOs1Pu2XazjiUubveKNdPMyGf0zaAeb4yL9EBLVWvArjVTMjvggMsxTMh
mHJNUkQaKrmQU3fRlkj3PMzK2UwEGgNpx4Q59z6ca+VtrC4ptc0qB+anLHNNtcAfnp77pwm1JHZi
67OM4cXUZGGzaXAnRjmVJM8rPGIBgRPtbVOqWPZg4P8MCaHWZ9ASaBw2897OmyRC2JbZIbuOlXUR
dP3j3Tq13rION5y/MK3NaGiG4fPXYwAfWm0Ydn4tvDdGFDiLpUu2V7bBbfKdEUS6P4Ny2uwdlZhu
KcGPQlStmjkXRS5AbnkWbQzHTn9GmKqEACJyRi+ZUbXoqBt1yBxGLy2S7xrKwcZgLzUvwiwSrhPa
19iLTuUcDYynh9TwVjF4RGyuSxJhhADh8n7D8YQoKwmV9Eu+dIFw9q9CIF9z1/Q9GzU5NZ6Vssb/
+adBKogqs5WhSpsl5i/ktANbJGNfjf1cK7xTUMrAJQ8ye2Z+pty2TI4ypEFJepC6fFhIOzgKcFv/
12xkzQFfsc07KZgBhNsaTNX9np9z7jsGolPRIJCQhm/RalB9rNxxAstWPJBPlMKH8IMHa0t2SMeY
2N9HUI1taYcP8G/xtuZG/rm1EuTpbVCal4bCZ4C6IPquJ+2KOYnaBjqCYNksf3zGYuLOXnkRIATK
+CTcgztK6uf/TMM3ONQVPHwTBYaPMkM5sRmryzo/76VJzRL/cVOe1df+zHboK81kXeMgPMz6URN0
VtzlY+BZF38s3Y6ae/2ls8kIYXDnlIPR3Z3Xo3vfYI94WYRWenVMTKyvTLHsWIlebwQ/MmZ1X/f9
7KxtQtiW1Y3Z3dYnKtJ9cTIV98NNZWXHfOYS84hIGIOMbimAlvhDcXbcLvw5xi5V9Q/B6enTzlRI
R06Pn5nl6QArQsQduhE0ncrSCSqRlGcekEJRpEzrdftaFpp8FWuh+5caUv9XNTQfMSHqdniRNZ2x
0mMiD4PTl0HC38roudCzDiqfy04hsx/jp4Cujom9pa08gD3yO2kZFhuu0nqORyToec2cVNrenX+X
OszJs9mRk7JrGbY1qX1gOGcpovXmlThPWNHquMFv57iDY4ZySmDFMyG8CZmpZUSHx/kxEY3jhNbz
xiv1Y2SMkBBKyP3yNjtBfqPWKbpff0qfDRFBeG7uEvKHFUH+pHpK909CRjCLT5L5E2s+rtRCJ2mb
gIsGwO4wQpTmPJu0kEgt7nZE9b+cVa1pQWxcp6k/qjoR1CEgLbf8Id+K99ulzD7CzfE9VtYwu3Vn
IC/QO3eq1cQfVdRvpb6ukIqLKfnN24KuBjWDhucLNRhDiwHbAIy9U+HFAVqYkITmDs+iyYL86C1t
LV/sRpVldLW+xM1LFVnTSFOyLfZhVliKoR45CK7Bc15ybam4kOsQk/fJnOqTgoTzLKoi1qOv60to
AVLDL9FQVen/v+lGUzw+ak4CqwFPreXoCZuxpLgrBc6X9LPhgdt6z29rfxjagJ3J/+vJHNoegXvr
UL1GlkpwD209gaPOs4nzXODQu4RWRlpNCT3WNIvYirX8PDyduAQebU38qZxa+SvsLx0j8brLrycd
85todW5VwGyCuojZmMoog7PrPjPa8X/fHaFMtR+4kvx5JVE+G1+2Nd9hd0D+cdNq3uW/MSRDztcQ
gVW9blnYYhFGOGONP9yJAgKpGEIYvntzvpAl1MQ3V51AEsJN2lPYuvm35JQwaotKRuyL/Qogiutq
wrPH7uejsCyHf/BL9UzZzeS1lzAJ91vd1kpYql/HJANX3QynMvMXjSkDqleCLox3nzeDREaiSYRY
gGN9N2Zvl5hjRRQsw51TTPEu0qHfZedZdVpwLa1oCLRrc7uYT6/aZ8hKVr/d4GJN8e0YPuJFTFbQ
0FEN6pw/tWn1f3ORTq0GG1nxBBHL5jQ6MN2BmOc7+LyszMrODiruZ49/o8zTSvfqMJjBXoVb7aua
kLuhuahJAEnRVwOR5viW25iJa2kjBCByCawsAz/2zaLfypnve4e/V7oOKSjWJCiZwmdVFhDe8rll
lEPz3yzezxbBn1KaRkbuEbwcF2oa2cb40stl9kk9J4HZe+NvUkjnQ+Kdsy/10XsmD623im0zjevy
Np+FLtlpExi7vdjLuP2hHbIvorssnWGSmv257BoytgsTQ7J1YPu05AUdouWSYwFPL/mvfYyQ4ifw
KYU8t9aiIOCuZXxTz0qgRSMtps99l6PT3eV4W5axekutwFCGA384cgpuRQP0khSDe4eAbc4oWQFj
kMMjRL3B+nx2VvxPK7hyGiT6YAkQCvtyQPrS6ppUg5U+tDkR8DnLVq3frQPErAXnf3MfPh9OoBhw
PJ3Zl4jChhVJBMYz1Dbol0Jo3I7tOoQqQEAoebrKBvnYRidpp+miY2hkXakD0y0X1ENzTRh1Or/j
P4sotT1d5fFERjip0LQYCyn5NWRIm5g83UrLg96906o6aQ6UwIz2Zg5dy6QamYaxcmpJtnyam/1T
JBNCa/xBgBBwKByfssZlYu4IxwRRF9uHgswo2anXa1TxqDslAY/4drRLf/xXNEW1LxlaGpKkIYWq
swl6HdT8C+A0b/UP/SI/IFD8/loHTYo6EFVLa2o58m0RwNZ4QuDFXJ1W6KVyojWXIQYOOwVhLKii
DH3XRApKu8nY5z8mKH3luJUPFhlVLA/8qTWKPgPhpy0BgycTp3EyCK0mP0A6HF5j5V1BlvFFrJk3
tDyOY6trUNpLADBKTPt9NNCsnzDjL2+BfOMihjHyf0Lg+n3CjCyauw1BO0vqDxpS5HTmE/RzId9i
fcQMXPslu2N5xi/2iSPdU+OX4UbBibUI6mRfyi+1+IczQPAc8fLNLD6HZg6dj2Ion4iJySTctwt8
VKnueM9XoPSPKKyiFCjg18InEZNxiUSEPAK+ZCNzWmXTiS/PIVgcqFqYYJlFScd1ryENX+a3Qo6r
OoXylcp8Js7RH7eZQugHruu92TfhPbRceshQtVVdV0upzGEWDqa5AwZG3LB0pyfcnGp0FSXSOsyK
Lx7iO4z9ZuDcGWIViRq5r2t7KKBsGaqqNBu02gHjvI4nyQmZuU2jSwMLuJ9sGakF53/oLOLj9dup
FaPb/VBWqYBsW3zE6g6GJ3Ouyosx9yk1gIIVw3wVzelNSjjtVP44jcuRLSw938QCEgmQBNhjgX18
LJWa+7L8oO/X7qPAK2IIRS/9DsR3BnmXTdRbOmNWCtfY1HYtWSBl0Ncfk1giUTxVK3dwJXuxJ1DR
+Ocpbg49dSt0AS5rZR51msS3+cUptFNd7YF+tpVYFJIPXxgHM43/vx3L0MfJ2OrgMAB0klLWG4xe
AtZnur3ae73luibikvhMvmUiXU80URPlfvecfrSBcDXIDtAy67axm4B7oQbiajsyCprsa6oc9Taq
bgN/+Lcjxe5Uycvl5eIgWyzCm79vcfkF6T1FrxUF2YdJ3QfU1X7Wh/hFQofu6OXSa+uM8eTa7yjY
oNbT+iS/+Tdd+IJNt7Uu7OKjE07ASZne8x1qXUKWpHhFL0gUBlbG3S3els/nD6DXo3AFUyJs3eP3
GX6VaNKbnLAXg61Xshu6HFXWn3FGeO+1bjABmGdlzo9ACO45qB4/KmG9rhmi3wztgGXhkfdlA/q5
VmGoSLSF3gpemheXOWlV0Da/uLUaSZEbCy9phXNI9lZQr/gM7L8loC4HWdJ/rVw5yL1MrcR0gsJy
9twQYwIJrhi6J/rznA2wgau0YJiuScMcezQDw8/N8Ok7PEG3JWG+B9ZXyc4sscfgyZ8xbPxDC+k6
0Thh4FRVhidTs9CVYsTK+Do6G1VuD+fK/8SgJwJy8Z+pGRbrAdzdYP32L/8ku2YqEVu6kCwtd/ir
S392iHV3OCkdFt5fIZrbhyqlKymigL1jN9f+eBvTUhZbyBPjjagVA4EA6z6AcRRKNEhGJWZGdy23
qGW4Uae3kk3KxbJ2ml7UYPkTz3aj5PxN275e9w21d2iDuR0vCSw6pem269XVeibtsaTDEmbFSb8T
gkiPdD8BTcXdNosaPMHl4AlKk9j69otfTmffdr1IMUI3MqESsDjIq7LfEcZs4RztptY94IKlzuW5
zIwfqwt8z+p7u1VA2U/oAqDHJxwN8X82CoFU34d4lgLUXsys0Evq+HYLWEJ+gTCmtNizntyIiOeA
MWbq9lAbS13X8UWqIMm4YvlK7SJqZQqL3cqCDnjwX2F8ZAA7ALioynyLNf6HrmLGUa1G71dRnLVK
JM9mMB6fnWmOmHRyRafuwwlJVy+CEo72rzw4CSxzilR1DYn9idEOviZZw5pVhf8CNpGzogcJl23u
ici4L64t6MNL/HgMAek1SBIE9rGUMU1aAWVmverPz1A8ALGU96WtH2MxQHKLE1Lz5brACnVXXqlK
bwTBmjBwhILpOrHOF3D9asLwZLmRiLpZqd/n86UXcrQbg/okOBxdzgNHLHkcXB64D04OgnGkVm+A
0c+2GWuiVA6sLUfRkw2D/cGUjsWqEmvUYzweVSBs7c6N62WQqfyuiCGgvHSCxX0FT0aoilhr4uBk
Y6vE/0Opufsj+NrZ6nnY60n8PP+PQM3Nl9OaDJ/wzoIjmnc2naQwy/9avPIn+ygck4a6S9OXp/4C
sGDaFCqkDmsLKn+X+R46sCbHuXgqA8h9iAL/xc9XWaeSKDi1JkMKjSpFKxEBeB3zCUWdZ8cKXZaS
oELiVZ1aMVeV2DcvX6DjdLMsL/RFrImpvQhz+4f8uNvFQmAqbGoOD0wFefQQSLiLG/O8Lidzksrc
UIWSYykSeFddQ2w6HXLiklydDPCHgSlBT2LXQTuj3AegiLAviJ7dGNjytJ95rLonNusfNhdnqZRS
7sNSYRpR64kBiaq+YvH0VOzeOLsc6bG7ts9oCI600LgDNua1Q+4REb/RMGnWv3XHfvUsnhvc558o
O4d1KPbe9KVEtsEMGdFMk50b87Iea3B5tz/zC17nQ8lJe68BS40+wz/LqAPt+XHeBbwG96Ok6eks
wRyUq5vFFcpjw7tyGkNaPgZ+/BbEgWmMBipJYpclkBSEvlkwv+oOxRxmt1EqMc7rlOIOjwyrqce4
G7ZMxVrxMlSFtBjpqSuseo294KokVSSCtbgUz0JhjCHakM2LXzLOw35A9ohdjgzx0n3gsd/dm46M
OORUrOluyHDVcQPVD2OGnF9XjapBI6pTu4kGLjIS10emyyBq+AIIWan06YRkVOqDctInHZkMfFPw
vaVQVyJZVnMVrocZjq45QDzVHfU4PhVHeNK0rC/JNJFkdkzVkKxxfO8Dcefl3bIrZFmE9xPI89er
QNUFuIUiiwutbxN3lbDzelLc0m8Kc5qKwrq3PAGez949Kq2QlZ+F3vPIHOIgAuywfceCN1zlcz7n
B+hJ1lHzHnbzaR+gBejfrNWqViCBmC3GxYiNewYWRUGOuMNr0ritv3buhkYSlBgEI5iPzVWwJVD+
3KCks5Zf7g16uZYqnoSF0oQlNnJsqsbGz7HNUDcGldmhqW2sR6peg5QapSY489Zf0CaMiPydFeDX
CS2ZdgkK1Zc+hkwYUTqd3L8u7GRCz4Al+VhjmdfHXjqivvFy1qCTNne4RBZVj2wzQYsrUTGUrBv0
Pnxn0vUfcfrykTO0hMDHFgQKc99lDDxGUXGdrXdomFzbXZsdBvD00YC4olhKzo2YMdxDxct3AQ9s
pwbSfahrvxgy7Rb0+6NIfRNAW4k2vAG8uyfs2VmlYHWWnFL0/XpuNt6A47kgFKCeaaWde3xbCRu+
uidsJxsfl5me1TLkAHp0aS7wIBQechkzZ8/PZOuClI4iLl16NmTvnL3ujxIK72HYjeCXscp6tFeT
ONKdzp9D+GQY5t76e/IILvrOGtoQr9FNe6I1RxChSCmQtETjhn0TCWtwvakefIrS7sHojEVTHAoA
OCPop0RisVSnVbr5EV+Mri/gh81EmMG+8Ywm2ukxA/5sXeP6eB+gyX2hoMvZb33jgz1Bm0agXPyc
ad4dFhm+11rHr8Qdgi5Q2w1UtxkviAk7cxwr0TC/NT2v1FzZTmCGaOnmxjEqSV465vRTW3O44FJj
I5CW3+FJhLkQCRPaULa9Wi18Tn8MkM6WgRGaCYbYxWqxdg8zxJdsrftPcXpjsnddtcyIrngrmF0M
cBtuwiFHbdwNnT/frIMtlmeXQ89CpHqO+MT3GMZlxZVaYtNZW7fuo+bIzw7BUegDeAE2BUojm9yc
rw8YT706Y9xZawTSJp63Csry4FdQFZV/rTHsuMzSKDnTuM269pp/BHHINyjbG5iK+NBqfPhT9Xbj
ZmSRJhYzPyqsh+p8oiEytehFQ1bDFtOAKVlaMhdSyjmitiVdV3tSQxMBw4ADc8Kp28BHoRU8x3HF
fZ6B/r6s2o5Fh/X945/nvpHvOqT5ptQ8cqK3w4oVI6vUZowzumSmnVEtmnb5rIT2fJxnHIW9/hfP
PgiuAkUAPM1qtGfoAYhENhFtM8k/1DmK+/GeAuvLuDSMF5n6VRJBlMzKOlr9LlY1lbszTmyy06Re
COmoAbWC0Q7IzZ8/joSR0vKUTxRncapsNaVZ/ldejADvVP4VoHQ5ij6vmUfQBAcZH4pnnyLwIVnP
tO15phYoxp4+a5aBUz9aioJl03/XUTZ4oFotd8nOG1XNcc+uHQWwnEJo6H/tEiv+mlr0zLPgFQqk
GpwbIWpqo8vg9Rps0f52Og8wmEYlD/hOffcW54Ztv8RrKTPxzGjjfxFrKfwSxCPpERZao3FKYoWR
BtLnxy9gn/PWi7IRV/hKO7TcN6Lo0Gqv1PZBDK1X81CjvzibbQla9zz/M8qqSCL7cB10CCTsop/b
VzxFrduS2PQWr0+Ms0sUKO1S0C/+4anA/pGp0o1i8bv2kKuMDE62P/EszdGUr744gHcUSUNVpyt2
gRhHtuxIuoCqYvRJvBtLYln7u16OWgbKyytg2+W5VFGGoCx8SX1adiIVrj61cb1JzBlkmPe9XB+Z
GwCU+MZQo9WJ2eWy2REUjvHiHIIA1fLPSXOQdTzWvvPzzxFOlnUeQB6EiRAb9CrQIYZTsFL2MsT5
UuQFdCJRkUn1HA02a9SKc9Vbot1gNtkjBmP6JBxVMIK0rR8V8PfPSpa1yIxNsV6Wdvvz5ivkcBgq
kUl/IhHhKHMCXlQSZ180AVmPZOcH22zbx1LubSV9t83aQWd5V/GcYWF0mSwnrRuiE1kHxRgYmFUV
9xMuKvOLIxVonCJab+x7m6Qn5yv1Zdwsx1vmd056nlDU+nDI3F5+x4jcV22XbQksVabxOfaokqxt
jucFOmmwGp/pwOCSz7sxGJ+luvK8oJ5EQCvBRwRQmdRYMe6szk0moiny5IAi4E+PHWuiRSuUHBdI
UddE56h44hQYi9PXu9Ub2kyYKrYqwhCkURXWr8Zbq59HnpvTJe8PFU8yJVeZLlCENlm5Oij3xQT4
5D0Z2oP63TqZj+qrajpoQoERYEYo0Kxhv/ze5g3BKMWJDajczg7ieC1oVL6h9AiZki8w0k5uTQNt
kRdlaIKEaK3RzpbJ6sfMykaNRnivkKVe5O/PMd+x67Cs0VeWZdaaVBykUoMS6ftO2fioyaab+ab0
on37GT6G59V0B6Q3uqS0SiUAAoKnMD+c/MmHekkrGZtMbCfdBl68pRlpCog3EwqFHRP72vQ/ijqW
o52qx6irXsBNlDSA/oFOZXSzJBP+6a6y0QuBkVrxA/S+zxmix2WUouaaYkz+EVPNcCkrcSFxMIX3
83b0IwufaY50qLSiwKkeo+lkuLCO7woLljtFdEDIAbBnD+D+EgLGZJPdmmJJ5qZgrbz3XkREGVLv
cJzmd36SvNm2D9IPe0/7b5fDEJ+he3YyWkNQv7Mxhkxfyya2u94uvVSkRDYnLakIaAfiqQ3KYba/
Nyd04WyuBejcQ4seD/BkxNvte5fp2EU4b+BRQqUmXO/PtGewZtJUnwcczHtZW0h1KIsV9wqHgHos
YB/uOuZ7qnSYcowI/GAP7S+/JX2DA4laOiDKUZEck2F4fp0fco6xDWv+/3F+M2npVoA54rz8qgTO
Di+CV0kf1BsOK52I+sNjguMZnQrYKqc5DjUdCn0y/79vv/QXqV0nEcJRjG+b42bw2Qia8kblW0cf
XEoxvvou3mepaYKPj17icvB0fIzidlOOkXy2zc2Hu6WpTU/ahJCTdAsw/OoP5HzJTmMq7yQxraJR
6v10NdgPLHM70Ps3BD9mMh859FDSuyHT8XDjXcLKUVGVKPYNK//JOq62CWfAA37zqQHkz0L90xtM
eCkeMcggikZAR2F0Kj2iEmQ0mJuGOIxQLb5bxGV5gIrMirLJFkthxbkic/8aE8aFAi29NvsgZV5D
83CW/EmdiNYsS6WOmrXviIaB6a0EZcsO82e7Ct+n3VGTqH08bgzQm0uw+BNvNvtMpxAsDEqOfKSU
mRdH1LJjEVD2ISOgHpNe+ZS8QvjfiE2hYZxNMyg7y2KRDKxKG93ZjmHbXOQu17ZpwPTOe/YKun3O
bIeR1v516ZUuXGHdtrHrEJTUvndgTGWn+jJJji1zd2itTkBvnnmddg0zeNA6Nt5JVgoSqw+/9gL0
gYK6OvdRgaHbNJZPoB/exOg1Le9AxuoBYElZolSwL4VHY96bDne6WVR3cK44i/d1uSNERjqR2SyG
ZzRKteW/ILluIZYvvjvheUdBmRakg6icG9xpnCHiKP9ejbNHUkkpzCMbW8xqQDF/n3NO9vC3Lfwo
oYEb2yWJGaRYcT5g3R6wKN28XqpnSnXON8Y1NejYtqyK4XgqxhwXAeWgjo68J1wPtkgqXZHUYKL1
zAxlBKa1picPsfRuOpE64HexFziwDRt8PTin7oZHrGtVjyJoUROZ7cBsAPS7m2pOSV5JAAafeaHN
59C98g2LA0dzmM/NBuqHPgJAqabDJ2mfq53U/QSjP70X5Zsuq6e0ifkqKQ3PIXA+dI/atQQoIuUc
UbfaMm9nySev6B76teqq7gcU/bD1ST/JKEC1sSxuo/gMuH/aTLQo1h9ZYOJobnsynDf3VzQsYupu
SClBQlRPDry/YjYcpVL8Z/du2/rfaduu2p+QFU48AL5stgQphK1R87V/9pRURbNxyvDWtt5mBjCX
KxcG4sSt0xktPfCpBCkCSjiLAsJQ3gVjvDRKRBn3w4A6rl1boEPlGmke/RniaHd5+vqYvgWMd2GD
uqjMqRZxgjV39I0Zt1YmQ/pSnB9IPhPbAfJAdVtNnfWrUU8sLZ0JkjX8oVQfffq/rODRBtiNIib3
9IJEW+GMcZXNDmyISKpkvGu7wzBRELluHnJGmcInmV+lLpYRyivceC2JGdFtJLX4ySfk1TWnoFV2
s7zeuQ6/mAOR+9lNTlpu7zyPEDLdhUB3dfMkZtVayjx7g9Q425fGAvKaJA==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
