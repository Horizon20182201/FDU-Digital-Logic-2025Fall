// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2019.2 (win64) Build 2708876 Wed Nov  6 21:40:23 MST 2019
// Date        : Mon Oct 27 10:39:43 2025
// Host        : LEZ running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ mult_gen_0_sim_netlist.v
// Design      : mult_gen_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "mult_gen_0,mult_gen_v12_0_16,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "mult_gen_v12_0_16,Vivado 2019.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (CLK,
    A,
    B,
    P);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk_intf CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk_intf, ASSOCIATED_BUSIF p_intf:b_intf:a_intf, ASSOCIATED_RESET sclr, ASSOCIATED_CLKEN ce, FREQ_HZ 10000000, PHASE 0.000, INSERT_VIP 0" *) input CLK;
  (* x_interface_info = "xilinx.com:signal:data:1.0 a_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME a_intf, LAYERED_METADATA undef" *) input [3:0]A;
  (* x_interface_info = "xilinx.com:signal:data:1.0 b_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME b_intf, LAYERED_METADATA undef" *) input [3:0]B;
  (* x_interface_info = "xilinx.com:signal:data:1.0 p_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME p_intf, LAYERED_METADATA undef" *) output [7:0]P;

  wire [3:0]A;
  wire [3:0]B;
  wire CLK;
  wire [7:0]P;
  wire [47:0]NLW_U0_PCASC_UNCONNECTED;
  wire [1:0]NLW_U0_ZERO_DETECT_UNCONNECTED;

  (* C_A_TYPE = "1" *) 
  (* C_A_WIDTH = "4" *) 
  (* C_B_TYPE = "1" *) 
  (* C_B_VALUE = "10000001" *) 
  (* C_B_WIDTH = "4" *) 
  (* C_CCM_IMP = "0" *) 
  (* C_CE_OVERRIDES_SCLR = "0" *) 
  (* C_HAS_CE = "0" *) 
  (* C_HAS_SCLR = "0" *) 
  (* C_HAS_ZERO_DETECT = "0" *) 
  (* C_LATENCY = "1" *) 
  (* C_MODEL_TYPE = "0" *) 
  (* C_MULT_TYPE = "0" *) 
  (* C_OUT_HIGH = "7" *) 
  (* C_OUT_LOW = "0" *) 
  (* C_ROUND_OUTPUT = "0" *) 
  (* C_ROUND_PT = "0" *) 
  (* C_VERBOSITY = "0" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* c_optimize_goal = "1" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_mult_gen_v12_0_16 U0
       (.A(A),
        .B(B),
        .CE(1'b1),
        .CLK(CLK),
        .P(P),
        .PCASC(NLW_U0_PCASC_UNCONNECTED[47:0]),
        .SCLR(1'b0),
        .ZERO_DETECT(NLW_U0_ZERO_DETECT_UNCONNECTED[1:0]));
endmodule

(* C_A_TYPE = "1" *) (* C_A_WIDTH = "4" *) (* C_B_TYPE = "1" *) 
(* C_B_VALUE = "10000001" *) (* C_B_WIDTH = "4" *) (* C_CCM_IMP = "0" *) 
(* C_CE_OVERRIDES_SCLR = "0" *) (* C_HAS_CE = "0" *) (* C_HAS_SCLR = "0" *) 
(* C_HAS_ZERO_DETECT = "0" *) (* C_LATENCY = "1" *) (* C_MODEL_TYPE = "0" *) 
(* C_MULT_TYPE = "0" *) (* C_OPTIMIZE_GOAL = "1" *) (* C_OUT_HIGH = "7" *) 
(* C_OUT_LOW = "0" *) (* C_ROUND_OUTPUT = "0" *) (* C_ROUND_PT = "0" *) 
(* C_VERBOSITY = "0" *) (* C_XDEVICEFAMILY = "artix7" *) (* downgradeipidentifiedwarnings = "yes" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_mult_gen_v12_0_16
   (CLK,
    A,
    B,
    CE,
    SCLR,
    ZERO_DETECT,
    P,
    PCASC);
  input CLK;
  input [3:0]A;
  input [3:0]B;
  input CE;
  input SCLR;
  output [1:0]ZERO_DETECT;
  output [7:0]P;
  output [47:0]PCASC;

  wire \<const0> ;
  wire [3:0]A;
  wire [3:0]B;
  wire CLK;
  wire [7:0]P;
  wire [47:0]NLW_i_mult_PCASC_UNCONNECTED;
  wire [1:0]NLW_i_mult_ZERO_DETECT_UNCONNECTED;

  assign PCASC[47] = \<const0> ;
  assign PCASC[46] = \<const0> ;
  assign PCASC[45] = \<const0> ;
  assign PCASC[44] = \<const0> ;
  assign PCASC[43] = \<const0> ;
  assign PCASC[42] = \<const0> ;
  assign PCASC[41] = \<const0> ;
  assign PCASC[40] = \<const0> ;
  assign PCASC[39] = \<const0> ;
  assign PCASC[38] = \<const0> ;
  assign PCASC[37] = \<const0> ;
  assign PCASC[36] = \<const0> ;
  assign PCASC[35] = \<const0> ;
  assign PCASC[34] = \<const0> ;
  assign PCASC[33] = \<const0> ;
  assign PCASC[32] = \<const0> ;
  assign PCASC[31] = \<const0> ;
  assign PCASC[30] = \<const0> ;
  assign PCASC[29] = \<const0> ;
  assign PCASC[28] = \<const0> ;
  assign PCASC[27] = \<const0> ;
  assign PCASC[26] = \<const0> ;
  assign PCASC[25] = \<const0> ;
  assign PCASC[24] = \<const0> ;
  assign PCASC[23] = \<const0> ;
  assign PCASC[22] = \<const0> ;
  assign PCASC[21] = \<const0> ;
  assign PCASC[20] = \<const0> ;
  assign PCASC[19] = \<const0> ;
  assign PCASC[18] = \<const0> ;
  assign PCASC[17] = \<const0> ;
  assign PCASC[16] = \<const0> ;
  assign PCASC[15] = \<const0> ;
  assign PCASC[14] = \<const0> ;
  assign PCASC[13] = \<const0> ;
  assign PCASC[12] = \<const0> ;
  assign PCASC[11] = \<const0> ;
  assign PCASC[10] = \<const0> ;
  assign PCASC[9] = \<const0> ;
  assign PCASC[8] = \<const0> ;
  assign PCASC[7] = \<const0> ;
  assign PCASC[6] = \<const0> ;
  assign PCASC[5] = \<const0> ;
  assign PCASC[4] = \<const0> ;
  assign PCASC[3] = \<const0> ;
  assign PCASC[2] = \<const0> ;
  assign PCASC[1] = \<const0> ;
  assign PCASC[0] = \<const0> ;
  assign ZERO_DETECT[1] = \<const0> ;
  assign ZERO_DETECT[0] = \<const0> ;
  GND GND
       (.G(\<const0> ));
  (* C_A_TYPE = "1" *) 
  (* C_A_WIDTH = "4" *) 
  (* C_B_TYPE = "1" *) 
  (* C_B_VALUE = "10000001" *) 
  (* C_B_WIDTH = "4" *) 
  (* C_CCM_IMP = "0" *) 
  (* C_CE_OVERRIDES_SCLR = "0" *) 
  (* C_HAS_CE = "0" *) 
  (* C_HAS_SCLR = "0" *) 
  (* C_HAS_ZERO_DETECT = "0" *) 
  (* C_LATENCY = "1" *) 
  (* C_MODEL_TYPE = "0" *) 
  (* C_MULT_TYPE = "0" *) 
  (* C_OUT_HIGH = "7" *) 
  (* C_OUT_LOW = "0" *) 
  (* C_ROUND_OUTPUT = "0" *) 
  (* C_ROUND_PT = "0" *) 
  (* C_VERBOSITY = "0" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* c_optimize_goal = "1" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_mult_gen_v12_0_16_viv i_mult
       (.A(A),
        .B(B),
        .CE(1'b0),
        .CLK(CLK),
        .P(P),
        .PCASC(NLW_i_mult_PCASC_UNCONNECTED[47:0]),
        .SCLR(1'b0),
        .ZERO_DETECT(NLW_i_mult_ZERO_DETECT_UNCONNECTED[1:0]));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2019.1"
`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`pragma protect key_block
HPMPLvpmoX7LOmPj78BMT9X1rCnPz6PdhVGZQ307N9haGfAdMGVirvGR3e0Glyn2ieoWqXA6qOQL
t0xn28+h0g==

`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
Nxv/BnutRgdmHnLyK7kvDGjm7WGfFKW2mxQ6xUKF14zS4ziz5pSV0ueW4VqAzUyEPsErIAEuyV6F
m5KCqRBB197Q2NbZa7O7tdAqboX6tPAJzbB6u4U/MmNS1AQcSgtfj5srMbdBzDa5pR4V3HrI0MRj
0xhV1BWf725FYPP4av0=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
F5KGJgEDQsX2btdjtRUlSmNtuyodIhGXEa3/AXv1Y7qgSO8gknBfiqj5HcIaVA9b4npQpDnNcmq+
1ONAqLeLhdOm9TES+GsTAkh/lClvl89bzfqgOV33iqwQHYIHwSsWMRXT9JSUx+YWu+g6xKpT1Ycn
8BCPsq4QUJIqL6W16fheEHB/lkMgnespIWEYJJG6R6zvv2zG8GiU6cG8zHrRjdvAj8kOkhmiMvSd
YjGXJSMfjw7ojCPSUF+nb6WWhUEmoMA/6lgSVaXRm00YHSZ09k7rKTJWSXFSpTmkL2WOsQhNS0ek
jdTK2KF5K6z2YOK4zkfHgZ+fB0KJyANaLLJH/Q==

`pragma protect key_keyowner="ATRENTA", key_keyname="ATR-SG-2015-RSA-3", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
lFuQXeJ0hi7qnIKAR+37XCSOwp8bGLukonngcICceOVpL87+rxvhP5TyNJ/zXpAWDF0BaRYlGr7d
isPiUStrvUthNyOqCr4vFZyhCdY8n+Mrv3OCvLoLQSarxVXbaKbXb0tPsXJCUdXTrCt9mr5x0Nda
6DAI8FBPlFMAiqnFXnYMwlUiSlkNWUpInuNw7+1eD8kUdckEUV1PDwZ0yjpFqMokMH9oJjN6z0Yy
65D8Tqo288ZMfZQuIimjski+X6EK157XbpyuoZIuYLJ7j6oaATdintgfZpgGzVvhCZtMbx6/SJtR
efW5vLBGiGs7rPBPE2T8fosHGOvmeC9QBSj8Ww==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2019_02", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Q8VVvHzTNgU3tZr4+8ia7ylST+kbNPWskONHDOT1dTkB7cHZIAWyzXpQZPuEgk2wJq21PoqmVlG9
t08IYzkfC8vYQ2LRf2Co3SXc7p3gF2OFMC68J9Nf9D+/PXJCJy3QO4H8oO39l6bn8c56K2ARnK0R
mMIALbCWSBDGCWGQmXWZJ+xmDGs1KgTeiSW3bZRftWJ6K8l8BhMit8BLOY2Mi3jJ0WRhN8kKd6JT
D4NU1jTZT6jEtmI7Gnj/AXG6auTqDPHsVQzf+ZzBsLTfw83CFoO70xM997L5cZXlqz8fEDmxezkr
wWxPwJbJeVkRV3tUxlo2Bs2x1uVkXQeNVMI8jg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
oUeTLA0HA2uKORUHo1HidNC3lw54gxwlLUkv28qRPv1pz7AEVUbIJ7wsyu2Scju+EkC2Ivi8HbBn
jxkeqRDTAwAbAqIKnY3AdyfojN9Hb8SMLcLnpWLLCpb6E0vwA09r7uqKRZ8wYAgT9CPFvzpQ3zKt
9DTLgQ3rZtFxx2nfCug=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Fayrlym1l14Y48yZ195XboT9ZQmp/mAzUyHby3Y9qJTzDF+m6mRQ/ZbebObo8bu4VAm45JeETPx1
YI4UZNOK4IqKv0BZsAlzUfAYAmqmkmIJYbn2gWUCwXyKX5AoA4ONnlxEHxzZhqtsmEXvxwTEs25/
R7iLzeoMfmwwNHgPNQkteiR4zDlB76CYmgu6EOSUX5Nnitq1oh7qRuU8WqWN7lLfgIC6T7qNHwGD
RPze2yiP06fSG45jPrOn2fvBX9SRbUXjNtiFgmqim4anwJU46v7y3ubit/I6giZhz5PJMZfkDaFX
ag+uCMq4Q8ZEolqMBmjUjat86BdVd4Nmr0yUaA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
kIpxh3qIIkWUg8aLJSPKvKhKTPFH7T8fisti5RtNaftS7xh3KDsGLYnF1lYhH2RVXgzbdaVqvtED
5QJazVo6wUFI91xgFeOR5jX+Ny5UBUX2MngsK+UZyZg5+EdtSiDtiJNtQqgjq1Rn+XQCGF3xP80n
7YvuVMbgRHCAfWrWw7ZJ7Y3raRzeIkx+koPFio7XnC+QdRJ0ItO1YtQgF4Sg1Ihr5TH8/RrNn903
kPa+anH9spo3SFCf2Ts11UXAGLdIBmOLMtEAKjjCUbtmjGSeSc0gn2q2I+xRTFcegLevlr/iuLTw
3lFndBAoW40xOiCDjWZ6Rz7J+jZhsRl3D0Bhwg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
FHUOCgQO56FvRtYvz+ntzx5qZnbqg4LxGI0PznEOAffkoz5aJA+1T9qncgWO0yVT+xFdyI20q8/o
AO9tJKSd3Lf+icpFbObvgjpMzMOX6o732mtuath6A01V20BrD+fHY+mKtswsCaY8qEAGqSrdvIyC
/PtVM278V0IqU4R28NK8CENwE6IsVf80zpEEX0lpJIlrbJyRD6Rhs324ymdFDgDHwMoqgYx9VCQ5
UoQiGSz1CZ0DyJSbUochNqSXUW66ZVwFw8AYFhkSkRh1IRa2HASehjh426Xeut4VNpcqnY+Hl0K5
do5AS9n6VIwKd7qWtuo9p9S45dP8B2IvAwBG0w==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
5SVLZ+4QBzTrY2ZFcwouC+PhsdGHtrb0gwvUwEO66dmMLr4Nr8XG+GU6JTfe+ACBkghY1dQgyZFS
Bt9gARiG+qu6wquivjomqxqfXuv8x7V50Jc0M6rGdoIYQpbVd/FDg46xzvXtbat7Me6W+YoJxdnE
fxb+vubNJP6ve5hVu4i9GxK5oR1IDOy2OarG7iRfzzrXBCUqaY2W87wQ7++j2zfQ+y+fwyDW0ojn
o+vyTWofjXtNjpSAgGxEFU8xJOTgutaImGX4qK/xGPH6e8SAW4hT4BPiJrwwyl9oxPNMDjLILfiN
pB5kP36dS4wMlynXK+GgR3bJ55W752zyuCtOPQ==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 17152)
`pragma protect data_block
tl5WK2pxw6A1IC/mehKHgGlu+oY0nRAdNSKO+faNauWgHbHorY3ZV28zRs3ufxHsKsg7GnmKb+ki
/T9emEcQW+iwIyv6b2JJg9M0nnaBIg3BaXZH5kg0FVPAbphqHJ4s9mO91d0vx695d0N2vus3AHb5
B0d3YyNu4lXa7wutJxvZFMYVap9pCisbL22hGyDpAVQwFVADZzoo0TsNG7p7d6YIyR4NitJoi/H9
tAGs3RUgaoXDAMfgzOGIhnMQ+16r3mWLtMU2DmMA65sNT8catSimSfzVgX6ldXEd13NcG0hMPkTa
Ni5Luj/+cTsxeOVtGOaDR6c46S94lGwDYc0HPjDrlblhjY2YJIXKsTAhpzuWZpot12i1GBAes5CP
oyVywd76CgadWVtwSLvPKscbW5AceXMyFevcBVKuZseLWLJuNzzLkO/LZPdmTPNl7/EycezCO4eS
t7BoqFQgptF4eyBbi23oRi3pzC+MsCOtvQM+clmELupY860gxnME7e0P8BNVmDaJnAz+tai4O7Jr
sueFCIOUqBqWFcKLTguF56ct/5FJWu2lDAEBO9ovJmrS9OZzzIUz5fajUUbUyH6yZftcItvjMhCw
5JBwo/TQ3rNWWNhaQ0XjN7BN5s780uvCg3VDIskDxLRq0fWB/7TZC3g6IQ2KRzK5vzwrWY9fURH1
A2klkfzmeSebsSSMbk4sy2qSiCZqYVoGp1Lzc/GnjlMxQKZ6tRlRa8S8JwUPtl5U2ugmN9jbYNM+
OQ7ZJ08cYYe8DShaEN7reqGVxFDMaFRb/wwr6V3NcnFl7mKYZPotiCrd96+2lYzeVA/cwqEVarcV
7LsBAZr0h9PJYqDchFwGzapHaGbX3z70ouOl8IKtHlm/PF1fGs0BzEFWdM4F8oJElkmX6sQgPOiG
H/2vogR/CcF3OzdupgXdUIe86o3O3rY9fag2wIpuZqwMVTjD6FXk4DQ3zUy9ScFJ1zyCGtD86ffX
k5lLHCklww20NAkyHKtdXlsSyuNT1Go8QLkBAK4chFYgMTUgjs+TN3SDOYsYmcw0ojAZyf/bGfmX
w+1AECO8NRczX1fvM9K9AGfU33uBBT4qvO1WQvJ89RYGSTod0lHFYD+FlObEg6VRkj9H9qepFURH
1eQDPoLwYcCMH6ENx0NJtZKzq7J4PkF68ntTSuW5CY63j508RPOqnusmegwMKA/7R0Rdl+WTnfBC
tDnxPyZt8DitECHS9Hrvn67CqLF9mdPywfCDNmV2JzFtstkmkQVdRn3+mM1uS6ekJk75WQKMDb6A
D5GmS85HZVRkl0axQgASF6IL3B6tQ9cMXfWUmwmI+drMENs8MGaLral312zJfP4VIzHPDI/JszRu
BXDf8z6Df0spXsuejAFw7KL2HHjl3QRqeQ96yWFtyP3uFF4qwN9rzSC7dz+BF4l1wbdN5/9kokl+
5AcbXRo+UwcmFccI8v+v5lFLvD0W9lASKMGWlqbDy/FlEBrMrZF4I8ZcKxuH3HfWfAT3FG4RbX6V
uLqkQeZ98/RWr+MGWqICayHDXWmjAEgyz97H4ImuYU9LPcK0YjkFZkMms1dCJzMIPy03rem7BRvP
Ewd4CNCz4fK/PuTX4SysQKee2eqjfievPzNkao5wBgr567PdkgwKU6JLN+RRgz8mS55PEumf6Aud
Qf/rzYvireIZgzV+zk1YSmRL2cDu0kFQTtkK6tCd9jVqO39SH9rbLFq+oIhuSx7zajtreGmr9vg6
NGypOPV//hAF+0FFRBIdry803CVFe82Q3MVYEpdNWS7uk+Bi5bDQ44Vyp2/CzPMpirD84sjCf8Bd
Eml4vQOAzwNp+NB5bXSITLYmMeIcxxOZM1yEmufPSoL7AV5TNK9/rvSAVYOx1R4KN9+MkHsfYMpM
jOW3970lz8BreWW8OI1sKuN0qrqu4wA8z5WNJBmWlbtmhJYFAxm+XbojMhd5/uVaquH1QCzJb35l
aRT6gIATsVluBhKre+FbQhjRbPPKIYmDanOcSzabom3DJ7Xe5g0OpcbIPGoQ9Iktbug2y7AuLjNI
pzJebMThs1bxWLCIgvK9ruaCaS6cVGpTVEKzhg3ftGXn2Xmnph8yUHlK9PTUoAP9uKmLxw/onjN8
PKbmMRDdO3TWb2KSWjfWgP/TA8IkBxqkl507gmB8RQ/auwXF2kueip3G7DDjQ0M+RGqgQSF5WqHI
rVlraDnVFoFyaNCTz8ALao8qnM4m5v0PmrhyjFOUpab7vv6djkZgL8shvi2+eWpA+HM5jdz9VTvt
Kpil6Psgnkw3nkufO5kvQYFKJIMNzovrDM9xSusfBhoAtpKje4AgS8O8jm6MDt/bHyuEm5FTGP0M
eWRVKk1OPg/VvGzUjxRCYGFf5QPDx9fvgD15LrOJtnTnn22Eyf+kDfUIMYrlCztad1iw6VttOCy2
uViZwwGCBAQoUVYTO1PsbnLzq2M//5MlJEd5ug1v3IfmDPYqe3vueNT5R8qFKkUAzy4N22cuglCY
IrdY0Mwc4oI0USa+nfbJRnbjoj1Qjj8EtpV0F38zANG6rYjOWIJdewN/Z9eLSyxAR8aUEW6GQneP
Z78XJbQ82bCX25/dk4wpZ6yNkCi2mxEUizFPHLi7o8slEQotrAb0S+V1nTr5M5Wqc7kdHLvIGxuf
bmDT4dni4J7rxPis7FeuWQhdbqALzku0QAwwdPX8FbFqfVrlqMYhj6lUhHjLtWEV9UQneo2uJkiR
f3gsk+gl3hg7UVYXyW+/6NCDxyAhKCWw1e1KxRTZtrNZDX5tbWWcB1gjLcyYaeEBu3QyHyFoaOtO
FYeJPBNfYqSLykw1aKHFX7K40c2xDfSGuVOCNTyb2CY4l61vddtxY5viFMOZTMR0WdaFOJF88HIj
J1rEnO5I5YKITuCe34UErzdJwQnisUooAGnedOKdyHjvs/HD6Pcr+pg/vWvzea3HY6Mxw3c6eIAj
NpFr+tzlJ8MD9oSITbl+cp3Jiw9T4K5aucHeZLUePegEYdfKvw8z8bfCqJPd+kYVY8FtNxRdTYGM
KZXmxUe4fWuIcW23/ZFt6ZDU2/t12lR26/a5b592DJJNvPoq8AIZA3IASVnvKUOfaPlSQXALIP8d
/2Mxg14Pe6OKHwBg4ubs+unkc6tvrdcVTmBm4owRektofK4KUZZX+WKxOLcFk4DcwoWlKU3wQtkh
0jfOoSmpKFZq+CB6JuRgy+09gCAw8xY1Y0V4fpxzAyzi+QbqhXV67R1i1BBqpDBL2BS0LkZHv7AG
CQMsak9q45OUev/L5avFGu8Aas4V5JU5pUhFrgvc/nLwA/TixozsP72hAnVrMH6KUxhuTMb1tYHW
JJ7P729jt31DflefhWOufnomiylgPSLO2YLbvpq8IzARCqZ6EcrF01haUUeJwhQlkGyj87mUvyeT
TO+gZFRZudQnwKeYwFkMvQbBZRbJ/obuvOCHEYNy/7iXstSLO/IRLQ9BuVrQt48UYV9LjgGFTi1I
dErrOC5MDRndn/wP7gmqXCTe7di391qUYLQVYpznkz+Kk0Y1xU9zqWPCo9Z6IzBnvbHbSpdFPkPN
hnBIJvq6BhYqR+3XsHoKoJyXEm8af/Nuwon1E4HKv1G64Wme9w8dgX7WsTBcO/Iqd5CbKR7GS7bi
9JL/dTAE3GDUXcpNh/V8LJWjyoYVNhcMIUopsPdfZKspp6xJk/282S36SJ45tXYtAyRG7TvhSNZd
3INfvoffRbIZg0LsnVLQx6dC00T97pB4KZHIAcPm4bHw2G+Itd4xBhUD83UVEUFN0VrwazQLZkCp
sbvQdTXrxhvRQ2y0U9dabeyNvcZICTXfagKGynjO/h9tYxhKzZCBOw/xIawCxM1HO6LRKHLBzFWj
6bUn/B0gIt2chzTR91js6Y7hvrtu83k8N09thAgKr3II8NJrm0QLuqO7DUVh4GlklOugXVDVe6bb
MOcAJuf/+BFUJWDAzISv5IbdYYpzXdU/0fdzpdlr/jedcZ8Tt6+j4ZRCb/fpsrzozf7NUaeijZxi
1+ZQ9mGzgRIJZa3r4eTr/VXFYYEXID2K+0n/3yUJiK278yWGJNJadgboIW1m9fUtSdtGOfH3mAWH
8RTE0G2lZokShpC00JbQwp54WLCv0115zcqmlkTSfwWUk0YJkbT5H3y9NQfhrO1QD2KR7FP9aupw
kv4l6skF3QliN77kPueQFLWdnBap0LC8+XibSnyhEA59P3tWapCCmc8cfVFnLVVNxjhR7xn7bKhE
bUcLd1BEU8PLxK8z0qC7zDfPVna+zbht/SChJeJG9fBiTczaFwH5qacTfDu4fyVoLcdxrqMH2DV/
noesuz4xJH7LCrDaEr5VCmzGTwLVCRozD0be5t9KHjAFiI6bi8yRl7kQj0FXU00WZMpFWMrB641+
Ss5fUbuQgCwsGoIIUvahbc8KxvibopOqhD4yhe1leLOVgosXdkVyLK067wXiSyQSMFgS01BHmOOZ
GSsIhBqbbTSpl7dMi7ZKc3Cjcou2Kvkl5+jspileK72gnlIU7pPZmD28KUhHtzooNG8it1CP4b36
8cUtjrViaXwwBCM4eyCZNFPM4yQ16L0bI3g1srqAXCPIEvCOW7GgpKUxtoMjAG4WRisIfYQmhBuX
hCWN+OamR5Ej7ErmZuf9tlL7/JVFikS1KSKdeibtRG/xgrcScIThLvq6BzuRNvR2Jw7J3o00SYY7
RKuv2Jt3CO4Ht7jnnLgAiWZFdPvSsQ/ZCHHh/4kJlj9f5ynUuS69Drq4xilmDeF6Bn9XDVXisNAl
rQlJcw7c6OSi1wJ7R+O2UISKv4k4tMNzv6REzl5BH1NmC2zZoGf+iTiWKE7BbTzmPscSI4TtGEwT
Qoul1nqKELK8/vMBmrfiw78qyYQOgAxDVnu807wWHvrZzmOwHcy5xRXo6L8IZUkfKByCsfRpK/CG
f7ULOR/sTtDIlFCElYirSI8OGzakZY+EGcUc0sXlXtyuN+lg2BmYvTS43O7I8UacGUIl/xz9Aw5v
1uFK2fAs14Vh/zQzXKfEMlOVBOmnjSLhwKSPchr2dXsLr3RPC30vDO+NOs3cIqehC+LDY5a9pPn1
7SX/EOl91z3B/FdQmDQeTwBf2uRd5EZcNz0Y1k5EUJFtgsA4oVwtv6QJdFFQITHZKOxCS5rccfL7
s+SipzVQEmDz90eso5lb8QtjNyw5lJjF6J+hNM9t5aJeXetR8pNHMrKTajmu2BgpGyDkdffVpLcp
RfmgompFB2uyENoL7h+rjo10HIcex9K/2tj2b/xlf7Pk34NRZSLlOVDM8G1qo+J4S48+Ju8/M+Qa
uKnoLbfxObsGNSoCnhn1uQTZRF/Yw3T33uiv+aTFpnUyqMXC56Rwq8nVr7zFeHRssc7SU0g37ECX
KNV6rtUe1Z4FWYVZ97A3V5gCc3qPxJRmoL4fZZJZ8E7afMqnN8MkdxTSROb818nR/fjop6YrHwHi
DVgaiwPJN9Kz7jZZU8jchirL6LzzNPIOTN3KL+YilDNz7F/6yib3UtppIrl0qnn7bm3/ulOvlbLr
D5qfu0ilrY8Fb7XuBV7d2Ij3z5wPl/1xWFipKpcyOy97lkMqeYuSk4H0qEbdYbT2ZkB1jTy4Bckm
tfFSeiFY/A7/13Fu5S2cRGsJSic+ApKkt17RsAjTgUo1gSANKVoj+6/slPQMr/Pbu+IN/q+NjoYb
xIZjIHX7DgAdvyiHtZn/riKRvheRrLI+KkN8TwBjEG1D3lBmmlfaiKAJkd9i2s9D9BBHbbj4yx5Z
ngUe/XinpQ1xL6KqORXNnAftKdm6WR/1fwhGpxmNclJnlwONcUFiBes8z2tXcx9/zW3P72rgONpG
zmDEwGCLn/XVEpmsFLBXEb0nhvyguun38IoH9GshSJBkGfbbSGSGokGCM9kOsKGxCXhrkIXtLo6f
o6Gtm1LRVLah2n+ZCrgHV1D+jFJu+BISPKs0wNz9bcbOfvA8OWJTouuYwdHLPz/zpdFpjDGRXwPU
p+6l698XQkpGRh/UVWtF43As4ZsNCEQeQXxq+u1USQbAol8XoLwTyZZtSGFDDgJO+kVtzTokBxOE
BvQWVWPbJ2XQjildmTnkgq3m20FJurRqTac4fC13O4xzXhkt9/aNVFlUoySCoqqGjQrMGteb9UeQ
7Y/Z0q4G+H31IklxP9sF8KVIBs83Jl2avRdfYW67FJa7E1lpnnoLBD8js7OoenVm+wCNl1Ck/Iro
cR4z7CT4pquILcfzDeKjlkr504Ki4Qhzxr7N8rzo+iCy+vcKYdrIPeCmE+uJMItKOpmAww0+MkNu
rY88sCLanFQxmIXKyYWi6iR26Z2OgqqvwFVnkzvxfQjZ9C0lZi9IhFnlmkokIzzRjvueXT5lemcI
Wf9JUQNzQk9Wj1YXOe2l8ng0VASCVXc1E5Aqb5Bs6+7s/zkPGwEXu9F1dz+8OGjRzXwwNc2YR7jU
FPT1fPcFqxajemTpRoVu8dIQoIfOlEQWuIjrAfPsigsDH/DJghK2whmiPgmFgNPWp4Hf0PU6MhL9
35yfzS4uUuEijBbYGBTlaVqPiHJ7Ht8H5GmMRRrXuUn+HIwJqSPp7GVreCMMZf2MT+/I3TxIytyF
G0TijQ5X1qgUCnfG6GkfVpecHTRtxj0ccrNpdx6IAAbw2bhZ3xgrA+FV9+OSBcMrvS+rzsZaVLTv
Zvjv3EVMStWu+wqTL+HYT3M9QN4xVzvJtGBFSu8DJVp4GKboysea/QyFVuQuzueQ6JG2KVpBYsUG
NNn/rpcaJEhuCdZKZ+kglgPjasRwTTntxeogzdVkntNvDVFby6vbM4eK0LD4/J+GNihm1ZGUs7RS
3tktxN2YBGx1CQ5kNYAZ7NG3o9oEgiRsVr4pygFSMZn9D0uno+xCzNbFiS7oGwTZ/tNy2HO/ljr2
4t33ZXG6C6PC8KOe8UFIh0ruLCyKfy/FjhYh4IJoXdUv/CjhwFimUsbiLy2nsGRze+jUD45oTklc
zLge/+WcvcAQAqbBfjFe6cjecBoyn2tnmAmSGbzOjC7IIhK59NT9ZJo5ys03GkJYUR65eXvQOUSA
jDARzNPmjSQyeHg1IwrRSXv5j/Sa5qvA4AzoN3gZZQvcVnwBTGfWRF8Mebku2hNqKvJSxflri8rI
YNkPkCQ3NGlUxXPG9ekvva3O+CAB1Iau4IG6AX/bzX0/SEUoZJvFYir9bM78zM7+56YM7PRPZLb7
kPXLxh3q7chrWU8V2z4ywslCIQX70SY71YwsQzlnCRF5XYRTGD9JueJwq7zQAWzVeodqM1N7JuOv
E+ILeuk0MnSD+iVbs8kq02KlOiWaMNfgSteOI7tWcW+1T1X0yR4kHpDXB482SbgN+P6PY0vWifO/
q7ERKZ07Pxel/90vzMgyYri1/njbahe6NTTbE6C3aAp9v0424YNb5i11kTcgJPD8LNwlQxEqHs00
37oM59lyXaQiF4OUdbwUvfNjA5pRDInNu87rffmrfJ8qtDcf3I7fKwDp2snv17mKGCzX0hVC2tBQ
BffaXYJhkIyDCm2eO9MO9D9m8UtNubja4MQXl9NfFVueWOxyF/q3IUXn2n+R2bV1aIm7vkGuHK7t
B9gE2i9raT+NKKs/kWKT13YsYs+IunIioAidEuZtGTx6tQMqHpN6ZVScKW69fdhikYuGaDAr31tQ
Hed0/W9wNr4DUUgBOAQYRkJlKonT5tE8T4GvnHJqE23vBm2DpS3SrJvFxV2YDgrW3MIRFPU83nU5
REIOaCV4Fdn2aBFkNSsnFn0nxu4OTEWV/pXUXLZWNVSAS4DiXHVz8sc9QlGruJdSEzE2W8b/tjaM
skh34qeRS4MgcpJMhJGN9JqTqM4UfYf95jYfBXxfL5A8z7TdkHtHMyXVz/jpQO/VDLCIT4oooUFZ
6zqPvHhfEMJNfVvSutD095Jp7dahgGApiJpzmyX6QAhSBaEnPURmTeiuwgWcbhcyBqT3EnHYIGXk
osYMt2Y7c8RuxyjKLMXzJeVUMHpGAfLqozF5vh31V/1ZA8Pb2zBCAE5ukXTyUmnfhsBUBgCePKPp
x/e5r24ULqq5qCDr8YqWqJ7XNaztic3kBDafVTaA/5ADWox6j/06JEECsWhB5Cg5EWOmXgvRPCqm
/qzOKr5fJMLwjggFymgj9IQS20o2scz7hLf63g+EQApXM5H+IfftIgG0g0Nz+DzoRXnPP/IExZMf
25/Lvo4WNKoYziW2N8MZUDTec1rIn5qlY1sutHi++P2idQ1cCI+33DGnJ8nZfxE634wFzDuse23e
HU5TrRkIFYLkNICG7ArZt63NLOvlpo20ZDbBYzF1hBLNUkNv0+3pPvSCSa9bO0ILLn95zeOMEcWh
v8XRUVEzeBU+LtzhrmPDOqfFz+dxOG2bMP5wy0TRATmYc5DrNB8diD9zO09yW7aWwD1Q4KjI5y/b
xdq1SfG0QQqdYPEM18YNVnP0+qrFMXwQDtVer3gvHQWfI+vy3X3CR4VKhm/NV3EB1Ujvdr+iT4gm
YDHwVe9AMzx0VIz0AjfLpJGlSDvxRNa+XG4ysupZqM2fbM9nKRzRIh1tB2HlYZ1+tUzjooOBdRji
i9gLFWZmlyNY6KOXcHWkzVS59987oPY630GZTV0ErseRBvLHrpzsE+0o67dkwYMjAH7j+4l/Hdc/
6KmxHBxKapMMbdLAc8KHYUDuaWbI8A/QC6Bb/OnGCfARdhurLKyJZeZKeERJJReWbE3WeQvNkfU5
mgkLDyg8X/3udRtDRYqDQoZ7qXF8B90doKlBLj/2a+slJbsL8y3GGXbFwnqpSE1mlPYmS+5ZOT0n
YI1O85afLzlGe/ANakKoMSlPcb72XSyskP1ackkTcJRg+ot9Qu6QKqyx63YicHYn6FiN+T8nYxpU
SbZkOCqAxRhg00EmQpguZB5csMYGqX9Ok/rw6UXlLIvKh5VG598p7YLJvzRXDk8mw8YM+Ccqc0S/
bc6RgHKEnUoBD6sOX+6bJqOg4jPaVZqJ2sL5BX2qWZx04KyxBmfRqBKls/hGZaaBMuyJAF2v5UL/
rVDrzRu8BrThi/DE/vspuIa0raFb8kQfj12EsOH4GHYa29+mmVfMkJu1A8YWv/YddhYn8njti7eA
SlK4RjKPT2DC25DzwojrKr8hOc53ZO5uQOyLQQaXB080LZwEtKcH3LInvHP+B88g8h4wH81Pa1pg
ziYHkomMuRwEe4CC310Dhl7wMbVJ0jJ7QjmMWAUyrNzvZ/IRHmLRLs1a83Ulcy+qk4Hu5hpRGaf4
4ZUh895BjUf6KkX2tKrlaSks1gYJ4jnS8OlOMjNhXxbKPHgCzFE7kLw01WpZYd8kONOqYtwJA2HI
eQd5z+5jXW0jPQmuIooKHqUzukkbmqPGHONZwE6K8/uV2c5OakaGfAF6DVuZFuTB2bq0Bb9Cc/FO
AsUbiFCtBfSypWHIHOlbDXGQ4nFuD8ss/x5j8FWTcobvXJdL5JF0jXVpAuRzohF7L5nKfUKeF9nw
B7qRW+9SDOj608LbRl21ccvpELUTQNvioX3whakIdCAIu21229Qz05vaBX3sGGYjiXxhXTb4X42i
0utxctjEzIONa8rOJu0xoBa+9A1KQmDtDsVB2AKBP3ewtw/2VXUiqI6a07JVF2cPwtnf4oYa4Eqg
VsR4kAs38Dc9NL2AfY5x4XXpI4RDSw1QSBKGnMpbexT6Qr4rLM6LmGdr8Wl5eQLl33Cx2LVfIJCS
H+24t4ctLI+JQOctdXAPk1iw0aV8fzKWxKQZ5Nw2M3GETNlae122MSDZXSdI/MyhK+7J8iOwYe3L
huEm9Y+M1bw1l+N6aRlnvhmclGhAe8+z3h2GKn91U19BxaxLkiBcPwg0Hn1xi7s9LCtDU6mVEK6m
lWAIGHm5WKPheEWIRLoTO2HiWmzhdXC1iFq0czNbw+iMWTYsbAsGEIXW1GxRrpYfZ7unv6Tf5vgM
Tw7T3jdS2yalziJbJa9aPn4+3BTA3E0lrqDKBmtozRgIcAk82z/SEjETkMXVxwfsuZd+PSd8scz+
NTD/0b1FZxVJWozJWhGiv4ogHHcj5/QbNIMAn0fqvcZxESbFbzTwQ+FMs0DmRx2t3Mcwf3eLmGcy
RYLkgV1FbM/27mWQxruuwNRknBCd5bc1OJXdVN9xM6NROUPZ6KHK/xH4idOoaC0hgfiu/1DPphvz
r2aOpF8jDRDQSMFhS25Mb1wQbEAPB9L2S93j1n6O6P3uZj+03MxUEApovI10GUz+Alu+vhYJL0sN
TDDRncoBi4MdQibypBZxE6llZf+7simz4i/6rbluyXdvWPMYFZydFt2w2UYqz268IIwGgVfej1Us
wrMafizFywt7PckLCJn87YUf6C0x1ML9dE3saSWRdm+df1qZwWnamNJ1DxNyAMESPhftxlex1gDY
R/081yqjOoiUj/RM6x93lYxjiwxYxpCioz46dMoUYRVkJONxMVzVpmKwEUanALgA8dPJ7XF02QWN
kl48YHvdVopJQIuaO6PFY8dm0EOHuZqlOvKaa9tdgw3p/bDG6gZAkAsA5UhnvMpCb2FbV/Q/8gl0
lUtoisue1XJZh1yMYC1ZcJPv/lacdp93htf1X9K/qoV5r5AHqoJjfK8gNdMoU14WfahPHpGzXO4w
bhSwqVExGJVa8TIFRGneUmvQYUv0flRd6ZprPn06cIedsWiLdDxWHJ+G6fTvWvwIEdAAZX2nCyy7
N9NakIZIREvCYmPFizqPnDqP3FyO+lA79T7b+XaovJWIZqtuVZ5YDoeamWIfcgniqKQ2DNVWQVbS
08fEmkthXjFr6mylwqc1P0PIERN0rm4t0uQ4zeP6PmzaLba/PC7f40WfMHG0GEayiyMezQuFQ49a
gnYISPdeaHBIpzO/mJnm8PrRJIXpf7DXFTtGSKSeZuc0R+RH3HNuPngySvBHQi9mH4o42m/CnX7Y
rDTIOu+wXVqCyWJ25u4kLidKgkw+h491GUNHNX7zfPbiCeZFjXtXhQktjyM0McC3GxKbKRAI1Fdb
5G2PLeq8K++QGzES5RtE7OPm75BRsIikN4Nfl8Xc6di7lhwNH0M05hq8hUYWawfd1P4m0J61W+1i
7CyBYcQqbyV20dVLdt+C5vzS/TEDUd0DY8QxgcHDq/iBwaiLWrWK3jMMVgdO14gIbY8SGmP2i/Ri
L+Qmv+gSh9JqQReFi+Ts9OpW7Lbb3a8HX9J0MK+QVgdIVGO33NPwS6iSDFysq38UCe0cjfB7Ck6m
dxMpcaINHCyxod1hhvwZKvsqSOUq0dDpZjdlyki61G4BlmNXV5FyeQwGFh94QV4trIXGPP1do8St
jRDxUCOVazyhhRvBJMWbUCPYceFVn4oK3ddfdQlOJQo5yaBxtX+mWsdeTqmpZy4Brs4lKd04j96u
3SDWVLUGiLTs870okVXrpXtnzno1fIDtkuBpMZsdYqsbWZ4xT2p9yEzp9fMQ4d8//lVXXTPij5mq
v631p8U9Cgy/shZmm9A5VZIT0s3YhmppRLZQQfrr4ojGC3dV/g71OGasmpkq5Wwlce5Hu1MvUxZz
hBhdu/cdliLfulemBpNsAXxtAW6RwdacN6yGcU++2ANO1lZSreItZhPadnHjlspoIZL8BEXvaimq
T6wpO1DCF4Da5/ja/S6xAI5omXwpxxj1rvX/g+b4pc6j0GIR0n6tRp+hyiznyuw/k1cZW3WbU/SL
eNF2ngnb6b72zBFzEqGdE43BUpTKUBqpUvTwbsidW3ka7fgWsN7SB/WqAqt8Ly2fy9FzkdYPn2jf
2BxR/1sVhHZuS23WErBkOIH9tUiQz8QZjJp4TvqVVO29t/JsrwZeuHWLecCW9Ht5Va64fIgBgg8m
y8NDreYVNBClAockTYI5AvbdF/Y545Vz1A6XYcq+0SQf0Pi6QZVcchA0IAYO4evRAavP5/R3mnaQ
XZIA51iPDQ/JljkfHvGH+JoaazRmJf5pQV6WvLO4XE7ztMX3D2wtfsT3jnY0/j5hB3c8eeW4PO+8
Ddn3FV+1ziW+FOjH1PvEb+BZTi+zMj+uFX/ZFmyjEis92oguxD1d5XOnppDeADcS6uXR0q89t3uz
2VONrrcIDtH0WPj64L25xi8ckM5yRzDgFtslppyJn0dHfkQivj8Bk4BXeNx6efuQAAka3BGgC+LX
Yeo3e72YRP/6IPJSuI2HvQuc/q2OS912HXmZIJDTZHdjvxZnpinEKCWvfCnxWxO4W9dfvdfEwkgd
Plm2Utf1k/Uy858op1evXxFwAhWiDz7eDMP50WjUFS4lNPDu7e8IgPLxi2JUWxYDEKCeOvJtChEj
kkU20KU+JcpvvVV5ZGSlG8OXglMW8U0zxdRoLDOj5bTBJV1g1AWHMkztXqPqZC8iblP/7RQryztm
fGd/tXiwLqeywrQV7DJlu9QLCI4o84bH/2DZbPbgh3+EgE7rBerVaErTuo8ycGEL52OHRvJVtSVN
knYNnI9sUWvMSkFytK0/KEE5MdMMs87LR0yjnZIcW9eo/vbYXqs3U85yenvC7R6jNZABk4V1mydx
Le8N8cvg6fopGgSc0WxwrTjoPj6yNZ7ytjL/VDEmGQi/uky8o/xWGB8kzZGUQRnakmcHbELvySPu
shb3hNjqIp274bc6iGou7sUGB83AkPNzMMvyCtalKACmzHRdSbLVeV91mgw0FJ+pFu6Qqir51ppa
JiGeYjFVrkc4rr2RyvX7l0PCgRDwvuxptvHqbYAFOCDS2Sl1dkFZu1zFlv2PQFiITt/txGO8SXEA
bMRkfJdFhnG4yI+0dGY5iOOi3yy+P3qRsl4gnCgGMQdS6tLvoshz+mFRx4jYfMYvwCT/yEvUWZEr
ojpDFRTwZxhRosRQba2TkVneHc7kkh73ypPHo3sPjPoZZbO1hpMVUEBFN6COLV7slKmrHDt+fudx
cD5Xmikrl+4cvzC9+xAZmM4DcRtZkP0Oi7B3QiJqvhviJZqJ25XIzap/Dk9wD0P1c7WokZ+U4pbD
yO+PhPW5fgwMgbEdyLi5ZF3uYLsUx9wOV2D82jOty+IVAQSv49f9+hAjHQR7olOc+dfUkxhiXE6w
vjsLhtMD2IItZ9niJJ8CZZg+OzqH5qP07DxpfXHe3+Gfm1XTt/3tYh6NLfDmYtB7n08uwssF8P9a
zsbhvVimGg/kUKX1ybOJkxscZeQTi8SVAwnzc+onKXQS6mn0tZZViPGZUFQSu7XH8eAyEoSExrso
7jJCrVMFSnmKIYOksQsxIJigBI0lf3GUL13xjH1RNTqlSfR3GC9pyMbuWgInYYnsDXh4p26tzcDK
wZtLQfJwPvRnkrKipKH6J0PSdvBa0VVIJaY+/lOISnuQTzIqPb1qjcUhU6R8kO6QDq6XLGhw2HDl
yOfPJGUCt2VhDyzxidU1lsuBE1uiIHpYJLeyPgFIoaNtuvwtvLBXnzpgeFd4Wuy2nqEIQLB+WNkK
9zpZo2vCTy3b2Sdl790YwhCsEP1YBPpA/MnMAzvoJEP+I3hHgQz1vjiEL7agtzBMgAf6Kdoj30W9
0rWkr8W3l9TyW2D4WdviHNkFJBgLySUkX9a7wGRQqWKv3YISPtJMEYi/Dw8795RoJvUBhZDI3Gz6
VJkAax3xC++f/H195uVtWi8wnutvdl5usFTKXmJAO0uwTqJDyJVnssDi3eBOKFBWl5xoVgrSb9gf
HmRclHZC7db7U0u3A4/ye3pQgsZ2GY4Pkubn4P5OnefAiBBr2G0a22wU9fJMZdNrvkQfTcvIIPAZ
2IXK+nsL/2KPPXMOI6mNYxGyaSq8j0vj8EBvWWWn0r4gjm91eLWWZdCr0Hh3WcGi2NhL2S/ZANgw
E+gI+/cEJGF+ig/9WuSGl5Sv5IDkOPFc60UuoKK/Iy7CAZb90ddu2y4GW6RfwiJPSH+XbzhicUyV
FL9cxsEgfB6o4RVg48MjOZjQmehkvIRH7HQ5SgFCwZCR1ieERQ40TGJwwWmQKvcoq/vMaTufa497
pNa29ATbFfeBmlZ0Z5RDyPbOMZweADSyzzxr+3g0gJ0ktOtGUWoLmU832UGyw9LKORmAjSl7iKYO
bNEBe+n3ISxQBkAJdjrtZABGTQXlxzmE80x7DAZEuYCC8zn/cwlfQLbdgGvSyZ3kJiUAlNZohNOq
o9voIJO/eImGTUTATr9J7+me6i01oc+9nEOMTij1bj6Gq82bM2uNRrw51aUBWY5tvEdv+h5mMpUS
y1kDKiDGLsyA3EQP7QuT37jCxw4NgHW2lj/z3Wlcou6dTbefCNHkLIUNe3a8HHJuMekJu1xnoxET
PX5iBQh9q+0uxDJ+rbBAFvd3sX+WjnHOnyKuA6+nzYmyAfoGjJd1UfaUWbfCJZBQe0RgGq/TMCXb
e91D35R8rvzZ0LUJ3f5J4a5sDfudz8uC5oUMoFWrweAZh5z1X7Ji0+j8TGWavxJLiGVMyu8Z2bGO
KEse6WqYKRkkiA79uUKX2Z6I942JaCh58G5VGk8BQqLkJ1Y7p4qoqDRbGtEgTsk3k8J4jgXw3X1c
3iDgjAI2Bi3oIYR4BKGZEBOMcGB0zPHCNMI2w9G3QzpfjEmTZstV64Ybcne1Qvd6ima3hPjy7Hm3
s+QPtx/x+/gptJoRytfHbYN8tgqBt2+7kzr044rQE6DsBi9tgQcay7kszgnocAGcnpCS+PfB1QzF
BZlRc+oESNKQtK3xuCrTSauq88vsz2sQcUTXaGzxAFmYAEu6NRY+hyVP4bAF1lVSk0U4FRdbwyPS
PISX1NtrWfJX884HWAeafrySahnynFPq1e12GUhBT3auV7mtsrkI4tnegRLxnmgFHJZMAkjFX/hO
WHPsW0Wgu8T4oWLstuB6nbWQ9YeWT9rkmko2gDKUynULtqU7TZ2arbu+XWAMTGaShs155rtPmTia
zVmTqL82bZg6TJDG3YEm2y4sI31VlhZKWddQFO+LFP+HRWCQYMgbOj3Jzqvp/1L/T+84khTcqCNJ
H3yw9HLW+EOHcaNEd7R7Ipui7V5KJzS2hKxgEe/WF0mtS95haWml0GRB9Zgw6YPa1W/VD/dPzBns
gfMVaUb8hVY326Z5NnFwXy/xmWNCeH59a47BerErvPCK7u43mfkOhUjiGqPkqqR+bnbT+F+w7HRg
eNokIETPNZesAgICJB7JNcUZP7B+2sEurGgY6AXhhu1ZRx4/e0uEV+i1NJSpcjsLQyXXCblQ3rU4
oEGzAcJdpDVF8EVIV1RFPYBvHkUTCNzxzWuWvtZVvUi3ZvWGSTX+pay8xoYT1x/6cH8FHsmStc7A
Xaf8BW6NvelGG03WwlJJ5eg9M+0pu2oF49a2XH8tbdSc5FS1OBlH8chSgyNj6x4S6C/QkBySRb2f
W6XoYjvelJErt2Zb+Ni481pLlz2tGh/tMra16Q2XJAviH2bbbB+zjavApF619Fbc4nIzkLG5eVfO
W11mz+98TcAowqjTooMl9B1S+uEMXFo7Xd7LoUL8wY9iAUkJdjbUzIxfKqnWCRyNHR1vaA/cw+jR
5N6y++puEPYuiDVDa9GcR77nalL15HwGaz6XleT4gZi07P7hXgH5vysdLM+7f615Ub+dEGc5UBQU
uvfW2FgDVg4Ev3UyZ4gPNIJaDSNEAhBWTDa6e/ivI0mmB1EOM7LcUcWYIpuW/D1k4JPFV5yvplj+
V6gmavRvilFKowr3csQLU7NSu7tTRiaS37RSiuJK6fLzcaUCkZq2+1nkRAzxr6EVXh3TzgaKCzCM
M1qiZFPgO4X4fwexH4RuKz4w3isObB6Ua6YRhPuB3/7TRELFxIVMyvJ+AOPK3VrDWCItfPC96zeK
srv3nb/4ErZJgXQArFyYHKGgqoZq9VeLfQ1NtkUHBRrsE599lqIVkLTZyjpq+k2JDAXAxZealQBK
5IBieIO91ciutbRfpWGNGYbVk0eDSlpr/KrJJoBPw1iU4toGrKoe0SCcMtrZ1d6A/Lg5vPbnJXmr
zGKp/3Ks25ew0XWcDDapII3BBmXt7uJPg7AJdmSk77mUqnNuzVAyDYfsd6kPM/b6adbjAZvL7u8u
gjc+PXCdP+Oepbs8gT+GKx54XZVaKpa+GiTmqwg0YUACNamYYA256WrzEBt/YR7xqt/MxHCGWvqd
a/vMVduM8HaMb2dOicPyc4sgieMLZQydOOdtgX76VXO0J9PGNhE0nh9Hh39g+OQWP9j3Kvq0oxVt
i9T9ej+gEKty8yx2wVyDg53HIv6CNZOncD+Vcqr8MAnoY70kKS8vuxq88hBtVH/NQfJCrLPKQfPb
PI0UM8Jo8KonlacyrqpjcpHvSoo6p29pKk3Q6OXCTAqWk7AmVtpGN84iNEKK9ySKQLeQWAIaKwbc
W9Mmq8CdzanbI1LqQVMAt4COOD9GDBFg5lsqdXw1E1bhTBU0jsXJjlBLmTW8dFKBhRXpQc4Ed9CX
sB2MHMSwAr6QQ8UMlPEfHnPtITzskW7KKSSoyJ+foyYgtLNX4qjFlmLQisXBo5ZyB2h7XCYgk0k9
3OXPJuezijxc0kRIz7OWgG+b151xrIvzhAuE+ZRrUTBpg/lhLOR7H8PYzdIPLM96IiZInHrgMFJ+
HandJiI4r2XDFrxlcVF/7yLidEpVBriJaFsaz2jl99l6H6Py5zwn5HyJRJm034IR1H57x00YRcd1
wuOXof8ODiao9tM5tzXVflLmgFYhahVX2FtgjI07X49hARWRa6jVIOG5BOSVF3QXsgzaxOYNSb6S
4BE5w4TTkuYmlwTRu33nOzumVHZ+Up6XcKqWKijodDdL8pSX/UwN5wtSJwV9lmZLrtICNTOwCCh9
JQH4pmdTD2t3/b9Kb+XdNzU+T8Rnf+CEJxe1sRCTRfiflHFGmvVZgeZ8lru/ky5o9hQOhzCPIMT9
e4MePRA3gfPDL/qefftzwfKDvKDLRY9J5WCRqO9ZQJu47OOdHJIv7V8iub3bRY0mttFuO2OkX5lr
/vYBTF+PmycPJ0HWeofalwSB8oUY1pkSDp1FsTOIMvcoAR1EABNOa1VMAg4b3fu+WTYwkA/bhVDB
Vybio3qAUh9uVDWLX8bO5VktZ6RpLaQN7P34nUwih88tVt4AwJC9KT6QpoNSX0VYNCjJMkzEt+oP
+6gnfZT0eUYvsLRW05l+p/+snr60Tz1L7IufqDIT+eJcvX1C4Nek0LOwndkl7dIcMUym7RY/I6HJ
VM4lmMAKJk/J2Z4CtfNZ448F/Ha1rc5nELPGoHuZxUFjlf855iZeVpPJtjG2BHD4vuKsOPjxMPs4
koYu8k1yBqQq3OGmyH/l+/WJ5f+J+04+wKYW8epEv8bNlGhZJS4bt4xhN9sHjDVhyzjU4MH26CzD
828lvDqRQ4bfMfUah77IBFRtaVt3JJRYf2/8K+QnN+vhM4gDlaYQL3+gLK0aqpPawi3DCMscAl5w
+Chlu+Lg9Gqynp/CL5SYInjcN1llew0i/GS/XEMuJrhu01nv+cUmpfQrZxbtebCdaRSqaqbfSOin
Ib54egHb7EfdTYIu8oZeSu5gY5kTQZ3zATVJjmyOfx/441vtJFmso3Eyef60M4lTfYk3CO1/+CJ0
TRBUMW37nJlvMMU/LOoiB04lSzbkA5poxxms4gtXg9X2IXnBA/OFFr/abIIArDNhnI7mUI2/6kvy
3KS2M4JIzmIQUCV8b9XDK4225Q2BtlCS30urH6n/5CZ69bc6TlX0KuiDCMgD8xRELZ+7hN8t5YWE
eLd/bPzh0RGnqk8WdNfE885UzY7iUmfuxyLg9L/MufCzAwgJHbWJonkmgOF4GL+KB4rr9AavIGq3
Vl7er7b7/tKVz4rLXKN1drKCHuL6Txdt1G1dZlWjbITERFTWf7hsmPJHhIlzAV9gk4+OwY+d6JBW
pqkPAIktKDtaaVNzwfoX4XYG1NKCDu+Qm2DicmDMNVq/7baKCUN2b2r4VH5bYhNd552t/DJaHYPd
sRBthDNMlWxM2QtqPWWyRQp35NUwNrzafzlfab2f3mJswKWKshdVuv+vFKsuXKO+mPEdtqJAkpQ5
knLhMB+48HgH/8aWQ2qsRZJpG/H4DSyKrTBWpI5XmHRxq0gS5VqlwJMTsdkrhyNOoZ4hP+c6J1Sq
AQzlh+OmclrfN/Gy124wjtu/AH2KTcAWaGwXfhWFlhs9pa/V1SoKebk6nwlb5uElsZSc385azjOs
+EFCEU/9Q2YfTbOUoKBpHjTBSATwdLJl+Z9SHATI/LixkI4yq9Vi/45r6NNOOvTF+aQgijWHg+oZ
qBdZ9wEwS7J0ziB2xQOxafGhZ+lR6Ft/MHbjypZqgRxNmOtbQZUQVT2UcOIZV6Fdh9jIz+gEB9tN
iz9xXliVimkCAI072JZmXPjT/VSvfqkPzJKbK3IfKo51orSDusW1maP++vzZE18jqsIkKJs/rAEp
Gi+uo0lIlsyQ+UhXDsoEzxgE6KL2Ac2u49ZxDW+tZxBwH3dpPqTcSbB2C7YMeg402mEjq1mmNajX
Y0xhmjr3FMZBCYCQqUtUyMew82mG9kcfMg/1PlubsLCGcW3xKNvs9/hiqEOB6jQhFmeHDIqo/uBP
+eipNocBrHApcMNCjKqQhw/bwn2W/gUkPWLm23uvQ8ZDEJGckMk1MK0Pd0f2/6R19xP+2DwMJHvk
zSfkt5B+mFx8T1n7jH2A6W7jO+u35pr39b0zUmjtIDqhV1LL2yyLLSpacR/3sHhpp8aQpEf4KuAW
dyCKIyx3tuwIVcdNxFCrvrvzIfi9jmG3sXtJ5WEgqpF2dJ233NVprGxPA7kYOwKnSUY1ADOKV4Z2
rRFSGERyH+HFvE9im2/jIGtQGykiUVC6ncBTx1gfIfRDibcbeSGb/3x6h7lvEDmAwagIMI2S7aK4
VpJjMfrprWS4Aiqp6c+AX1mxxv8QFBcYObybHgGPAlpGBYFGRY/JHOCZJ7NH8hcPd2xBaCxZF36X
gQgyXeTRPDSjKaVN2jis1ewgIAV1t3G0G5nB3y9Jq01FOf7x77J6Ndlbh8uZkJJwCxBumHKPo5JS
NlCUNF51QFWJPH0wIRBGgaNoHXe8DynpWixe3TDLRXXQcSqScx5qfotlM9mkiyCJsHWo0OvTwD+7
Weh+4ia6Yo5YNpUCw2Ko0Qs5GklSFFjEk4eaBSPV6omKjwhhwhMDKkb0VOzwUVBCKk+v/6iH05iG
PiAH7SS0JLlsNj1gaCYlgIsRbMpuwsGCnCc2Fi5GF6NeeFSEW/YAJqthIJdADV61bPwXHeYDqqPJ
q31I0wZY/M7g5y37s5PRYpLKo5tdVwvEeYDbhKCcuXUvSiQmtrq/5iXm6A2U/LoxfmK2aYp8MHon
iUcUalgi18SrUSiSnnAZ8U6L+qTc9an0WOWBqsDTuQ++HqS710B5ePcqdGJPPHdSBt9Zoy+hDhsf
P+NhI2ZJj3TD7YD0QrlPf9udW513oJbM4Ceruf12XiU+XCFUJD1M/3K0AnfXpsjk+1jPwJpuOlh4
Dx6h/7KaAojhEXS52V4GnXn2tR4q2A1NEQys6b0EjJpwXkltcM8hwV1Rs4qs6oNN7+ZiU1i4yHsD
48wyRbuf/pyzaaqROgdV+2BmX+TUoS38VpgQPyeYV6LlSYTudLcRxpbkLYMHh6sAgeM9cFjXklxf
QhX18j9DzqNSJwDZut58HKdRWvJXI0otOTgOuu6dGEN0P811bwaGo1NLsk3HYWtofBVYT7bsd/yA
CdIuCPc7IxNoYpIQVNA+DVrZ4n9ZlmGqUPxia4JxMcGPoCG3OrJf6AbP5jDNjrGZ/o4gNR0UxG0y
RC5SKmFEjJn6BAt6Wvbd4kS7U9jQhF+OmUCS0U1ldhpO1zv8j+R/g4cT7eV3/zTIhEjmvp7VFrSr
AdQr4zmPool3hOEMJkdemC2RTjzln/3znEsMF4q6f3w7j59xOQHeASENzlkFfZCXscJKYK7Y6yf+
l5u3JmJzzg39qo1mfS+AMWuIZ5Vi0xqz3FPU+gHvGJ2BYlbyxXcFm0BvpJM8STcpGK5sl6CPlsPB
VNeOYIs3C2YFDGSvlc0qvZfOfMKS6hd+OF+BBtavQVUe7Yc0C8MwCVG2bhCKBMMD4OPVX5NEbJtT
FPQDlSC0oFYcwlB06IFIVk8iUzAPzQIIvVNG92tLvejei9voTdP32K5v6FgnJyBJ3iwixGwJCGiI
Pp3tYwwDvofNJQyPghjjEN+1LXwbnxhniQfFZ7gA5dIuyRWHESndrfkIQwX53sP5IMq8rOdi8+k5
Zs/ub2826bY6e5fgJQUajiyYt36O3SLf5Wj7EhUAwe/SibS8toqerWVCtiZi5jrc994vlXbNPD6T
oMQP22YxYYT0jFnrZOPFN+8qV1b4Ba7maaQpmYEyEjYFypmnhHYYl7XTlDuj3lzUXMgQfSGzJbQN
S64iSoBuWcXXEcM2WtUrUF1WxV0/KclZ+dz5gq6QAuiwwAwCXXiqGi1LJ4kmbLc6QyUv5afxzwTi
f9oQ1RPEwQ8qeGyq7O0IMuuCtS1QDhDahHmjQtgrzPCnbWWZ/OPjuLI0ckpO5WmtSTcmXK66xhvP
grgcaVp3k2S8okFCPZ9jnoKQeGbTPBCM248Xk0YYgbe0GNzcxu2DhgGQgKUuwIqP1WufjkIdvRBC
vojR+MjS8IcBMFB6WOppXn/butf9TyYPx+Dxz01UivnO4ahjwW1z92DDup4K9LfSIWOifeWV7/46
uijM0gi9Lpvk4JBVfRnFf/t+EbO/wf6YaVKBY3YEpF/XdivN6L3i8LRy1Be+2Wvb3olurMmFpSDM
Gz7a+PxummIjgy6yoLGeuXzl7JaS+20GOkfkynsGPZk6vVimbMGaWR5pV5CofL9JhuXdOe1QytiG
ehOGqW48xPlezBoQ97hc3mq06QcszPLST+/iSfg08IfbvfaWyLoez4ka/6g3sOdTxBYsAixXrEQM
X0TT+VAIvVf6uivcYOnl8A/0SrxFyMp10N00XyHsLUtblmM4zt6R0Q/7tZPU0ASPj0vF+mxVxZ/j
xygKqV3MWYH/eFr8xn3Q+80hMiIOvAMVbjX4FM1LvMFLq3mR56E/Gwgx2uwLLoHjqvIasQiJLtc3
RMiTUtnrbn1fYHH+66HtpBo00eakyuNTrCB0+ANh99IkKV7Y4QPU10NpRrCk2uwVTFpy/W4+Vj4o
0HfoNb3KGeKQ/IjWJR0LzlQhWTLnQNBSGjall8jT2y8vLGUwubE9Z39SpVWBH6A/bWWQAcdz6NZV
NDdLdUH1D/k0fdiQGEYvTrgoMqgh6MwsxhvnN6ZBr9d6Y8l8urLr0ayL1oGhaZUfe6cn+qxd5crH
ibwvn91N/hE6jVCkgVyj+KiQh22BXBQZSsSqfoRk2eovIDZtf5PhOTUASyCNCBom/uWRYnfje1Jn
wWeQ6VyLh2t/Nq9gW8U6LmG+zZ0abTXnMPR8CLdsWDtUa8nZi4nacUFj9MIh9d9F/oZ6tGgyWJWN
41ChhzZpQnAC/Qxc4Unj2SAgLRt5AcHgrSaTAE4hjF62NZ974oCHWrD95mBrQmfGqmPmk5/UA/Oh
jeszUpUKEO5w9qVjP4HL0IPn2WRyDGsMTMrab9QptUidONiJ/3vlu+NRznBeVapdqIKulG3bPM0X
BxGW0PVbZVRiz0wGZ2Vs+Dam9JsrgR3D1YfrH8hLKUHhMqnPimgolOkdVVQGwH3zxAOvxU7GR8NW
7/AjsGRuTOYSrZeIwnuytgErDRWkdgtBMo0GtLdam1Obnb3Dm9uZvmZDpjvmO3PMhclzBF6V3xhh
2qg7vszqv9bEZGmAPBwnG+nuj5KxMdeH0SF2Jp6eNElOl3+okEDIfoRwZSSiPK+Coqr8EfDGSmqI
Osmys67lqZfZK4DNiUaGE5tbWkX77FVj7qSellYw7gv+xvvGQ0+97WRNSP7iYg2UU8N+KpoBnKJK
ze4pNbR99VZZ3hC0NSwhOBIU9Gvxjqc8fxqvM89mYuR3B85owjSRgUZaQ+6vERD3/0bhVCKxfgBR
dq1lwFEFh4Qe9ECi/MtA8oLvsPFuEj+TWA2I+wVv22njFf9xrMUAcSv11mruFqkUma/C5BNGlziy
8mIijF8qjxkC2nleYCl0Fqwp6C2/oy9Vv9KWtkRbz+EVGi6tcaIM77dntX4RNdPvcdkRVigeH0R7
qA4VI8QdkscA+96gjchiduxalMdfVqD0VUUWgSnpSZ2LIy09ksBsoQ2OcpYVIT1D/+nY7/KrQZ+E
kMK633QVtrDULl/keD4x75I8vqbbgiu0MzKpePHxf4eRKZXtZlr+Z2CE89SmCUIK9fGumLMhIAG7
a4Cz4tOSD4TeeF9ihDOUjLWgikhGdmYquSNQ5kHy3fPuOMkGyRv4pbxokdWpHgQRZ83rg12urQIN
0Vc/idUNtVNoEvtph6pty+OjnO84poAddGHr70j6sCz2L7X4eQezxja54Jnfn1wQyE53RjyNl54s
4cYDIO0Dk7hHlcmK7SCXbdj8kEVVHw446wGp03Q/rRiLWeJWgqMBTzDp6G2fLURVkGsoVIZMAaLc
LDv+xy3q2c6GPRMAZLpuLV/MFmPKvgtLfGKQIxkfrFuK2YP1evW1YdwMgmUpjSUR0JK8hiVTRBIU
bZwLjUk0DaJqLWZ9nVd/0u+SU4vqoKi2OJTb2DyLmyvV2E/uOT8kBBvr2t0liT75KUFafo5mDkjX
5IGwjGXaPCffUl00V+3An98/fflgXVD0nm09g3boRzD4e9MKWxVgRxxMUu84WwezkfNKMnilx/gC
RRfVZX65n++Xg8dHxocj/JbveaW1Y7Nq+b6w32857CnDuISBVJI8watUaP5d/u2XQ+0ng/glzWgs
krI7ppu8FJxBJ79zoAqrpJYwAvNvnDms34BAnBg2mmnVDCw6rV+HwebiP6h9QgFrAwkGNA==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
