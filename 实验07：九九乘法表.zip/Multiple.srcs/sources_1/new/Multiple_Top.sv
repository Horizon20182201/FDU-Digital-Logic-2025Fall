module Multiple_Top(
    input  logic CLK100MHZ,
    input  logic [15:0] SW,
    output logic [15:0] LED,
    output logic [6:0] A2G,
    output logic [7:0] AN,
    output logic DP 
    );
    
    logic [31:0] x;
    logic [7:0] p;
    logic [9:0] p3;
    logic [3:0] a;
    logic [3:0] b;
    
    assign LED = SW;
    assign a = (SW[15:12] > 4'd9) ? 4'd9 : SW[15:12];
    assign b = (SW[3:0]  > 4'd9) ? 4'd9 : SW[3:0];
    
    mult_gen_0 mul1(.A(a),
                    .B(b),
                    .CLK(CLK100MHZ),
                    .P(p) );
              
    Bin2BCD B3(.b(p),
               .p(p3) ); 
               
    assign x = {a, 4'b1011, b, 4'b1010, p3[7:0], 8'b11001100};                 
    
    x7seg X7(.data(x),
             .clk (CLK100MHZ),
             .clr (0),
             .a2g (A2G),
             .an  (AN),
             .dp  (DP) );
    
endmodule