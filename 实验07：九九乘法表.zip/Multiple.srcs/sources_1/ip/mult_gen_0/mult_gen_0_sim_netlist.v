// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2019.2 (win64) Build 2708876 Wed Nov  6 21:40:23 MST 2019
// Date        : Mon Oct 27 10:39:43 2025
// Host        : LEZ running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/19691/OneDrive/Desktop/Vivado/Multiple/Multiple.srcs/sources_1/ip/mult_gen_0/mult_gen_0_sim_netlist.v
// Design      : mult_gen_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "mult_gen_0,mult_gen_v12_0_16,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "mult_gen_v12_0_16,Vivado 2019.2" *) 
(* NotValidForBitStream *)
module mult_gen_0
   (CLK,
    A,
    B,
    P);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk_intf CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk_intf, ASSOCIATED_BUSIF p_intf:b_intf:a_intf, ASSOCIATED_RESET sclr, ASSOCIATED_CLKEN ce, FREQ_HZ 10000000, PHASE 0.000, INSERT_VIP 0" *) input CLK;
  (* x_interface_info = "xilinx.com:signal:data:1.0 a_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME a_intf, LAYERED_METADATA undef" *) input [3:0]A;
  (* x_interface_info = "xilinx.com:signal:data:1.0 b_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME b_intf, LAYERED_METADATA undef" *) input [3:0]B;
  (* x_interface_info = "xilinx.com:signal:data:1.0 p_intf DATA" *) (* x_interface_parameter = "XIL_INTERFACENAME p_intf, LAYERED_METADATA undef" *) output [7:0]P;

  wire [3:0]A;
  wire [3:0]B;
  wire CLK;
  wire [7:0]P;
  wire [47:0]NLW_U0_PCASC_UNCONNECTED;
  wire [1:0]NLW_U0_ZERO_DETECT_UNCONNECTED;

  (* C_A_TYPE = "1" *) 
  (* C_A_WIDTH = "4" *) 
  (* C_B_TYPE = "1" *) 
  (* C_B_VALUE = "10000001" *) 
  (* C_B_WIDTH = "4" *) 
  (* C_CCM_IMP = "0" *) 
  (* C_CE_OVERRIDES_SCLR = "0" *) 
  (* C_HAS_CE = "0" *) 
  (* C_HAS_SCLR = "0" *) 
  (* C_HAS_ZERO_DETECT = "0" *) 
  (* C_LATENCY = "1" *) 
  (* C_MODEL_TYPE = "0" *) 
  (* C_MULT_TYPE = "0" *) 
  (* C_OUT_HIGH = "7" *) 
  (* C_OUT_LOW = "0" *) 
  (* C_ROUND_OUTPUT = "0" *) 
  (* C_ROUND_PT = "0" *) 
  (* C_VERBOSITY = "0" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* c_optimize_goal = "1" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  mult_gen_0_mult_gen_v12_0_16 U0
       (.A(A),
        .B(B),
        .CE(1'b1),
        .CLK(CLK),
        .P(P),
        .PCASC(NLW_U0_PCASC_UNCONNECTED[47:0]),
        .SCLR(1'b0),
        .ZERO_DETECT(NLW_U0_ZERO_DETECT_UNCONNECTED[1:0]));
endmodule

(* C_A_TYPE = "1" *) (* C_A_WIDTH = "4" *) (* C_B_TYPE = "1" *) 
(* C_B_VALUE = "10000001" *) (* C_B_WIDTH = "4" *) (* C_CCM_IMP = "0" *) 
(* C_CE_OVERRIDES_SCLR = "0" *) (* C_HAS_CE = "0" *) (* C_HAS_SCLR = "0" *) 
(* C_HAS_ZERO_DETECT = "0" *) (* C_LATENCY = "1" *) (* C_MODEL_TYPE = "0" *) 
(* C_MULT_TYPE = "0" *) (* C_OPTIMIZE_GOAL = "1" *) (* C_OUT_HIGH = "7" *) 
(* C_OUT_LOW = "0" *) (* C_ROUND_OUTPUT = "0" *) (* C_ROUND_PT = "0" *) 
(* C_VERBOSITY = "0" *) (* C_XDEVICEFAMILY = "artix7" *) (* ORIG_REF_NAME = "mult_gen_v12_0_16" *) 
(* downgradeipidentifiedwarnings = "yes" *) 
module mult_gen_0_mult_gen_v12_0_16
   (CLK,
    A,
    B,
    CE,
    SCLR,
    ZERO_DETECT,
    P,
    PCASC);
  input CLK;
  input [3:0]A;
  input [3:0]B;
  input CE;
  input SCLR;
  output [1:0]ZERO_DETECT;
  output [7:0]P;
  output [47:0]PCASC;

  wire \<const0> ;
  wire [3:0]A;
  wire [3:0]B;
  wire CLK;
  wire [7:0]P;
  wire [47:0]NLW_i_mult_PCASC_UNCONNECTED;
  wire [1:0]NLW_i_mult_ZERO_DETECT_UNCONNECTED;

  assign PCASC[47] = \<const0> ;
  assign PCASC[46] = \<const0> ;
  assign PCASC[45] = \<const0> ;
  assign PCASC[44] = \<const0> ;
  assign PCASC[43] = \<const0> ;
  assign PCASC[42] = \<const0> ;
  assign PCASC[41] = \<const0> ;
  assign PCASC[40] = \<const0> ;
  assign PCASC[39] = \<const0> ;
  assign PCASC[38] = \<const0> ;
  assign PCASC[37] = \<const0> ;
  assign PCASC[36] = \<const0> ;
  assign PCASC[35] = \<const0> ;
  assign PCASC[34] = \<const0> ;
  assign PCASC[33] = \<const0> ;
  assign PCASC[32] = \<const0> ;
  assign PCASC[31] = \<const0> ;
  assign PCASC[30] = \<const0> ;
  assign PCASC[29] = \<const0> ;
  assign PCASC[28] = \<const0> ;
  assign PCASC[27] = \<const0> ;
  assign PCASC[26] = \<const0> ;
  assign PCASC[25] = \<const0> ;
  assign PCASC[24] = \<const0> ;
  assign PCASC[23] = \<const0> ;
  assign PCASC[22] = \<const0> ;
  assign PCASC[21] = \<const0> ;
  assign PCASC[20] = \<const0> ;
  assign PCASC[19] = \<const0> ;
  assign PCASC[18] = \<const0> ;
  assign PCASC[17] = \<const0> ;
  assign PCASC[16] = \<const0> ;
  assign PCASC[15] = \<const0> ;
  assign PCASC[14] = \<const0> ;
  assign PCASC[13] = \<const0> ;
  assign PCASC[12] = \<const0> ;
  assign PCASC[11] = \<const0> ;
  assign PCASC[10] = \<const0> ;
  assign PCASC[9] = \<const0> ;
  assign PCASC[8] = \<const0> ;
  assign PCASC[7] = \<const0> ;
  assign PCASC[6] = \<const0> ;
  assign PCASC[5] = \<const0> ;
  assign PCASC[4] = \<const0> ;
  assign PCASC[3] = \<const0> ;
  assign PCASC[2] = \<const0> ;
  assign PCASC[1] = \<const0> ;
  assign PCASC[0] = \<const0> ;
  assign ZERO_DETECT[1] = \<const0> ;
  assign ZERO_DETECT[0] = \<const0> ;
  GND GND
       (.G(\<const0> ));
  (* C_A_TYPE = "1" *) 
  (* C_A_WIDTH = "4" *) 
  (* C_B_TYPE = "1" *) 
  (* C_B_VALUE = "10000001" *) 
  (* C_B_WIDTH = "4" *) 
  (* C_CCM_IMP = "0" *) 
  (* C_CE_OVERRIDES_SCLR = "0" *) 
  (* C_HAS_CE = "0" *) 
  (* C_HAS_SCLR = "0" *) 
  (* C_HAS_ZERO_DETECT = "0" *) 
  (* C_LATENCY = "1" *) 
  (* C_MODEL_TYPE = "0" *) 
  (* C_MULT_TYPE = "0" *) 
  (* C_OUT_HIGH = "7" *) 
  (* C_OUT_LOW = "0" *) 
  (* C_ROUND_OUTPUT = "0" *) 
  (* C_ROUND_PT = "0" *) 
  (* C_VERBOSITY = "0" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* c_optimize_goal = "1" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  mult_gen_0_mult_gen_v12_0_16_viv i_mult
       (.A(A),
        .B(B),
        .CE(1'b0),
        .CLK(CLK),
        .P(P),
        .PCASC(NLW_i_mult_PCASC_UNCONNECTED[47:0]),
        .SCLR(1'b0),
        .ZERO_DETECT(NLW_i_mult_ZERO_DETECT_UNCONNECTED[1:0]));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2019.1"
`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="cds_rsa_key", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=64)
`pragma protect key_block
HPMPLvpmoX7LOmPj78BMT9X1rCnPz6PdhVGZQ307N9haGfAdMGVirvGR3e0Glyn2ieoWqXA6qOQL
t0xn28+h0g==

`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
Nxv/BnutRgdmHnLyK7kvDGjm7WGfFKW2mxQ6xUKF14zS4ziz5pSV0ueW4VqAzUyEPsErIAEuyV6F
m5KCqRBB197Q2NbZa7O7tdAqboX6tPAJzbB6u4U/MmNS1AQcSgtfj5srMbdBzDa5pR4V3HrI0MRj
0xhV1BWf725FYPP4av0=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
F5KGJgEDQsX2btdjtRUlSmNtuyodIhGXEa3/AXv1Y7qgSO8gknBfiqj5HcIaVA9b4npQpDnNcmq+
1ONAqLeLhdOm9TES+GsTAkh/lClvl89bzfqgOV33iqwQHYIHwSsWMRXT9JSUx+YWu+g6xKpT1Ycn
8BCPsq4QUJIqL6W16fheEHB/lkMgnespIWEYJJG6R6zvv2zG8GiU6cG8zHrRjdvAj8kOkhmiMvSd
YjGXJSMfjw7ojCPSUF+nb6WWhUEmoMA/6lgSVaXRm00YHSZ09k7rKTJWSXFSpTmkL2WOsQhNS0ek
jdTK2KF5K6z2YOK4zkfHgZ+fB0KJyANaLLJH/Q==

`pragma protect key_keyowner="ATRENTA", key_keyname="ATR-SG-2015-RSA-3", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
lFuQXeJ0hi7qnIKAR+37XCSOwp8bGLukonngcICceOVpL87+rxvhP5TyNJ/zXpAWDF0BaRYlGr7d
isPiUStrvUthNyOqCr4vFZyhCdY8n+Mrv3OCvLoLQSarxVXbaKbXb0tPsXJCUdXTrCt9mr5x0Nda
6DAI8FBPlFMAiqnFXnYMwlUiSlkNWUpInuNw7+1eD8kUdckEUV1PDwZ0yjpFqMokMH9oJjN6z0Yy
65D8Tqo288ZMfZQuIimjski+X6EK157XbpyuoZIuYLJ7j6oaATdintgfZpgGzVvhCZtMbx6/SJtR
efW5vLBGiGs7rPBPE2T8fosHGOvmeC9QBSj8Ww==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2019_02", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Q8VVvHzTNgU3tZr4+8ia7ylST+kbNPWskONHDOT1dTkB7cHZIAWyzXpQZPuEgk2wJq21PoqmVlG9
t08IYzkfC8vYQ2LRf2Co3SXc7p3gF2OFMC68J9Nf9D+/PXJCJy3QO4H8oO39l6bn8c56K2ARnK0R
mMIALbCWSBDGCWGQmXWZJ+xmDGs1KgTeiSW3bZRftWJ6K8l8BhMit8BLOY2Mi3jJ0WRhN8kKd6JT
D4NU1jTZT6jEtmI7Gnj/AXG6auTqDPHsVQzf+ZzBsLTfw83CFoO70xM997L5cZXlqz8fEDmxezkr
wWxPwJbJeVkRV3tUxlo2Bs2x1uVkXQeNVMI8jg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
oUeTLA0HA2uKORUHo1HidNC3lw54gxwlLUkv28qRPv1pz7AEVUbIJ7wsyu2Scju+EkC2Ivi8HbBn
jxkeqRDTAwAbAqIKnY3AdyfojN9Hb8SMLcLnpWLLCpb6E0vwA09r7uqKRZ8wYAgT9CPFvzpQ3zKt
9DTLgQ3rZtFxx2nfCug=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Fayrlym1l14Y48yZ195XboT9ZQmp/mAzUyHby3Y9qJTzDF+m6mRQ/ZbebObo8bu4VAm45JeETPx1
YI4UZNOK4IqKv0BZsAlzUfAYAmqmkmIJYbn2gWUCwXyKX5AoA4ONnlxEHxzZhqtsmEXvxwTEs25/
R7iLzeoMfmwwNHgPNQkteiR4zDlB76CYmgu6EOSUX5Nnitq1oh7qRuU8WqWN7lLfgIC6T7qNHwGD
RPze2yiP06fSG45jPrOn2fvBX9SRbUXjNtiFgmqim4anwJU46v7y3ubit/I6giZhz5PJMZfkDaFX
ag+uCMq4Q8ZEolqMBmjUjat86BdVd4Nmr0yUaA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
kIpxh3qIIkWUg8aLJSPKvKhKTPFH7T8fisti5RtNaftS7xh3KDsGLYnF1lYhH2RVXgzbdaVqvtED
5QJazVo6wUFI91xgFeOR5jX+Ny5UBUX2MngsK+UZyZg5+EdtSiDtiJNtQqgjq1Rn+XQCGF3xP80n
7YvuVMbgRHCAfWrWw7ZJ7Y3raRzeIkx+koPFio7XnC+QdRJ0ItO1YtQgF4Sg1Ihr5TH8/RrNn903
kPa+anH9spo3SFCf2Ts11UXAGLdIBmOLMtEAKjjCUbtmjGSeSc0gn2q2I+xRTFcegLevlr/iuLTw
3lFndBAoW40xOiCDjWZ6Rz7J+jZhsRl3D0Bhwg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ajiuWi0mydYuctGHSimwj9WxmyQ/DdFM9/vql0xz8GQwIIklZuEr9A5U4JnvLqUWbPIcOEg64jOU
yoArRpkQiWtWPj3F8CI27zmJDBzsWuU/4kyO6+aa57ducMU5NF0QfU9+2FJli0EW9D6xB66MRix/
fe5AaXb2I73a/QsVB58c0Cih6PY1D4K289AbgDn4Y9kJPo6p43NWShMvp9sXM/mbx9s/UNjUwl3s
iPKZiXZBi/2vjUymYNdxE4Y/W8Mlq3V19xt0avmwpkZkOsKM3jHBPE5cPuVLP9HN8+fahp7Kv+Fp
yADvHgDpK/qkG861FSb+oOW7C5qR703VbNIDaA==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
y6TVf765Ca+X2vdohboyXfUq6jwou8Dgj6FWWmHfh5eowNEUf6gnisUEN+viW+YK/HQm4Cs7/akF
DEaTMDyc1BEInIVROfHXSqUHG3U4nAUSWfz6dyV6wKqIy1eiktHRJcL8ddalBMRzTkE9DlTYkE8w
IJc6uku7aTtnbiDwTbrPX9bQuyhwkhNl2YHRhLj/QSscqWy+HsOmGnoohO/3iscXHpi9vgIuucPc
vQd9tmh2IGQOo1U3ERX9Dkc02FPyLlR77wXJ0w4lWUcLmaot+oymXibJl3PsEuaHReNwDYpmQRMF
mTakl/9vnFouEtFKk6ZFGgouwcJFonUIjoDRPQ==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 17136)
`pragma protect data_block
V6+oT/TbHpnYfpfOWHEX4YvjnWUpUIONMEcHWCAFCoqH3EV+hzMSpJEU4zKa2C2bcURYGDu5ihie
Amv0Kj4v5fygG6tTn/Bm3v2V0syCKap09wbiQH9SAb7H0x9dHffiXuLhUdN5eHBLEuyQcp8qSfuu
Mg3uruDedb5E9HhE+A3sRtJ2PFhJHssNSim8y2N41JMdmr749lQXUVvLWtAkQZN1z3bdymK+KxYL
0JQvuOjIgKsqew7hOetfKGNlP/ex95VcuULSpShVivpe8YEiRtidlrzDQOk4fsekY/ulVJWXi85M
ReTY5x2wd0mXeLW1AHWyyU9XrGW8S8Bvd+qlFvDi+2ExjymrQpoP8BPkhOKlqo1tj/Ft9IJgr9pL
+j7rmSI/kuVUWt4qu3IOh3zkaCa91Itr1DbsSKPpUayA1ZS13zXwJ/r0eDN0uXMxWaZpSvEfpye6
n1e3h10UGbuICVyn92Ts/icI2OzOHcF7MDyaW7zZH+4TTuHbjqSGFI7L7hAn/7orGddmHA86i6uf
oi+6CNadrpefbBrGI76BcyDgMp1+QxYW/WNzQTGCouVVzopPfvN5JEqF0k4lFd/uHRdCCZ9jqlLb
UEAYw/vRa8CysbbAi1ddTdmaGgR3X6lhjGwxsUPhdp9VpBJm4j/y9/ezfCU92I0OhdRof7PxmRyQ
v18UrZiizc3yi3fZyZS5nWRzJd9B5t725xOQmOQ+zwydHh8nTXNL6XXHlqndjFwUmnzc12fgh7pz
+K2qpPVej78VTJNBhEFGB4tc26z038ga94K62qO1LIRazomr2SAJTjVpZPz3lafvEpNH7H/zpMS5
jbNKwgnxyVI4kCgKoDvR9Xu9ocMfPi3z6mpTqanAVmb0+UmzZRNjfy8kWuI01Y7v67cyWkQ8ZlHt
dB5sgnLF0e2w8nPQ6LprTOf+N9ar+wwyuAuHLT0Xa65as/Xl+QC9T9KaVRBVM28BHQJwGGsXuGfx
CpBGqL1GdVXjboCNntHOZJhxa8H0+C/cwU2jTWPN4cRBmpmoIuqsmwjrgJy88ppVbcdGBmlrZ0xC
OiFbTBUShe2KfKufDLsLchD6GE8vkfrxJSyOHHg425lvAMwUYJLnLkbav3LUJ1/wKduT6re9QUGt
PwX+Ftsl0XLdsgYcfZZVAlHCOc3MA1mBlUMOKoklDOWfaRVwg8Ye/dC7P90R7NQ6qVjXt2bScZD5
TcE4atlbzkPhG3Uz5oT0o/6icD/0ZfUSaza+NhFPaHXErvs/KGJVV+UNigFqtF4UhbcCe/4XYGnS
Ys01wUIb7qNT8jV7CYsBNveFwpdJh+G+rmJplrP1vz4SpDz999IuhEumJOdDzVO8xyEuH3ul3LBs
g8UFRqKNW4S7LE+jUXlkyIIsfkSZYLMXS3ByQWRj+EAq8LT3TRbQ2W3kPm2m0lFl05vYJhap8MME
v+jRg9Kw7A0NQ5VNJRr2PGX1hFZG10JMbDM2aUdsumZOaGSFYdJ0ID2StGnqQN2qQd3rIcx/8yJP
Suz00Wbg4sXtfSNFcA3z0yqMXWmwcsWB594a1ux3xz5bTO0lC4rwkNWtYUpmA29TSCE4Wrb01T10
NnhNSICihA50EJOwt7818ZuNCEpHtHWIBHZha/8gco6LbX35AonJ0SN4jJR+IuNn2MUijpsg7FTM
JL80pO9qMADK3q3bIG2BH3afrYzg7bzuUAooxd14HhC4NHbYPWlIVwxtOvruyweV68fykWc/Bk8A
T+OKUyAbncvGCLFwKyW0IYYyz+LPinWEDX6TFEMYL12KtWsaWqJ4pKoVnXn1pZ7fmriJ7S2eYVC6
MsTKhba6BmCUVOgiJKjc5oMBtn9suaKI1Jj73+jb8X/Ax2sRwEu7NZqmFVTcmbBlw5HeHKZQ0yct
lWFXbdDJj3Mw8HSgJkaF07eIc65z0CQBYEkvBADCx4Z/WDUXKIwx9f878wLiqLkcetnCxHtNSpg9
oLq7YzEDvLZ1ZLuaYmAxqBNpNI7OU3/OqcQKy1MCKDKvyKM4qMvYqEdglR3kFq7sva0WPYna4jjd
+Jj+N7frkW6Sj0DJtlupSpuv1N/WNA3BhwRAKyDKZltXfCbNY1rXkXTrf1r4t7INrkLCBAevaSVU
kcqlyEDWbgKjctDQD+AisNF1daNoMYsY3kJ0rEyr8jYs6dC411BZw1asfG4D2XMwCd5vE1BOLzfV
M+E/qWyxnnDi3hgQruUUK49ziG10HcJU0iL1WC+GVqnNsYaEYqXSsW4fe36M/MVwSHvbbX8vFhbN
tP9xRKONzFRQ+diwtVPDhGcgyQOnK5hPDla0Zl6+k6KaizCO91/agezoJR3qGbuoJKdkYBSI5lxQ
ZGTwuVpofgS3To5UzwaNHDwNwr4qwxKoHq/J3mBMZGy7lvC+R39i+wFKzWFAc38IIdE06i0M3cnI
m8+uXTJY2qIBTG00EXcT4Xq4qutZ8x6c0O+mInbYyz40hDdXSIf1Shi1v0gPl4wGnWtf5RIzQbOk
SufUKVXtZShgopzgHt8/KUDuviV1ahFii+S4KzXYAGEgMJpQcfBsIHZ0z0aMcBV3JA2FAWd8Hyho
Lugnl2CT+alYWUI3IGB+TZ8X8f3IxFW7QiWJJXQQmpiOVejja40r3FBbxPh5wIUEea0gIXiV1gRL
WHir1me/oW2rBYFcojqrVuQSgBA8Om6gUIkCAm48fsAhpGk0e43cbPFBXoIEZb8pq3oIWUarQI6/
2C4NH37bdn3Ng+jamEg8wVgbppfwjIG0f9CiH+jSPrnvdTOd1F2umxkw70MB2oZSQS51pQeaScZ7
peBC3MTa8P/+3HLPx/aVUhbd1US7yPid7uIPFWMGSWGM/Xm1sNsUIRsIq685xSV6acUHc4mRawId
6khHR+8s0M7XE7EOp3c6rtGirHigRVBnme86y+fFaJW4vWaRU+4B5VG2N9pfzF9+Anxf8SLU4YMT
qZQmF8mi+oOL2Tpzd/k4irv4lcFdsfP3LX3+WiA56BTt1J1vrbXO1mJkqsZ4cQDAVBv3JJAmhOs+
NOI0K2ZfsEyyArUogUXt6UIqWiA7l9Aj9HgRCEmzvx8YEmSuTfDNau3KeAQV6iTbUg+vz6idemZH
27QVEvOUaUT9qG4M0GjJqJc/ZXsApsF1QPIXkP5uxS9z9ZkvjHBxWU+xLdRDmwy/pYEjYeMbMqI6
YPR2Ed2fGs/wBkUTeoDv8t+RiXWCE64kRbJhkqeIjfCV3Szg9E6dp+XflGn1WUKPa4NetdyWL5rh
FLSPjKrdqAsuIWCw0UxRugeT8OLaewTLDxOyFohA1Kwo6gWbjTpszYpOpqFguTbIASX5ROIh2ffa
eGFfXrEObHSTMNbWYgyb2yMoZAH7Vwvux6tIlzpxvtGyvC4HSc1+/0+ysqlumJ407OSs7Kp/3bRw
JNZcxyTXy60p5J77cnlXGkiLtxNDkdihq3M49nJ1xQKObH3UccY8VAMEzWzhYtytdq2WIf57Vuea
7lLHMuDV4gtaLlNeBY99P151TPrDWE2749olPmoeRDGWnkQ61GZfNeptjlmV8Nzyy7QAEdNCMMW6
1WohQEnUa1GsbaGWQDNKw0v9RlJVzh1tSXe4W+biFT3N9YCXiG2r6gb9bXrpwQjvNaH5TYDQMyby
qzb1bNTQ+QNNgQOvW0DFDLSGNUenjvjGMjA18Dgnc6UdTO3g8yyNecKgMxUSG26qVmYd1iWGomVx
wovRSPiElZqkQtZBH0c3aSxFE/TP80slL3wRrgGbYxxaRN3NDgMbI9m1qhiVFChUKw03C6eKZ7nK
tgIuGPwtTzyapMHsoRAQD0T0qseuiC/ggsX3k3NyiAxZCnMXLGqLxXryOcuG3bmRODK6StbM0e0p
+JYgf7LIVWYLCLA74mk2CcDQ6x24/B9y74WvnSzXbwD8blwR2RRhVUQsiabMIcXKBx/WIMJGnQAf
pK/P9ljkv14pcQ6nEDvE8axYlJbQHghEGEnZi+WSVOYDU3lc/F1HALVo3pexYfWzprGCKfHYMghO
wg7eXqNgVvQTKJJ4IB2I/6Q3pmIDs2fM5LT9gbAQRyS+uYdi82AxeykFCXxnRxmih6e3D7igdPEt
il136X3YaYWvSKDpA/N9P+5zH7+zqLXWt8VzSNvWBYLnXtX+Ymtlslbx7FM7I/XXSfMgrB7dL7T+
f3qK8hSiNJOOF9DWtLhfL++471/wgFkfqonsNZ6Ve1nn7P4v+Nli4DqCznumGjnbTYBpwHF/3Xs5
d/37dAJ4tn3Olg+KSyRDAefJKeGfTd34klXZ8kx+27pLPsrKjdotDuq/qMvhDfswHqw1kXzh4lxh
buktRiLcbcUMVejJVDkQncEUe4kxZ+KwVLndH8dJ/gqKTy5Jg1VyKIQcprbTgIIahTVElWV9kZoX
IDRQHe/9MgJ2BCsIgBSBVnWFQqHyBiroAn58KLGRAyp5fDDqZUih7F2xQ97EYD//NA7QQ7dW06uE
kk2bUTnY5RSiHbcs29qnToKOnZQXc5XimtcLThpe6WdOQYiC39351Ps0cGKlbbJ+GPN/6FOSq4wB
LIOHN81tw9zWetJ8qdsgfR322DUzsX1dOa2aYUCZNOE5F0QK/TbqMXFrm312s8VZmZftVFVbnoHE
lsTXJxIQ8PtYo3GYh08t9LqaXN0fJtTFp3gOWEU0xap9U/VArpzlMhE021CDdq0m+MW9WSytGw1r
ve6HIQ9lLTG7tISDt/FsGyvnl+f76a4oCo43kWgIaiqSc6GHw3iJ2lOUt5OamKAUjhQGTa3QS4e7
gDCN018GFHsjONMiDBH9OC8smD4EkK+DYwqSQarbn0CjQB4U8/JfUzGrI91Fl5G0izJNFAQRodec
dNXs06UzjWTPgNKZf+I4vdXTq5AOZ59TiIrEBqcd9fwVxU9s6DtDrIa9uCCTlE+bZ9XCEEsuGisR
iXnil1oX07ngw5P/nX29Ws4434+oYyK8ZejwKnboMQIHVXu00p7FwTobH4JgeQtciN/69X2zLmSS
MaiG7Nbt1dhNl/QcX8biPzC1m3y5d/NRaQIAHeYsB1QKFY2+wJiZixByaNwfIrkKGx516OdgwOA2
UJQ6I6cdRciIz/l8KFFiQfXJB4TZvYu8zVd9Rmxu2jwD4DC26jZCMObude5CNFPxqy096+wE4bp8
7pFU6LEdI5CELcYg1AFThsnvArZRciS8n7Bk83HJ8BIdC9E1lDWad+2y5VL2mPMmM8E9oYI0spW7
8aUFiWl3cXnl8vvHbcI63rE2dCbKQQ4ZfRT7ZLfqd8XOSurXCUXemzH8bIQTktvBdIk5QXGaCdoM
hzafGpcwEZLBkq5KX2CcESI5ZGZI7AYx5ETKBaoJI8F1pV9FRcWSFefRFyd4R0zBOw0YtMD1MqMk
7iWR0lcGJbHxu23Qk9gMh6UCsIxBCwcvUFs1xrlwOok2+wuKaR99PQLYLmzCRrUvTp4sUBTFGuDd
zd6cSf3hLuKZ7UfV53IqR9t4z1ISemn2BrKEONz6mQo1rSXul84gYRdj2kgf3lLXrBXD49HCVVYa
aUYLCbghR5yVv8LLPfWBR4s53Nh9wiEdvdQbWvZslxalRaovBzkp8imQ78qyQhW/8bSGNbd73XEp
llXB/PFLZscM4T1WnrOx6pXNWzVmBMn9sVMC0EWb4bSGem/U23l9Od/b2Ag9RwHPJ2brmKfgjZIF
jWtAarUgMg19cEHkWPZSyKvnTzvPwwvmSVnP39H5pQhjciq1CjexPaqOlOUrQwckazwPOFvUW8D3
sUsb/ZgE5vNuVHSzcj9CBtFqxs9zckBO6mW2rt5lKsYNKTe6gGw/1T7ltLfcwHqnJN2ULlizi+eR
jdzozMFxonJ8rN/MoRXYXnFTTzyrCQ4LAT/zxAPshnfTNsDMTiZwORiRtlmbf5MmMRcqQzWtkYTA
34BhAlE28sFRQgrgLcblDZnj6e2CFV4DL+Lz05N/Eq69MPV/2/yGZEv/4XiDlAS0jOvvHppW5O3G
NOVh/C18symwvM4u8YxeFrV5yMFOWGmLCgp8vvRXIyKFZzfMJyqsqva2LEMSW6fDLK4FhMK7CApg
TdKCU9EeVKiXVASdNfuL56kNoLLhBVI+luTOUiPccBL/cbNlE69GAIfIUJDNs6nG1oQnW/WGP0Bi
WNDygdlP4Nu9dL4XBSthMkCZpgHYeRbVsWMz0YqV7eqXprkpdMMF26XonWLV2rAmMmOUe4O9peW2
uakBKzabrLJ6QVbrt6nTwRnmyQ+AGij1fCZstWrGanjjo2NlKJ4Dee/2SGDoKcINLaOd5jF+z8W6
m68T76AznzEX2vXkV4YajSK9wrFYOZEo40zBKWUX/6aAIAUzS5UeIuOJ7XrQgYZ5R2oihi8YttQ9
OzR/GdzmqmMPKvok1Xt7aF0/xLGKSDhZDZDkF5Z+4F56IcqbwoS1Gt1sqw2OYleXrFwsTScrg3Sl
uNZ2j8xbca1jJEM6kfGrDr1yhXKS3IArX8xa7UzQ82FQDPMzbOH648OHDQDp8g2BizBak6BDLRf/
C4rCVUajhuEwSn1qOiigAySJP+XbmNijoZmG1qV+0UgNofyYOo9lsn44IhD+f9LwvUDzoXkudAW5
dXgczlXXuCU4qlHeUqTJPR233T/Dag2AXMp4Vuft0JxV01eF/nUEHuxTYLHywUsWtydHQOE/JSaX
MymykMZBLZYsOL0V63Uso8C30qjzB4r6Ez+vJk7UuvQFJM3YyJ3nUZ3HrHOIQUBSU3XJvDKp9Ei8
tE/KSEAYZE2086UxLYJ0KZ+VGV7j6IlB8jubhPR242OFCmi5z5PO9L9/fXKns4IxM3S5gTKTayNJ
UicUCOLH7ReD+LWV91Vd6X9JNUPmHSq8rSQpLNJstQ1z3INGWalU0wKqwx4lMxkZvDNM4GiUMKfG
8xTSOhg8+kIxmpz5W+Mdbsgf43TE3sWontW0qb7ODwp5HzjO/YZ14WuyY1Gu3UQrMIPUb23k03eb
LKj37ctjqNi4LPMtsQLGy3fdU0ujSyCifRkvmIAIesWRpcdPGgdWIGV62j79zD1xNfALiKPDSnbb
RIXvdUbKgp6jcO9kjRgjPX5dhOQBu3Mr+57DFVuLgU2Rs5kag7E3tD/VcZXsWRyGOwrKcbQ/Vu+c
sFKbZBDtMgLO1xmJIRSxVVMGgc2bEuCR5QosmIm6CKv8RYzyeK4ghdVVmvxLIp5RGFNG40+QxK3j
cuUuhJf5bAbe8/qGEqvXWsFAWpbyPeDO4DCXTzcW8jVAeue6hZXDLRQypqOK3mgCUnXn4h4ESbnL
ShUYt0jl5FYPpVhKVmnq5MU6R0J7MNI0WeJjg/eoKWQNHcKzNaDB/nqxkmRAPccYMhNkSohRKfHf
FnRk7KCyWJ+2g6ICBxU8wLuwlxhC8xjSBI7wTYzYGsIG91V1eIqZNIW8+b9Yc23L7MKjsnedaA5b
cbrjVQWeXBdWbca4Fyqs6IsnMXAgpGKWK+osXhoY86auafyzxvy0wDHXDPXpRE0y/6/9xXB3zhqi
hJ3Vg6BwIwwSV+NygxCtamk1BKt7nijsgaWAYM4d+ctIDAjH8tFNb/EqHzgcGFAJFEjYNbXb5cSD
8yg+gwOExPIcROR15TU42hjK9S9OkXjkhOFdFpHfSDMkJEBnaHX/tTMYymrw6IJZkC95txEO8fBg
MXSwBjZQeNtoNlgEeThlGb8KrTb1iajEPbXJon7MkuXgin1jUI0OVM+PGTC5vniH1zHZ2VvIE1wY
Exk7QxYIzK/40UDejEQDD964JxLqBqKXdhu51U5soT+k0/VEvriVxzoL/3U129+1qsCutLJF57jW
we70UbHwEzV9OwBw9BsTkSX/PqVOhctIOze1WsyemETFZ5fMVA3v7+dDAmJ3V3GKETqppoLyfptW
nXr4Mo5LJghGcNjV6f7Lnq8WjG5ulwKrjMMbDebZ+T2gH7eAQAGYsFCOrzAFOQX9EgDUpowaSAlD
qx6KCJ6sVupHOERULLktIyrKsGwMdeoQ/ZEHc8IBIbsZJGQ+ZHMONZRjUuvnDi9J+Fi7T2KDJ6fT
fvUVatONDtloiKF8KgRdHKmxzJv3HHfyoGrmEAOhyhj6ZQ3dbP7Whj1M89odXc4nHN7K9oDpOm8t
YDdeHbS8sKjKJk7CtCze0kRsM826xlMwXrJ/AOa/MuXPRInyRO0f7ggjhYp6zRMJFudYfR324t17
SERZajaiUtd79GorTPT66/j6JgpFAN8ThbZ5F0C5mpBVLnWxqRnDzTvtng8846J5TEyB8IoIhOl7
I4iFF4wPL7sLWfDFkKFdcU3X1xCbo8YzXDuI6kJE4yKqLwhcz27BlX4LhzWMYNst1KjtuZyWduBY
MV5cpycqCXDqKYrVFffjrGK0hISlhw/KHvSaRSV2beyNbA9oUS/tXtkLYTjtJiQuwBzapms/LsWZ
xWGeLomgNj1BTZfDMeJjR4welJRoceWvm0e//K7gWSaIaxInVOTz8LupCiikUlWQNa0XYviqAsHk
aNw2dqkC6GD65RJytTQbIM7MPkazipsua/eve3YvM5IGijY+p7z/VgkWS9Yvlm9vRL4VQz3kQuga
7DzqGOmLTE5AeUXU6C6xCQdZtVQ65ZFxsN5wgWoDS2nAh3OBkGwqj4gaZr9MQnL6Yx6SV2xL5Gox
VRO+2POyqMZGSYD4zyDr2uihXPw/emoOIEBuWXWA7KXOSKNyqgG4frA3InFw/yCRXqYpfybcFdr5
LNArKYkVbWNFS9BbzBEFJqWazH38D05qb9DJ6LD5P2dvdEuaSnJ1oNkapVu6e/1f+H/Z9fRyXa8j
H3NvG0ay0cH4HcfKj0Mf7YsOAiVnL4v/djGUwfVLqS0mE917+gPcwtC5D29JCDwQtMOLl9XFNTCW
KWgwa/dLCK559tESuTVSpJfwvC3asC8PAJDs8QLFT6wghu+zO1d+kZJwO1LbIe4P2i+oz36t6l2Q
2dDnglQZpvB07jFzCDokFN7JscNDVX7V4SDzWMiIx0PyfJ56bbIvI985OD+MEpL2SL4VoNSlG4o8
XnIxlSQmQ9uRrpk+9+iJHho/N0c5vxcK8Td3JLe1Au6zJwfSM4MrivryEkFaz/v8FpsIcC53mRvB
DqNIRt5awop5/KGEEpT9ixi5vBJLlKZQMDF1u5kRvE3HpiP4N9rBdj0ldrj+nDQQ/UZeq8QW1jgF
1bJFFOm0etLNfkVxTFrtz6pntPIacJ0TlBTPsul/yn4BnJhLNOMRX6H02mMoqxTDOBaP6P/HvdDb
Shu5b+Zbf+bogLcvXC3cR+Q2CHnBTx5pjz7yms0NrdWajLiAuJQIHu0Pww1qLFXMoF0K19kRizl+
zjFhhcZf3HH4HVzyFS5VYEvYgqYmWM72cg91pYcY3Cg20z0pLoKShJnEvYnSXzDM/8xG1vhMSOR7
zFIcxT/DhvjYMndn8BzaJDwaFDQV0C6It44wrdbmovvHVvM4+G0VSSgXVIWqV0fwkkBxIaEEFEGi
Ata5wNlhCyyMVz711hlE8kL6oEAMez5+j/+buGqWrmyZK/CH+dK+52E3x2RsD9W+g1g13ZN4twuY
PFNAadnmRCDXcJ8Aj1TPagn9BoRGTd3ACk9Jt/UqNse3INHLvhJ+7ZuEMb9X/FmiDNvGYREtoOC8
cx6XsKYd5AHQJRIj/vAT/BEr3wuZ/Qjg9PCr80KV0YGCRPJv6onyRDTrBCcGzi2k+EyeyLJBLwh1
5aEf8gV5PJSbamFWNa/J6B9oSarpTAnwua5PT8+JCG7K9jQg7NObKKm1i/CZsad1pX/FXYbP4N6H
LIDcfOiSHsVowyPxdducX/swlnwrsAF0UGUx5wg2Dyzii8vCcfwD9qyp+0mtUrl01QVwqY7lkbss
S7HUDKl8xlE3slHdh7dAvXV356XkSjNW+dnBF+eQKMqR7Wez2z8s2CHjX4OQHGouTcgt/g7wUCvm
DRMPeYJ14wkJ7wj6UF4E+zAcR1HlMDLoYeYa+5ZeML+iaD2mi9gM6P/dLNa5MslQagMukUzMGdhU
r9spuZx7DNTcma7lzu5mEnSJ4FHy7KtXjv1HypRIBW00RCriA5Ph/aDenKyZwWrbBV+YDybxAup9
Ch8VVkd0YLa1x+d8UgX8nu7VjiRcVvwi4lR1HHg/IWGH/2doriwJD0+Tv1z9eOKW+Z+HgnNfp59C
y6YBtyjJcJY53wsnnTQ+u3qRMmeAjt3yKqu1eHPQALYEwdti0zFe0UXihRG8ZCjZoBKxAlv6ON6P
AtauqD0Xc1SILeUK7E2uay7kLVDKwHxVpTHkGNLSf6UZf1XuR0DoopMCC7PqNcgmYxrQWOPTHQtr
SW7695k9uepqFtE534qW0CfBheWHWazXR9rxcWHvZEDc3bn0HzFD4uRAN7p65qZBJkhtziPhHCcT
RXNJNld6UNnVGTex5PEwViXNbKT37TsS4YWLBROdZcVNhmMZhdV4EPKMLsBDVLV33hxaZz3A22oH
NOjvjSERDq1tW/ZqKV+fkEs31ytzykn/KxqguXLMO+K85JgptBMrwAtTVrnz3t60tqdcZG8kQ+RD
uiEh4Qod6z4jrWu4a9B9IzqxfiEzGkfz/MNKJUOddzpp/I30/tKItm1TQYxOktEqKlonT9t9sFND
+DHO91XAdGeesAQ8EFdQY6T9aw57uQBbxYbpi/EP7733DlxrI20picUIJLSfloyvjKDPhlIGKfQe
d4DKGSgF0Mzv7W6tXFs9zVA/ySR4IpNkqaeKo1Bva0pmoDXv8KRtlkxjEcvbvDxQ2meAfGmdvv9k
Oe+HiVy4MHFs20LqAHN5osZfLZvbRuzgiWiT9vf6X7ZPr3LNkpRYfVPruuYTKInexwtbn8ghD/uG
dB/1sd9Ut4//z+3bSD2HPuaGfud2TzsR7JvYk+wuecWUUpoGn1EeLobo0R0eBxKkcHlAl9BufjbX
iFFRweDQUasREz+IwCf/dxIolvlHAbYxYjl65ynl5/MoPc8II9j+CPbsG2XPisStgJsazt4LP3ub
Ajichven95EdtfVQX6T4dX4sXC5yRBySgNK6PgjiKrwXez4sgI6Ruwb9QfREGbg/DEPiaPXXgrpb
dOOklgskTrli6Ytyc6tFxcWICerstYn8WvDT4rtJA2KB9K80lDF75hKcaKYyudWb0clD1POpLNmg
SfsBi0dqKttcSm/76Gaomchqyt8L8YG97iQM5PlHdvUXbiu9kp8wbsLmsZBCYXrkjMaVYcj9sd/x
6Tr4rxZ0p+cvapT0ZKf57nrK93dUiOiqJ7/CLrEI4HpRaFkWTsjGfCpUunLrs1rBjRvvlHyHpR+z
l2UzieFMBqaEtocARtr1KpjMxXNdXevSWHzpLfJwSDSFd9TwHmjdXGcYk4jnKmFVBgnQ68m+mnQP
ogq5B5BowfWknQirqr5M3FMBHE7pGa6S+qE+2FyANWq0r/U+w9/xZdYF6iG6uA/BN7oqvIFyMg5y
nlJdmOmVmJERon8Hq26PhgoQqXkDPw9i+2GGwpQVxRWExJOhEVjuSkjHrcMzO4/AI/KovKjp4DOu
YUoSc8ReRFZ+wJCWzVV4U6Bpu02fzUIVg+rfNuGQBSr0jxV0dwuBxqTNd4q1a/Bs7MVrTGmulR45
wUdfiYR/qfZ+RQrjf1fwiJAXXbpsIh2gFDBOlnp28cDArxzmb83EsTwBZAgsidfHCS+HSDSVMPLz
H3pWOuMnc2k1MaCFRInPYof2H8/dLSNViR8SKQnt74r4EUs4q/JF4iMQOWr/fiWc+HYg71+GJ5Yh
FBApDTM/zDTqUVLi22tJBFWLfU8XNkhTIhxkuHxmT508xQ2RgzK3nh4v/9DtZ9pj6Owox3dgI4bk
UG5NhP1Gqn4Cgm4k/ngJWwUW5SyeJPEIwF5fpg6iaywyLkaLqc+LKvxpKpzVmIDAAPo6kn1ugV1r
LPWIFymo6L0FaNw1XCVXNzTaO5ZyhZ8f8Q5oQDXdZZ8pLhytMUTKWJX/6SY1RXDg3bMTLq5sBXB3
XPqhFjEvQit/v91G29GEZCiJJsa/ABCW6/dnMr0DF94nQ7bOrBqBkh7NEh7UzLWgilf5CbcgNtbn
9eoHfrasoNBqUrpinG0/CXC9zEsRFLxFkoNvntxtTW5O6+odrMkmHdmEO/QjlLY/xjN8P6fHDkcj
2+Aba+12Gbx/Tb15pF10RXO5CbYw1h5XnRdTuQuBdNLddevkNOAKTnhpBOZQrbrCAmcCeNYpMiy+
P28HbKZMIb7KpVegW4S0aCA2Xi/o4v+es7ZyrHq2UxTiI6CUWOOQsuMogbb+Tj/v+D7NWUuExANL
cJqNs22BEu05ud8/vJv0Tg0sHd4Llyx9T5WDN4YZ4SfG+9NtWjWO+9PklD+Ox3OmZ17giHqhuM2r
mTfUpSVSNI0JQXIxyhKaRZZ95IFOh480xnW3qKQHwLQW5DCbLDG/1GQHSJVzp8x33/ZdBKKAciYM
GDxi0nX81WK+R9oGebppV/u5ZIPh6b8wo0DdUjl5nHm9APZQXCVECYsWEG7u2NuybLMpZv9lbPh6
Qy0QRvIKEF+53QoR4Ufr+wySteMU2BGfqqAb+YJYT+ABuNxg3S8RxkvtDx9MWPdV8KC2YcEbMH5k
It+ZAB8EELQhiMdxs5RF6FxiKKzwhKQOgJGeDklOrMSttA5LmBmD+yeq8An7/LcQuNfifHiXznhE
L0XkMEgGxnvZP38YmWKG/HMUPWGReq6P0JsRg6c2X8z1pEmq33vR5hAoxHY0fJ6iAuiSgoEhgcBH
P0eP41c+xnzOx1cDGFTnTWV2UND4MSwLkf/RIRblVUTTXs9LIzdhhcxMcLtF2b3JbE6eRiGSyNUC
ZclBWKdfgp+XiDkkDeRcEktbPfb4KwNBJE5LEMYNv33IeGN8ZM2Ak0J80XFaddlLzMZOne/kx8Zj
5wXz/8jUs+GI7sHN+1deTU2UvEHXAod9LZ4Op84GBW709vkfzW8NreKOH9pT0wJx4IP5BMZiNw6w
tOvRJAEvLw/wkDIvNIYThYOyHtm1/IrfrldkM7T4d5KWIs1VCdxYh+fOsMOoGotFsFe+GZDiq94X
bioy/WSdGR+Kc+8gctY8OK3uSHb1aVok9rXdgeOUldTKx/rg0I8HzRn8f/h6RzehRVo6rZlXGDgU
0aG6ep1uW6sBeO9YfvhULhGcm2P+oBJXSMN6pLkR22jiqkFxsu8RSnBr56k08ZnKr+e14RBeXFJd
SFJWw7l3JJ5RgR/AZN1TF1k3mE9pHDF53D6RJ0Kz64xTQYcMZ+rBR0Z/3w8zN1YnETFJOw5s87pp
KfwR3Q1JEKWbyHrmPnpzGo4OJ1dzEX8YnxWA6aXT1LKPfJPMil1SQHLrkDlc8g9l1qDmMbo7F7rJ
4IvBV2heTnzBTJAs3dnNtbfiv3wbgOYvM7uXbfLhGU05uRm13sV1euu//7W7yGApvHT16RM9BYok
enfxSF6HE3ebrPdGmx7cyJG63f+qpx56jbvhVvyq2a4OqG7GAlOJONnRVq1/tiqTzOQbacb8RMgQ
qWe8nyB1U/BohUyO2G/UTlWQCrkphGleh8Afeu1aQ3D/B+esJNNx7U5EhUHbSZQ+UugX1zBOMfex
WG/emxcWQniwFc3ImwMvAQEci65bK87tAAAERpNgQA6Zufi0jC7qHFS/NS4lQR6WNaFNCOX7L1Yh
idJ2i2GQWxeM6Z5wlb1xWYtXiNsOQnD1dQE0uFKpzxBXbqDcl0u1fkFfudGCIFbonRenUZxKoWXN
bXU9DVOlPamsPbM70EhQ91LOivm0r2wVzprYu9dvh0WLWWj9s2CaE6DqSLQLuUcDIyx1q87+YCwK
U5OSZvlJGziEh5n5Ym+Oc8w5I/9Fu3ZOnpoBCOn4IK6JoKQ/rQ1r0AC17NdoShIgRb6xJjrT9rse
uLZf4SVhlkisiC+zaXUm560vkN5pvC7prxVlFU6EbC9iqHIQBRV1QFA4rpd7uJH148hThGN3Ko35
4B6S7AOKtZsYENGZC1oN9nKd1GQ2xIBH1H2QtkoLsY6vod7dEg4adZGlcy5f+HYRQtTKQ9OnSuwl
RAwEVUwfoPDWk+3ikrsXDaiX3eSR5RkSKLmL/iqHziMJ6pp6YbbUKK8QR/MqKhSvp2KQA/q3Wazw
2fepgbObkyBevT2PKiSPPJXcb64C7hMysDk7j2RyzSu0L53GyMPBizZd1ipL9wFW5xGeMNluM0qW
mmasWnGhRQDM2Z9qoVrmTq+ZURkMLFD/yLh07dy8KWomPuls/HZzKA7XFTO8gF3tr1bqB2Vso4rF
+0PQKvnYyKcnMH2LhBfzHl5vEAxGI0MxZsjUqSmL76GzXfXMud5JIdy1SbVi60OvvkFo0UjLgWq4
xCmUoUsExGu6fAIpi5doT2PqMKHos+N83kx9hDocRP4SjzY7r5ApstWZeUX71XlKxLI7r+iZcjte
0sB9UJhaDuWDbTt7A3OwEisBBTkaoj5hdnPyrwxujqPjyfehRygF5IOzaU47tNTytjFhdel3FdFe
T2jO7iZnS5rgHvYysI/4Cfwi/EsgSS4KCHUNl8wyzfUWyAlDenZn4UR1O+g+1ZTCjdb/F6B7tqOk
4uuebv5ZK75UkQIiQBhAwb3UIiQMHk8wdjBIwvpkV542tG3cD74VA8yuYDhICvWd8lQqRYA+81/z
yQ8cPatPr7/pfU2vDcNwNEVzcuD9V8oDhn0DfFz8bnLuscvZx0EfI0p9VMKdJSEYyt4rx73MWjWU
FOQv+DF4SSadyT5GRi7CFEJOt3IWioeSju4bRpyELoOdqOz3D40WRQcjaVs1VEbGgov3rn4VQtez
IR2s5KUpNb3/VGdumV5VqTQEfh/fRm7/8cCALoBmua/xzRa+2dNsliPo+gxGTmnre7jA2cozNqFt
IvzaehJ23pkSDukNX1RDkDSsH6IYpn69Fj5oKYuWAJO52DPHXwXpV8+pcUVzYqWld/Mqrd/bWp19
bsT1qMGoconeqDMhqL35zUpp1NCXRD9l5L7ekWx/Iwvp6wOH1oJKiVHyIOl3LWn9EdxiV55sMo2Q
g+b69UvZh7QSbVDpNc3ZZ3h3+yUTVkhPaWL0KhCCE7+2XOkS6YrjKML6M8Jg3EELH0D+3A3nNyp7
oIoqcWVr6X4NOw7aQzfSY0m3+30DrFYpLL1aE2NZ1oNFVP4IbO0ojUI0QYRg1YmJEp3IonFtBmqa
yWcYbvaxTbm6wugcoxsQmJc0HsT/mVHPbk/fX4KU2pQgvaHQvdzpIkOA/e1TgBQec6ZCz1Qj8MeQ
7VaoSR9siRzzBx1LyfZhkGlsCpvJvHAec2cnBNKF7nuKTCHhWEgkIaJbVIEUISZSuIACYk42Rq1c
qJlyuL7OIaphZlqUarSWfmbnw898/VoCXnblKkM12Cd99kPo+onpk70l1y8TR9QPmld/IqZn+WKz
dwfp47TjydH+F7WKoFJynRGSziBm9U90/w9daOd6nVBSx4MGZ/D/MsKgLscfBKXph0Gv3VH7/gbs
f8QDuHYHFCT6sDZhb+0WpJyjg6saBEOM/T58DAn5DEI0B8FYCaEFfuseUwhUwC+4LQP8XuNG83Ym
rKDthpAm36WzEG4NivtKnqjzWmeA2Genb4G6wrk1e+MakZeL3tTthNHmdLXIVzHcLb31aag4zn8I
LPSeDH+zyjLcJcKz0tM5MQL7X89N5Y6Nmvy9TIrP0bWTgZA6nGrmETL2E2MQLuQwEFFB3QH3z8hm
UZKwV/ciRtKzeG3FY923vKo3jYDuv6zus2m7hxLRZB7UdmCvNnt+vpJ13LIbeC0atuoeZNRn0ahf
+JswdCkfupkvtOukOkSsa+T6SLZ2BozdkrgQNk+EF+TkRWnWUzJZJVIYRUq7xSGxIQOeQPUNL1Nf
7ipnfadXOk52pnJQCoQMU++GpzmmgZ1kGYaJdTsT0PQrjpHijZy7bGa9Rsgh8JmBM0L8ecy6kBJe
6PC3GlIigDsS+4p1kiuuoElohN62PuGE4yjMq2TMOYPxj8pqgT6aowz2NMFAhiMyVlhN5GTL4y45
rwK3LHVdtUgNwCS8BzYPjmcOOTyQij1aO59Wx5wdpWf8WFKrthUqbc6bm1mWIHgLWS6H7Auu/OdX
E+PnIkrZaUqG573IDB7nZwH5IK561SwcDPSdvLsg7dlNGt1jtUWL+X2rq4jrMhMUe9HEUePXVcvT
mitIE9lgCw651IKmPJ3kbcIpXFN1G1iMS9MrgyvlzBaYyn0/gMelKBlPfU9iW7+XyfDXXDsMtThn
gdTNXBxaIvXTm40IjnCKyZ1+Ip2KLHx7FhHSiQERpxrD1XFJtCLMUBfXunpk56J+V5vM7WivdZyd
5LogSJZPYtuI5fLhmNsrOlJNCfgDp5ddB9hMxQY2Ew1/FvB/nsKW4+ojbzibYVIF/P5LSgYJn4Ju
Wg4Oon23CdEHyzXqH9UxRcu1eCh3XrqYY6GzECcN4V8Ss8SkEvlvcXVRGJxBl87U3xkJ2SEmEoYQ
sfACi68yaW6uP03mzEXzzTr00vVEs3YQS30xY1r5zFId66CxCglPBm3NHx0ipmkAJcHw1Ma9PAE9
VVoGKZktOJ3y7pYk2NX9tFORU28jS5Hy+1DUGYPhjprfrWbpye+ouOq+Bh3e9doOLC/WhIJ2R4bZ
KKZWxymt3Pq0KtBjtZ1R97i3GgCRrQj1CWUakRMg5DhQQXOsIEWrSPhq8xyycWyaCT9ngW5AT3wb
tDXY8lrPwN5VKlrrn+aQ4PELwvkkhkHqOCwTZ9kAJP0B+XfmJGwNSyZ3Fe3RdxNjAaO72UPKssSf
mQyYnO7ZpV1DSneQVpFmxJ2fO0OypDbrINywo7dKhtuh5ZRzK7DQIiXzCB6Sb5CpxWpJWuIYe8P0
rAwuW+16L2STdHuhn6/FExdQ3BC0SSjO8KeVp+9kUDIowF3z4mQm/HjXls7FQu+hbPWbZn17zCB0
k4y0lrePGyeaOf82lF+W5VE/hvSiJxiyNKoAf1tFd30BszPp3yb1NIZUPYP6vFLgP6ozqduNJu/Y
/pCegnlxpx+0IQNy/UfpbcOO3pRU0TcXBtlWKCqtiaW0qTL2CQXd9papfPesqYVjnwJPMqn9r5Op
ZuYEp26u+R0NqHN8aYyAevbbw1eCqyT/AtvPxz13jep8pNYTLbvTYsmJW7CTXHxd3PDaJhl4AXhf
IPt+kXWNIcq/Ol5Jr1u9tap5dY4qHfGFra0yKktuGXyUOW0tIgs4GWfnVub0nmx+0MU0qB8Q4EQW
nFff0eDzmiSu2mOTEtkNvnvNq6IGmmOTT//sYmAoyepJB5+fsrZwDfoq2tGXSjqhkLjV3X92g/68
thjxvv+EnUB2GOAnlrSCEkzZP7WvULzjhPQPNerUhvoWLhsZXkvY1pO86AlgPu+IQy0UVsgh5K0Q
G7GoaQKrARhgEwi7gYbkFUvOjMzOFTHzxM0UeHXYL23vcmh1kj2TcHH9+MhAzqu0qFGcGmvR5QKX
ABhXnPb8ldfHWfVe3GICUlFozwS6w4JPpUEB5F622CRBrmSwGX2SVkMzuvRjS7YWGf9aMex2Ge6e
xeU+ExDQ4YjrmKKb5wUKBxAtE7Qbgmle8AOlIrRuY26rMgt5ufeD3bw3LLRfzhblP+UwGGzN3upN
GH26Yw1hHKf8zvOoyqFJlhtrZBAAlmDjhLCM/t9MnJDofKZSqRV4ftQcaaMHSWKgqZYv8d16w3XW
gfzVOdwK058xcucHFhYHdVkdVLjw62aayeX0GTd1/iUsBsFLjD8WFiBhUUOzLbevhbriXLS18sSD
m42kCRG+qOrFRvuR16OO7ZJhgRCrR84AfsNO3vprK3lrMNMjX8JSuFxImqFRO5/6SHFfdlOJZnj1
Ao4OcWl+wmYdg87apEjf6fVZTUuJ0zhwkxdchNmor2uJ+HFWvZROaksSWl5PSmTVjNM23wLL+oh0
7m5UJ6MD1Zi9e1HA0cSZ8BAKDdo6Pd8s3FgE/EZW0FNjKVGrYNWroZ7dHabFrMcojkvesbdJl5Z2
9UIsGWSuISWAKuCYuo1WwMzipRldr/6GjpmOCS3VSIUDb79rAUPByg5jv0faNryQL/adKurNolY2
B2xBcmNDPhnQs19v/ywa2cz0kGQEYHpyGUag9cW4/LgLo/Mb/zNvbqzYUCmvffR1sn/yrxv3h9HR
CJH9/ucsEF+CIAfJBD74wUnZsv+yb41pNFuNFx0WTR+sJvxOvllwfvOBThzkboaosN4NoUMP/Vhq
fc9AkHJLAX6wWrEx54UT8VB25dsU4oXqdlrUAjYokhVZW15CYJHQ+4m1vfh144Ib0c+SFsJdHRgF
Ena/FH1TDRvGQ9DdDV8PBuHSLRXtNGmx1zikowYcUY7yir9hJOrSw17RqGlXIlLdCG1Vg89fuAee
IqtatxbGQfYEy2spXYc6pw4NTz+KYoSXc7HLpteqr0qBO2OJPttIfo8+EWUoj1Du0XWJmepNbVKA
XwD08w2Ufj+KBac+tE43MzpiUCd/D+cKsjWtE/c/lPtp8fTgq826Tg+0iktEGUATPHmGvz46KfdY
5WcmtJDjvz0oC5rdqjMLNOVpAJywPYtJWmy7859dP32AQAKwuhgjT5NLLkfw6XDX1+sVbyf32pWd
H+kGunGPLJcPl5GJ3w/QLBeMq9OND1xub51mPrkRLcZ8UJw/KGXosHNBhQ8FPNcfPcIjEpCESAcT
i/xQbOL4r75W0s6u1qGW5Eg79XYSTokqoj2GcpFvp2V3JDUgaoiapKwEhulZLfw4WFmurSL+CP+U
eTwB15XM4nnZgGqofGfG55FRfPuINc55HzrbrRzvhmdikb6UnuDu8Zsy29UppfV9TikhBPjs9iW/
aQcrhGmvycJfIEmHAHOLAsYpw8Tt9atd5Gpy58oIK4UceDOZjzvGMBDcqbsbM+6q6+0NN5LmR3RY
Khjh0VrlShZmzHYjK4JbCkDOJ5oOymKFVCYX9gEWPynVF0P7zCcev6AziwdU0axuznrBJZnwYyAV
EjJFTPjEiOHxuQHM12DR5LWQCHcyd2t6wJXkXNmR29A5q1MzTca6wASSjCajsR3kDVxoGdwVdf5G
ttdGW7K2EyMeeJ5MTWKwLtvDhXnElrT5Qgv5Vp7eowUkJajhdBCOZhM7LXBqXvekpIBsLmPEvKbE
MptFhTOxqDfuQHsZAq8QDTasQsHxmbLUzO6FO5xMWGrQ+GMWgqSIuU4dQGCokgtP+w3iWCEn7Zxp
Yh+6vzKUUxPG+FQTMKxR0SjxkoT+p/NXfPZLHNkpTre5Km7yNulycL8WyOPERc3XE68GP/5qBPaK
DA4oV4YN+GbR+zukYGaNmd/YgQKk4VuQ8ZHPGX/NBUyY7urO2QbqRl000Wi2POIrgVDQK4o3Cq4/
QmxiOs5KKVs/XsdESrLwsoGMSeUELg3QIx99r11Sphm7bxkeJ159fxO6gCJYcnuRzn9YFPzKjoGK
Sxn7ko+51vevikGhBrj0WdEsyLmvQvuLUhtLW+fl03sZz1FAfJyALBODWmTFfXZ44lvucweMYIZi
r0dOtonHNvlUmNP85O0DhieGnk2JpK6zZaZXvyisIy7iU749KSpdZVX4gpOQN5Bijh4g33BGSItq
Ym3XwtFnvJlib/iR5Ge5GKOmBulLIsGvbyafzBDN3fJ0q26wlSv7ZwMbYr4uOAl+LZWq4PXL5WvC
fUWpHEcvECH/TLX4AJxAsVhhmkLOXe6AbRYe8LuR8gsAcoUFvUMJ+Gj8MTd/vSuRj6Jw04Q4O26r
rGNa3sGXSnpUp9Npa5SMtdQuxAlOlJox6ukEiyHlgIBPkAyOoxg3EnJTSzYZea+KlYOolqIpLSgC
ehqcfbbzgekASPCEDbNNewUG+wD1M1bRPw6bnG2mTjD5cGcYtpFYxvP1JT/E97FVnMfW9dIk6W9i
SAOoXsgQUfM4hlGpDWCIpb3tMCESb8bfPn/X26gPD7CVkDKvOnVJYeZaQuPU2jBm98ihFwuDSgpD
Sn7cmMgC7ys7yrHn7PQJLk8CuAPj6oWLLbV4UV3sDob02kTu8rIprE5HTm1ugrZv8OQXtdTFLVXt
Z9JPS9XOsmT+1RsOtliV6M41wFNJ1koCrv6XYmJ2SPFXmvtjYsZS0gb10oVJmlQuRnnrhn9fNXAF
jhK45MYsZ4vPLTXVXCxihrbluuYGd9f2co/NHbDgoLfbzEbYCPJUQlzh7AB19eZ/JwoGs3tSjeGc
pKzkKpmjBw04/5D+byZleQ/Vd8Mb1LWWD67teF94pucVqprNQb8YlY/Pd9orPcDpAmvTYqP1KLvB
FV08BYKt+NKkTZn+2CrGd9AaEF3TWGSVCNX2kiyQuPECaczqvxQtkMg5Z1M7iXTunoVXlRXLIGVh
ht1l0/q4kmtYZlPJPl2Qz8zD03PkKAvOSRqzcZDp6W2RKFt/WEze23jFzb3u0bLueKAPmfRQdS1d
D5nP5aJmfd38XwU0fsZ3uGb3WiW1FjXNAnvyxTuRSZiVeLovyWApJxWQr+JE8CnbOBGBw4lIn8o7
mXe/URaiV78IvfugidpW5coz4AGZKszpByxOye4mWbdxnrUv0Kobcx2tZuIjTvqJq1tND/u7w8wN
ebPPTkRFxYtWIZXgAk1OjUQofBzxUQLmgInBTEyqmLmbgpk0RjPcu2UhCeGx5jYOHnlkL9BkOmqB
rOJO1d3TsLVvbII8y9vfUtr70/KBUTW7U91HErUJAu/NKvChkRo6SCHyvI4CFeOm+PmXkmRXp3mx
foqxfV5zp7CWsSvkAPlfWwPIzVmgCr2tL19g2jBN4RXItqWwXhkiL5dPn9OMCcgJ1TC17zmL7r9x
KCYeWXXYg+e4HK8wiDsOUg9IgkOQTWFmJmqxWIQ4ZvZGQl4HXt6HHHUucQQOw8d/3npZGtdep4Pj
sfRgnD86Mp2zmIys6b+SEHZmpFq63cdrcpR/RwqXVejDBe/yU/o5ELuv2UHeSlbZyJGDGoA5FlkN
FvaSdo+2nePYXPnMkdbfnELKC6tbVaETKj7hkbQh/JA9F6vlP1inHEjrXnjhzSagowSC0S8KeSbP
fsh5d3GsnFO+HnrQ0QNmgxwNxLW3BIQtAXax3P9lZ8tJkxduL9BjbVpAUwJHBkAxIt1vIiR7oUoZ
Y0ioSoiTVo6eTRhNrZecv+WCIsqC2Eu9c3PGaQx3QdTlTC65/F54QGuM1FsY6bFUPu9ZwptSHc00
2a4apXvL0QonixVei/55vTwAORqsO9W4Kf+kF7AbzwNpO2pZ9N2FoGnVJZe82Ovf1aDyO/Mogtsj
9l6bUwsJbhYNGAltSFg8wwczwjPCh59HOpa0Qvp/57hLvmLJvhfgyyItD/4EoDwj5RrbOLfhXe0C
cFEyjdwXyySnoODqI7BBmeTBs7EMIm4BgaGtUTYV00GxklStSu658F1R9RqhTfd+7EcKZQxYbGDO
tGUPpraI0bg4ximrbPdhKXegyvqKd1W6iGDkWZ4lmIEP+KEe2sXvT1aP4ZzahrNuZC7uVgN1NbUJ
cTmLpNNj8GnE8Shwyocs7hDupQm4ToiDFKivfdnMRHin9kcfNX/sqAyGL8C+LRUXnZ5PRDkbudXF
/S8lsxcQBTEOH+iiDieB5BQ7OZtjAJDN26qUeZKyAlCWwIpSgkgGXb0fCtFsmACobdAEv8Bp7H4u
UHRHFDL7S/15aOmVxtdytYFmYX/Uy85w1rWoMGscZ3br27gP9U75YbCGi/1Zg9uP1Fn1x7QHwcLi
LI2gQhzDfvGBOa9y8Z30Dh2xbqiGT2IX6AuUV/k8woKMsLUc9hgZ3KxO/vukwrs0BaZbsJm/DxQF
AdcL0qp6k2eXBEsLqRgKqh5YWdu06T7qryGnAXVZH1xD7eJXQmMenc+1R2G/MBL1ZXKJsJLaiGhI
aQOdmmBqBbnKTj0gtaplEVJxNceASQRVUkYl31o01aR/9BcxZT8GLZ9SaHOOq3wwiaZJhdPu2ag2
kpi+QBXQQGbZrj9ZCF8D5q5JS52wyZ4mxcfCkJVWE15peaqC2u5JQQzbr9rmNldRKkQy/PY7KqVI
WBzqPywevlS/ftDSgTY9viujVqEuOvU9mTrRHYRKqIKnmAn/3peEyAwt80D0tIcJKVoLXzZrsuDf
ou9vsP/XxjgN5QYSa/FroREq5dndfUWLRQ+nTn3GNskHvIiRB2gjDQieYx3fAcApL8HBPeCibu5B
6AUIH/61aAL8mgIDnbL2DOhKkshrJRXbgKcOHOOXrPXSKZ45Dj3eaKglK85tFuJ+CQu2z4y3DbsQ
7hOnl6iwRu4WMnx2WG6ZpNQR2w10bgoZX4zHhCCRrVFOHUoAHnubFGIAILrDYw+3AioQoEMteS+5
4UvycksIItbyWL/E6bWY6+4B2/WY75ezyyd0upFsGVbQIUMhTLTPzflJnxJz5LUzVrns1klb3A/T
BFO/UdB3py5c0zy2tCwoYg2HDv570khnxLmP7mmRgkZwCEK6aSzblRp3vA7g3WDnRTpfrfyXn8YK
Zlb1vKwTSxSBsPkWRAm/B8vMhKEFNz6/ZM2LZ8r7dtUCP9/zv96y8MrzQKYtG/MGU6oEklDtGAH9
dBfoFt4L/eKMh0QuHlKfnOQjR+XBL54dOSCt7IpUpBMt9zUw4rm31bIPCkjgCu0mbh8ddD5yiHtQ
98v/Hug35OEpryHkkmg4A8G25IwavhMoGrtvRO2Qi+bxF+84wSgP9emd2RpJf6zZE5AwlfEljEmf
86F84wbot9ASUIdMqhJtpYvhxQpAPVg7RXBcKKNO2BU/Qksx2epiPoat8WGSdupyoRRxuAVXhMk8
SYwD9z7u99SzZdfiPzMIHcdkZbDPoI9TpjCL7VlaosNE58TW
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
