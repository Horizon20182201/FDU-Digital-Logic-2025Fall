module Clk6Hz(input  logic clk100MHz,
              output logic clk6Hz  );
              
    logic [23:0] count;
    
    always @(posedge clk100MHz)  
        count <= count + 1;
         
    assign clk6Hz = count[23];     
endmodule