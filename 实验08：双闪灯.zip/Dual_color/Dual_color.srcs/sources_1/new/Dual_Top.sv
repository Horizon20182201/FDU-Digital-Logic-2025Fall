module Dual_Top(
    input  logic CLK100MHZ,
    output logic LED17_R,
    output logic LED16_B );
    
    logic clk6Hz;
    
    Clk6Hz C6(CLK100MHZ, clk6Hz);
    
    Dual D1(.clk(clk6Hz),
            .RedLED1(LED17_R),
            .BlueLED2(LED16_B) );
endmodule