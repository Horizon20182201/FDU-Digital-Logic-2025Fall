module Dual(input logic clk,
            output logic RedLED1,
            output logic BlueLED2 );
              
    parameter S0 = 0, S1 = 1, S2 = 2, S3 = 3, S4 = 4, S5 = 5, S6 = 6, S7 = 7, S8 = 8;            
    logic [3:0] state;  
        
    always_ff @(posedge clk)
        case (state)
            S0 : state <= S1;  
            S1 : state <= S2;  
            S2 : state <= S3; 
            S3 : state <= S4; 
            S4 : state <= S5; 
            S5 : state <= S6; 
            S6 : state <= S7; 
            S7 : state <= S8; 
            S8 : state <= S0; 
        default: state <= S0;
        endcase      

    always_comb
        case (state)      
            S0 : begin RedLED1 = 1'b0; BlueLED2 = 1'b0; end
            S1 : begin RedLED1 = 1'b1; BlueLED2 = 1'b0; end
            S2 : begin RedLED1 = 1'b0; BlueLED2 = 1'b1; end  
            S3 : begin RedLED1 = 1'b1; BlueLED2 = 1'b0; end
            S4 : begin RedLED1 = 1'b0; BlueLED2 = 1'b1; end 
            S5 : begin RedLED1 = 1'b0; BlueLED2 = 1'b0; end
            S6 : begin RedLED1 = 1'b1; BlueLED2 = 1'b1; end
            S7 : begin RedLED1 = 1'b0; BlueLED2 = 1'b0; end
            S8 : begin RedLED1 = 1'b1; BlueLED2 = 1'b1; end 
        default: begin RedLED1 = 1'b0; BlueLED2 = 1'b0; end
        endcase         
endmodule