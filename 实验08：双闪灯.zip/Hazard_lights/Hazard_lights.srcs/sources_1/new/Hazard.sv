module Hazard(
    input  logic q,
    input  logic notq,
    output logic [15:0] led);
        
    assign led[15:0] = {8{q, notq}};
        
endmodule