module Hazard_Top(
    input  logic CLK100MHZ,
    input  logic [15:0] SW,
    output logic [15:0] LED );
    
    logic clk3Hz;
    logic Q;
    logic notQ;
    
    Clk3Hz C3(CLK100MHZ, clk3Hz);
    
    JK jk1(.clk(clk3Hz),
           .j(SW[15]),
           .k(SW[0]),
           .q(Q),
           .notq(notQ));
    
    assign LED = {8{Q, notQ}};
    
endmodule