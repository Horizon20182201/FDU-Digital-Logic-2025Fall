module Clk3Hz(input  logic clk100MHz,
              output logic clk3Hz  );
              
    logic [24:0] count;
    
    always @(posedge clk100MHz)  
        count <= count + 1;
         
    assign clk3Hz = count[24];
endmodule