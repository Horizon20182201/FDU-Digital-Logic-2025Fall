module JK(
    input  logic clk,
    input  logic j,
    input  logic k,
    output logic q,
    output logic notq );
    
    logic d;
    
    assign notq = ~q;
    assign d = (j & notq) | ((~k) & q);
    
    DFF d1(.clk(clk),
           .d(d),
           .q(q) );
    
endmodule