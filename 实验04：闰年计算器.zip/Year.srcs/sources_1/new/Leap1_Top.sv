module Leap1_Top(input  logic       CLK100MHZ,
                 input  logic [15:0] SW,
                 output logic [15:0] LED,
                 output logic LED16_G,
                 output logic LED16_R,
                 output logic [6:0] A2G,
                 output logic [7:0] AN,
                 output logic       DP );
    
    logic [15:0] x;
                 
    assign LED = SW;
    assign x = SW;
    
    
    Leap1 L1(.data(x),
             .ledg(LED16_G),
             .ledr(LED16_R));

    x7seg X7(.data(x),
             .clk (CLK100MHZ),
             .clr (0),
             .a2g (A2G),
             .an  (AN),
             .dp  (DP) );

endmodule
