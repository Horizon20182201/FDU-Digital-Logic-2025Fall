module Leap1(input  logic [15:0] data,
             output logic ledg,
             output logic ledr);
             
    logic [15:0] temp;
    assign temp = 1000 * data[15:12] + 100 * data[11:8] + 10 * data[7:4] + data[3:0];
             
    always_comb
    begin
        if (temp % 4 == 0)
            begin
                if (temp % 100 == 0)
                    begin
                        if (temp % 400 == 0)
                            begin
                                ledg = 1'b1;
                                ledr = 1'b0;
                            end
                        else
                            begin
                                ledg = 1'b0;
                                ledr = 1'b1;
                            end
                    end
                else
                    begin
                        ledg = 1'b1;
                        ledr = 1'b0;
                    end
            end
        else
            begin
                ledg = 1'b0;
                ledr = 1'b1;
            end
    end
endmodule