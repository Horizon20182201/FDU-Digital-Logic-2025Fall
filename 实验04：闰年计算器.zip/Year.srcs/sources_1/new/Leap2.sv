module Leap2(input  logic [15:0] data,
             output logic ledg,
             output logic ledr);
    
    logic D4;
    logic D100;
    logic D400;
    
    assign D4   = ((~data[4]) & (~data[1]) & (~data[0])) | (data[4] & data[1] & (~data[0]));
    assign D100 = (~data[7]) & (~data[6]) & (~data[5]) & (~data[4]) & (~data[3]) & (~data[2]) & (~data[1]) & (~data[0]);
    assign D400 = D100 & (((~data[11]) & (~data[9]) & (~data[8])) | (data[11] & data[9] & (~data[8])));
    
    assign ledg = (D4 & (~D100)) | D400;
    assign ledr = ~ledg;         
    
endmodule