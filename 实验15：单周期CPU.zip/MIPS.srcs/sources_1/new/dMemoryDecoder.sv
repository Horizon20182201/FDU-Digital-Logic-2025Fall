module dMemoryDecoder (
    input  logic        clk,              
    input  logic        writeEN,          
    input  logic [7:0]  addr,       
    input  logic [31:0] writeData, 
    output logic [31:0] readData, 
    input  logic        reset,            
    input  logic        btnL,             
    input  logic        btnR,             
    input  logic [15:0] switch,    
    output logic [7:0]  an,        
    output logic [6:0]  a2g        
);

    logic        mWrite;
    logic        pRead;
    logic        pWrite;
    logic [31:0] readData1;
    logic [31:0] readData2;
    logic [11:0] led;
    
    assign pRead    = addr[7];
    assign pWrite   = addr[7] & writeEN;
    assign mWrite   = ~addr[7] & writeEN;
    assign readData = addr[7] ? readData2 : readData1;
    
    dmem dmem (.clk(clk),
               .we(mWrite),
               .a(addr[7:0]),  
               .wd(writeData),
               .rd(readData1));
   
    IO io (.clk(clk),
           .reset(reset),
           .pRead(pRead),
           .pWrite(pWrite),
           .addr(addr[3:2]),            
           .pWriteData(writeData[11:0]),
           .pReadData(readData2),
           .buttonL(btnL),
           .buttonR(btnR),
           .switch(switch),
           .led(led));
    
    
    x7seg seg_disp(.data(led),  
                   .data2(switch),
                   .clk(clk),
                   .clr(1'b0), 
                   .a2g(a2g),  
                   .an(an));
    
endmodule
