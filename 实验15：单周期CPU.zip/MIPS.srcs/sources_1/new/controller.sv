module controller(input  logic [5:0] op, funct,
                  input  logic       zero,
                  output logic       memtoreg, memwrite,
                  output logic       pcsrc, alusrc,
                  output logic       regdst, regwrite,
                  output logic       jump,
                  output logic       immzero,
                  output logic [2:0] alucontrol);

  logic [1:0] aluop;
  logic       branch;
  logic       bne; 

  maindec md(.op(op),
             .memtoreg(memtoreg), .memwrite(memwrite),
             .branch(branch), .alusrc(alusrc),
             .regdst(regdst), .regwrite(regwrite),
             .jump(jump),
             .bne(bne),                
             .immzero(immzero),        
             .aluop(aluop));

  aludec ad(.funct(funct),
            .op(op),                  
            .aluop(aluop),
            .alucontrol(alucontrol));

  // BEQ: branch &  zero
  // BNE: branch & ~zero
  assign pcsrc = branch & (zero ^ bne); // bne

endmodule
