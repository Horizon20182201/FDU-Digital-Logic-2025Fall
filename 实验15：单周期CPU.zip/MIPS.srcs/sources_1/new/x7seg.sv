module x7seg(
    input  logic [11:0] data,
    input  logic [15:0] data2,
    input  logic        clk,
    input  logic        clr,
    output logic [6:0]  a2g,
    output logic [7:0]  an
);

    logic [2:0] s;  
    logic [3:0] digit;
    logic [19:0] clkdiv;
    logic [1:0]  sign;
    
    assign s = clkdiv[18:16];  

    always_comb begin
        case(s)
            3:  sign = 01;
            default: sign = 00;
        endcase
        case(s)
            0:  digit = data[3:0];
            1:  digit = data[7:4];
            2:  digit = data[11:8];
            4:  digit = data2[3:0];
            5:  digit = data2[7:4];
            6:  digit = data2[11:8];
            7:  digit = data2[15:12];
            default: digit = data[3:0];
        endcase
        case(s)
            3'b000: an = 8'b11111110; 
            3'b001: an = 8'b11111101; 
            3'b010: an = 8'b11111011; 
            3'b011: an = 8'b11110111; 
            3'b100: an = 8'b11101111;  
            3'b101: an = 8'b11011111;  
            3'b110: an = 8'b10111111;  
            3'b111: an = 8'b01111111;  
            default: an = 8'b11111111;
        endcase
    end

    always @(posedge clk, posedge clr)
      if(clr == 1) clkdiv <= 0;
      else         clkdiv <= clkdiv + 1;

    Hex7Seg H7(.digit(digit), .a2g(a2g), .sign(sign));    

endmodule
