module maindec(input  logic [5:0] op,
               output logic       memtoreg, memwrite,
               output logic       branch, alusrc,
               output logic       regdst, regwrite,
               output logic       jump,
               output logic       bne,
               output logic       immzero,
               output logic [1:0] aluop);

  logic [10:0] controls; // 9 -> 11

  assign {regwrite, regdst, alusrc, branch, bne, memwrite,
          memtoreg, jump, immzero, aluop} = controls;

  always_comb
    case (op)
      6'b000000: controls = 11'b11000000010; // RTYPE
      6'b100011: controls = 11'b10100010000; // LW
      6'b101011: controls = 11'b00100100000; // SW
      6'b000100: controls = 11'b00010000001; // BEQ
      6'b000101: controls = 11'b00011000001; // BNE
      6'b001000: controls = 11'b10100000000; // ADDI
      6'b001100: controls = 11'b10100000111; // ANDI
      6'b001101: controls = 11'b10100000111; // ORI
      6'b000010: controls = 11'b00000001000; // J
      default:   controls = 11'bxxxxxxxxxxx; // illegal op
    endcase

endmodule
