module x7seg_Top(
    input  logic       CLK100MHZ,
    input  logic [15:0] SW,
    output logic [6:0] A2G,
    output logic [7:0] AN,
    output logic       DP );
    
    logic [31:0] x;
    assign x[31:28] = 4'h0;
    assign x[27:24] = 4'h1;
    assign x[23:20] = 4'h3;
    assign x[18:16] = 4'h5;
    assign x[15:12] = SW[15:12];
    assign x[11:8]  = SW[11:8];
    assign x[7:4]   = SW[7:4];
    assign x[3:0]   = SW[3:0];
    
    x7seg X7(.data(x),
             .clk (CLK100MHZ),
             .clr (0),
             .a2g (A2G),
             .an  (AN),
             .dp  (DP) );
endmodule