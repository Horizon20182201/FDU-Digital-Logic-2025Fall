module Traffic(
    input  logic clk3,
    inout  logic clr,
    output logic [3:0] lights ); 

    logic [1:0] state;
    logic [7:0] count;

    parameter  S0 = 2'b00, S1 = 2'b01,
               S2 = 2'b10, S3 = 2'b11;
    parameter  Sec15 = 8'b00101101,
               Sec45 = 8'b10000111;

    always_ff @(posedge clk3, posedge clr) begin
        if(clr == 1) begin
            state <= S0;
            count <= 0;
        end            
        else
            case(state)
                S0: if(count < Sec45) begin
                        state <= S0;
                        count <= count + 1;
                    end                        
                    else begin
                        state <= S1;
                        count <= 0;
                    end                         
                S1: if(count < Sec15) begin
                        state <= S1;
                        count <= count + 1;
                    end                        
                    else begin
                        state <= S2;
                        count <= 0;
                    end
                S2: if(count < Sec45) begin
                        state <= S2;
                        count <= count + 1;
                    end                        
                    else begin
                        state <= S3;
                        count <= 0;
                    end
                S3: if(count < Sec15) begin
                        state <= S3;
                        count <= count + 1;
                    end                        
                    else begin
                        state <= S0;
                        count <= 0;
                    end
                default begin
                    state <= S0;
                    count <= 0;
                end                         
             endcase               
    end

    always_comb begin
        case(state)
            S0:     lights = 4'b1001;     
            S1:     lights = 4'b1101;     
            S2:     lights = 4'b0110;     
            S3:     lights = 4'b0111;     
            default lights = 4'b0000;
        endcase
    end             
endmodule