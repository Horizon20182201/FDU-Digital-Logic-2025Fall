module Traffic_Top(
    input  logic CLK100MHZ,
    input  logic BTNC,
    output logic LED16_G,
    output logic LED16_R,
    output logic LED17_G,
    output logic LED17_R );
    
    logic clk3Hz;
    logic [3:0] lights;
    
    assign LED16_G = lights[3];
    assign LED16_R = lights[2];
    assign LED17_G = lights[1];
    assign LED17_R = lights[0];
    
    clkdiv  U1(.clk(CLK100MHZ), .clr(BTNC), .clk3(clk3Hz));
    Traffic U2(.clk3(clk3Hz), .clr(BTNC), .lights(lights));
    
endmodule